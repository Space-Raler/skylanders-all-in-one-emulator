# PS5 Portal Transport Feasibility Notes

Date: 2026-10-26

## What is established by the uploaded source

The Switch reference is written to make a Nintendo Switch operate as a USB HID **device** for a separate host. Its `source/usb_device.cpp` uses Switch `usb:ds` / `libnx`; this is not a PS5 USB-device implementation and does not make the PS5's USB host controller become a peripheral.

The reference README documents this prior observation on a PS5: it reads the HID report descriptor repeatedly, then gives up before interrupt IN/OUT activity begins. In the Switch app's debug page, that appears as `Configured`, repeated `SETUP 81 06 ...` descriptor requests, and `IN done: 0`, `OUT done: 0`, `portal commands: 0`.

The same README documents a separate Linux-host enumeration failure (`usbhid` error `-110`) that led to the optional explicit control status stage in v10. The `ctrl_status=1` setting completes a control transfer after a data-IN reply with a zero-length OUT status stage, and after SET_REPORT with a zero-length IN status stage. The README says `ctrl_status=0` restores v9 behaviour. This is a hypothesis to test against the observed host, not a proven universal PS5 fix.

## Diagnostic order for the external Switch-device experiment

These steps only apply if reproducing the experiment where the Switch is the USB device connected to the PS5. They do not create a software-only virtual portal inside the PS5.

1. Capture the debug page/log from a cold test. Record USB state transitions, every SETUP request, control-transfer completion/failure, `IN done`, `OUT done`, and portal-command counters.
2. Plug the portal device in **before** launching Trap Team. Wait until the device reports configured/linked, then start the game.
3. If the game is already running, use the reference app's re-plug action once, then record whether the game opens the interface.
4. Compare `strings=1` against `strings=0` if the descriptor strings are enabled. Change only one setting per run.
5. Compare `ctrl_status=1` against `ctrl_status=0` only if the log shows a control status-stage failure or repeated report-descriptor requests. Record the exact result for each run.
6. Do not infer that the game is communicating merely because enumeration reaches Configured. Evidence of communication is a nonzero interrupt IN/OUT completion count or portal command count.

## Interpretation

- Repeated report-descriptor requests plus failed control status stages point first to HID enumeration/control-transfer completion, not to figure-dump contents or the portal command state machine.
- Configured state with no control-stage failures, but zero interrupt transfers and zero portal commands after the game starts, suggests the game has not opened/claimed the interface or rejected some aspect of its device/interface match. The available source does not establish which descriptor field or policy is responsible.
- Any IN/OUT transfers but no commands suggests the issue is later in the report/endpoint path; inspect report lengths, report-ID handling, endpoint addresses, and the speaker-on OUT/audio rule.
- A correct portal protocol core cannot fix an interface that the game never opens.

## Software-only PS5 feasibility gate

Before implementing the in-game overlay, identify and test a PS5-side mechanism that can make the running PS4 game receive portal-device operations. The uploaded Switch code only demonstrates a separate machine acting as USB host while the Switch acts as USB device. It does not provide a PS5-side virtual USB device, game I/O interception, or an overlay hook.

The current Linux core tests are useful protocol tests only. No PS5 payload, controller hook, overlay, or in-game figure recognition is included in this foundation.
