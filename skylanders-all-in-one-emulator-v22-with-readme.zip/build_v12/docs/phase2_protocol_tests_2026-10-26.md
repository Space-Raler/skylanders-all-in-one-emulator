# Phase 2 — Portable protocol-core test expansion
Date: 2026-10-26

## What changed

Expanded `tests/core_test.c` without changing the protocol implementation. The new tests exercise the existing portable C core against behaviors documented by Dolphin/RPCS3 portal implementations and the project's existing Switch reference. This is **reference-informed coverage**, not a full line-by-line conformance suite against an immutable upstream commit.

Added test groups:

- `test_reference_block_matrix_and_persistence`: loads a 1,024-byte figure into slot 0; iterates all 64 blocks; checks Q read, W write, acknowledgment, and Q read-back; verifies write count, dirty state, export, and caller-buffer immutability.
- `test_malformed_block_edges_and_idempotent_writes`: rejects malformed Q/W lengths and block 64; confirms byte-identical writes are acknowledged without dirtying/incrementing changed-write count; checks block 63.
- `test_reply_fifo_order_and_reset`: queues A, M, R replies and checks FIFO order; checks R deactivates portal and clears speaker state.

## Validation performed

```sh
make clean
make test
make sanitize
```

Results from the project workspace: C build passes with `-std=c11 -Wall -Wextra -Wpedantic -Werror`; Python debug-analyzer tests pass (3); `SkyBase core tests passed.`; AddressSanitizer and UndefinedBehaviorSanitizer pass.

## Findings / limitations

- No defect was exposed, so `src/sky/core/sky_core.c` was not changed in the block-matrix pass.
- The tests establish internal behavior of the portable core only. They do not prove exact parity with all Dolphin/RPCS3 command variants, test real USB transport, test PS5 firmware 13.42, or establish in-game recognition.
- See `phase2_reference_parity_matrix_2026-10-26.md` for differences now identified: R reply byte, slot count, J semantics, and transport-level accepted lengths.
- Immutable upstream SHA/license pinning, profile-specific tests, filesystem size/atomic-save tests, PS5 transport, and in-game recognition remain incomplete.

## Phase 2 continuation — targeted parity tests (2026-10-26)

Added two test groups to `tests/core_test.c`:

- `test_j_fade_and_r_profile_bytes`: verifies 7-byte `J` side/RGB/fade handling, acknowledgement for a non-ring side without mutating ring state, malformed `J` rejection, and exact `R` reply bytes under both configured firmware-version values (`0x1B` and `0x18`). This tests the current core's configurable byte, not a claim that either profile is correct for PS5 Trap Team.
- `test_padded_qw_and_empty_slot_replies`: verifies padded 32-byte `Q` and `W` reports at block 63, data round-trip for the padded write, and zero-filled empty-slot reply payloads for `Q` and `W`.

Validation rerun after adding these tests:

```sh
make clean && make test && make sanitize
```

Result: C core tests passed with `-std=c11 -Wall -Wextra -Wpedantic -Werror`; all 3 Python debug-analyzer tests passed; AddressSanitizer + UndefinedBehaviorSanitizer passed.

## Revision and license audit follow-up

The accessible raw Dolphin source identifies itself with `SPDX-License-Identifier: GPL-2.0-or-later` and a 2022 Dolphin Emulator Project copyright line. The accessible RPCS3 source file has no per-file license header in its first lines; its repository-level `LICENSE` is GNU GPL version 2. We are using these sources as behavioral references and have not copied their implementation code into the project core.

Exact immutable commit SHAs for the *specific files* remain unresolved in this pass: GitHub commit-history/API endpoints could not be reliably fetched in the current research environment, and local `git ls-remote` had no network DNS access. Do not treat a moving `master` URL or a repository-wide HEAD observation as a source-file pin. Before adapting any upstream implementation code, capture the full commit SHA from a local clone or a reachable commit page, record the file's license and applicable repository license, and include required notices/source obligations in the distribution.

## Figure dump file-safety tests (2026-10-26)

Added `tools/figure_dump.py` and `tests/test_figure_dump.py`:

- Accepts exactly 1,024 bytes; rejects 1,023-byte and 1,025-byte buffers/files.
- `load_dump()` rejects missing files and invalid-size files instead of silently accepting them.
- `atomic_save_dump()` validates before touching the destination, writes a same-directory temporary file, flushes/fsyncs it, then replaces the destination atomically; an invalid replacement leaves the previous valid file intact.
- The helper is a host-side raw dump utility; it does not locate Flipper storage or connect to the PS5 transport.

Final validation after these additions: `make clean && make test && make sanitize` passed; 7 Python tests passed, C core tests passed, and ASan/UBSan passed.
