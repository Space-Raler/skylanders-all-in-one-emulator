# Phase 3 — platform-neutral HID adapter contract
Date: 2026-10-26

## Implemented

Added `src/sky/core/sky_hid_adapter.h` and `.c` as a thin boundary between a future platform USB layer and the portable SkyBase core.

- `sky_hid_adapter_set_report()` routes already-decoded HID SET_REPORT command payloads to `sky_base_handle_control_command()`, keeping the immediate command response separate from the interrupt-IN reply queue.
- `sky_hid_adapter_interrupt_in()` validates endpoint `0x81` and returns the next queued command reply or status packet.
- `sky_hid_adapter_interrupt_out()` validates endpoint `0x02`. While the `M` command has enabled the speaker, it classifies OUT data as audio and deliberately does not feed the bytes to the portal command parser. When the speaker is off, interrupt-OUT payloads are ignored rather than guessed to be commands.

## Regression test added

`tests/adapter_test.c` sends `M 01`, confirms the immediate `M 01` response and queued `M 01 00 19` interrupt reply are separate, then sends a 19-byte OUT payload beginning with `W` while audio is enabled. It verifies that the payload is classified as audio and does not alter slot data, increment `block_writes`, or enqueue a fake write reply. It also checks reset behavior, wrong endpoints, and invalid arguments.

## Validation

`make clean && make test && make sanitize` passes in this workspace:
- 7 Python tests passed.
- Existing C core suite passed.
- New HID adapter contract suite passed.
- Both C suites passed under AddressSanitizer and UndefinedBehaviorSanitizer.

## Important boundary

This is **not** a real USB implementation. The adapter receives an already-decoded SET_REPORT payload; it does not parse USB setup packets, expose descriptors, register endpoints, perform a USB status stage, schedule endpoint transfers, hook the PS5 game, or emulate a device through the PS5's host ports. No PS5 payload build, console-side trace, or in-game recognition was performed. The module establishes a safer and testable integration contract for a future platform-specific adapter only.

## Next go/no-go

Continue source research only if it can identify a firmware-13.42-specific, observable game-I/O path. Otherwise the next hardware validation remains the official SDK hello-world build/load test, followed by read-only evidence about how Trap Team obtains portal I/O. Do not label the protocol adapter as a PS5 USB transport.
