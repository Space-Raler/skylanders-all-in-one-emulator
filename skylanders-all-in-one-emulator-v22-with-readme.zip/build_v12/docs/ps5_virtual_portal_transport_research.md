# PS5 virtual-portal transport research — decision gate

Date: 2026-10-26  
Target: PS5 firmware 13.42, etaHEN + ELF loader; PS4 version of Skylanders: Trap Team.  
Status: source/web research only; no PS5 transport has been implemented or tested.

## Executive finding

The existing Switch project and Flipper firmware prove that the reusable portal protocol can be implemented on other platforms. They do not provide a way for a PS5 process to become a USB HID device. The PS5 ports are used as host ports, so writing a 32-byte report in a payload or overlay does not itself cause Trap Team to receive it.

The upstream `ps5-payload-dev/sdk` is a dynamic payload SDK. Its documented `hello_world` sample is an appropriate first build/load test, but the SDK README does not document a virtual USB-device facility or a supported game-I/O interception API. A successful hello-world payload would therefore validate build/loader plumbing only, not portal transport.

The public `PS5Dev/PS5SDK` README describes a work-in-progress SDK and lists firmware-specific kernel-hacking examples for 3.00, 3.20, 3.21, 4.02, 4.03, 4.50 and 4.51. Firmware 13.42 is not in that list. Those listed offsets must not be reused for 13.42. This does not prove that every userland payload is incompatible; it means the listed kernel-offset examples are not a source-backed basis for this target.

Sources:
- Dynamic payload SDK and documented sample workflow: https://github.com/ps5-payload-dev/sdk
- PS5Dev SDK scope and kernel firmware list: https://github.com/PS5Dev/PS5SDK
- Linux USB gadget documentation (general explanation of device-side USB controller requirements, not evidence about PS5 internals): https://www.kernel.org/doc/html/latest/driver-api/usb/gadget.html

## Candidate routes and current assessment

### Route A — software-only virtual USB device in the PS5

**Assessment: not established; do not implement on assumption.** A USB gadget needs device-side controller support, endpoint control, and enumeration responses. The uploaded Switch code uses Nintendo Switch `usb:ds` / libnx device APIs; those APIs are platform-specific and cannot be copied to the PS5. No public PS5 payload API found in the reviewed SDK documentation exposes a device-side USB gadget controller.

**Evidence needed to reopen this route:** a firmware-13.42-compatible PS5 API/driver or a validated low-level implementation demonstrating device-side USB capability on the console's actual hardware. Until that evidence exists, mark this route blocked.

### Route B — intercept or virtualize the game's USB access inside the PS5

**Assessment: plausible in concept, but unproven and high risk.** If Trap Team's PS4 process talks to a userland USB service/library, a verified interception layer might emulate the expected responses without turning the physical port into a device. Alternatively, interception might require modifying a lower-level USB stack or kernel path. The sources reviewed do not establish which USB path this specific game uses on PS5, whether its USB calls are reachable from a payload, or whether etaHEN exposes a compatible hook on firmware 13.42.

**Evidence needed:** identify the process/library/service responsible for USB access; establish an observation method; capture a real call/traffic trace; then prototype a read-only diagnostic or narrowly scoped hook before supplying fake portal data. Do not use guessed kernel offsets or write to kernel memory based on another firmware's offsets.

### Route C — a separate USB-device-capable computer or hardware bridge

**Assessment: established as a general architecture, but outside the user's desired final design.** The working Switch reference already demonstrates a separate system acting as the USB device. A device-capable external system can present the portal HID interface to the PS5 host. This is useful as a diagnostic/control experiment, but it violates the requested no-external-device constraint and does not satisfy the final goal by itself.

**Use only as a fallback diagnostic:** if the user can capture logs from the existing Switch experiment, those logs can help determine what the PS5 game requests. It cannot prove a software-only same-console solution.

### Route D — overlay/menu alone

**Assessment: insufficient for portal transport.** An overlay such as Prospero-Menu may provide a UI entry point and a controller shortcut, but displaying a selector and changing in-memory dump state does not make the game receive HID reports. The overlay must eventually connect to a separately verified data-delivery mechanism.

## Ordered validation plan

1. **Build gate:** on the user's Linux Mint system, build the official `ps5-payload-dev/sdk` `samples/hello_world` using its own README. Save the full compiler output and generated ELF details. This tests the toolchain only.
2. **Loader gate:** run only the benign diagnostic sample through the user's already-working ELF loader. Record whether it starts and how output is observed. Do not infer USB support from success.
3. **Game-path discovery:** identify the Trap Team process and available observation facilities for the PS4 title running under backward compatibility. Research must be specific to firmware 13.42 and the actual title; do not assume native PS5 application APIs apply unchanged to a PS4 game.
4. **Evidence before hooking:** find source-backed evidence of the game's USB access route or capture a trace from the external-device experiment. If no observable/interceptable path is available, stop and document the blocker rather than build a speculative hook.
5. **Minimal transport prototype:** only after Step 3/4, implement a diagnostic that can prove a specific game request was observed and a controlled response was delivered. Do not start figure switching until this works.
6. **Protocol integration:** connect the tested transport to `sky_core.c`, then test one user-owned dump and a minimal slot transition.
7. **Overlay integration:** only after the transport and single-figure test pass, integrate the L3 + R3 selector.

## What would count as success

- **Build success:** the SDK produces an ELF; this is not console execution.
- **Loader success:** the benign payload runs; this is not portal support.
- **Transport proof:** a trace demonstrates that the running game requests portal-like operations and receives the emulated responses through the selected mechanism.
- **Game proof:** Trap Team visibly recognizes a selected user-owned figure, and switching is repeatable.

Only the last two gates validate the central project requirement. At the time of writing, neither has been demonstrated for a software-only PS5 solution.
