# Switch Reference vs Flipper SkyBase: Skylanders Portal Parity Audit

Date: 2026-10-26
Scope: source-level comparison for Trap Team portal behavior. This is not a PS5 USB implementation.

## Switch reference facts

From `skyportal-switch/source/hid_function.h`, `hid_function.cpp`, `portal.h`, `portal.cpp`, and `usb_device.cpp`:

- Portal identity is VID `0x1430`, PID `0x0150`, device revision `0x0100`.
- The vendor-defined HID report descriptor is 29 bytes. It defines one 32-byte input report and one 32-byte output report and declares no report IDs.
- The report descriptor uses vendor-defined usage page `0xFF00`, usage `1`, and 32-byte input/output reports.
- Default portal interrupt endpoint addresses are IN `0x81` and OUT `0x02` when interface number is 0 and the default `out_endpoint=2` is used. IN is derived from interface number; OUT can be configured.
- HID class `SET_REPORT` (`bRequest=0x09`) is accepted on the control endpoint. Data is delivered to `Portal::handleCommand()` by `HidFunction::onControlOut()`.
- The OUT interrupt endpoint is also registered. While speaker mode is on (`M` with a nonzero argument), interrupt-OUT packets are treated as audio and must not be parsed as portal commands.
- Figure size is 1024 bytes, made of 64 blocks of 16 bytes. The Switch reference supports 16 generic slots and packs slot status into four bytes of status report `S`.
- Commands include `A`, `C`, `J`, `L`, `M`, `Q`, `R`, `S`, `V`, `W`, and `Z` is recognized as a command letter for report-ID-prefix detection but has no behavior in the shown switch statement (so it falls through as unknown after normalization).
- `Q` reads a 16-byte block; `W` writes one. The core queues replies and emits status reports when no reply is queued.
- The source supports tunable poll intervals, OUT endpoint, USB version/BOS behavior, strings, and optional explicit control-transfer status stages.

## Foundation / Flipper core facts

From the current foundation source:

- The reusable C core is platform-independent and now defines 16 slots (`SKY_SLOT_COUNT 16`) with four packed status bytes.
- It models the same 1024-byte figure / 64-block / 16-byte-block data shape and the same basic portal command family.
- It has tests for report-ID-prefixed command input and slot status behavior, and the core can be tested on Linux.
- The C core does not itself implement USB descriptors, endpoint posting, control transfer completion, or PS5 game I/O. Those belong to a transport/platform layer.

## Parity and remaining differences to verify

1. **Transport path:** Switch source accepts `SET_REPORT` through control transfers and separately registers interrupt endpoints. Confirm the Flipper's actual USB path and packet normalization before treating the implementations as byte-for-byte equivalent.
2. **OUT endpoint address:** Switch defaults to OUT endpoint 2 for Skylanders. Do not silently change to endpoint 1; compare with the actual Flipper descriptor and host trace.
3. **Control status stage:** Switch `ctrl_status=1` is an explicit experimental option. It should only be tested one variable at a time against a captured failure; it is not a universal fix.
4. **Audio mode:** Ensure any future transport layer does not feed speaker PCM to the `W` command parser.
5. **Slot/status transitions:** The core and Switch reference should be regression-tested for load/remove/reload sequences, including a removal before an arrival transition has been polled.
6. **Command `Z`:** The Switch `isCommandLetter()` helper includes `Z` for prefix detection, but the displayed command switch has no `case 'Z'`. Confirm whether this is intentional or a stale compatibility marker before adding behavior.
7. **Game compatibility:** A matching protocol core does not prove the game accepts the USB descriptors, device interface, or runtime transport.

## Test matrix for any future hardware run

Change one setting per run and record: device state, USB speed, SETUP requests, control data/status completion, IN/OUT post and completion counters, portal command count, last command, and game connected state.

- A: portal attached before game launch; default settings.
- B: re-plug once after game launch.
- C: `strings=0`, all other settings unchanged.
- D: `ctrl_status=0`, all other settings unchanged; compare only if control-stage behavior is implicated.
- E: endpoint/poll interval variations only after A-D are documented.

Do not infer success from `Configured` alone. Stronger evidence is completed transfer activity and recognized portal commands; strongest evidence is actual figure recognition in Trap Team.

## PS5 boundary

This audit helps align the protocol core with the Switch/Flipper references. It does not provide a mechanism for a PS5 USB host port to become a USB device, nor does it prove game-side I/O interception. The PS5 transport feasibility gate remains open.
