# PS5 transport investigation — decision update

Date: 2026-10-26
Target: PS5 firmware 13.42, etaHEN + ELF loader, PS4 edition of Skylanders: Trap Team.
Status: research and host tests only; no target-console transport test has been performed.

## New source-backed finding

The Ghostcontrol fork's README describes two separate paths:

1. It accesses physically connected external controllers through PS5 USB host-side facilities (`/dev/ugen*` and USB-FS transfer helpers).
2. It creates a virtual DualSense through `scePadVirtualDeviceAddDevice` and injects controller-state data through `scePadVirtualDeviceInsertData`.

The second path represents gamepad input, not arbitrary USB device emulation. A Skylanders portal uses a different protocol and the game expects portal commands and figure data, so the virtual-DualSense interface is not a substitute for the portal.

Source: https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2
Relevant upstream SDK: https://github.com/ps5-payload-dev/sdk
ELF loader: https://github.com/ps5-payload-dev/elfldr

## Updated route ranking

### 1. Same-console interception of game USB access — highest-priority software-only research route, still unproven

We need to determine whether the PS4 game under backward compatibility performs portal I/O through a userland library/service or a kernel path that a payload can observe safely. A read-only trace must come before hooks. Firmware-specific compatibility matters: no offsets from unrelated firmware should be copied.

**Go/no-go evidence:** identify the process/service and an observable call/transfer path; capture one request and its status without modifying it. If that is impossible, this route remains blocked.

### 2. PS5 virtual USB peripheral/gadget — no evidence found in reviewed public docs

The reviewed payload SDK documents payload builds and a hello-world workflow but does not document a generic device-side USB gadget interface. Host ports plus a virtual gamepad API do not prove gadget capability. Keep this route blocked until a firmware-13.42-specific implementation or API is found.

### 3. External USB-device-capable bridge — technically conventional fallback, but violates the no-external-hardware goal

A separate device that can act as a USB peripheral is a useful diagnostic alternative because the PS5 is the USB host. It is not the requested final design and should not be represented as a software-only solution.

### 4. Overlay-only — not a transport solution

An overlay can choose dumps and manage slots, but cannot deliver portal HID reports to the game without a working transport route.

## Minimum transport proof test

A future target-side test must record:

- exact process/service and observation method;
- request/operation identifier, buffer length, and status/error result;
- controlled response bytes and response status, if a response path is proven;
- a subsequent game/service event showing the response was consumed;
- at least three repeatable trials without uncontrolled retry loops.

Do not call a payload launch, overlay click, unit test, or virtual DualSense injection a portal transport proof.

## Linux Mint SDK setup note

The official SDK README lists `bash`, `clang-18`, `lld-18`, and `wget` as required on Debian-flavoured systems, and gives this build command:

```sh
export PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk
make -C samples/hello_world
```

Linux Mint package availability depends on its release and Ubuntu base. Before installing, check:

```sh
apt-cache policy clang-18 lld-18
```

If those packages have no candidate, do not install random compiler packages or add an unverified repository. Send the output and the Mint version (`cat /etc/linuxmint/info`) so the matching LLVM 18 installation route can be selected. The SDK README source is https://github.com/ps5-payload-dev/sdk.

## Current conclusion

The portal protocol core can be tested independently, but the central software-only transport is still the largest unknown. Public source reviewed so far demonstrates USB host access and virtual gamepad injection, not a generic virtual portal device or a proven Trap Team USB interception method on firmware 13.42. The next required user-side evidence is a successful SDK sample build and a benign payload launch, followed by read-only observation of the game I/O path.
