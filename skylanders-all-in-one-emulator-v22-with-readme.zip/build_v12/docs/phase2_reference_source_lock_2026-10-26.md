# Phase 2 — reference-source lock and reuse policy
Date: 2026-10-26

## Reference snapshots

| Reference | Revision / locator | Status | Use in this project |
|---|---|---|---|
| Dolphin | Repository commit `3eb30c7620b4475b2e0404228ba0d2b238a132f1` (observed public master head on 2026-10-25); target file: `Source/Core/Core/IOS/USB/Emulated/Skylanders/Skylander.cpp` | Immutable repository revision recorded; the source file must be re-opened at this exact SHA during a network-enabled source audit before describing its exact behavior as confirmed at that revision. | Protocol comparison only; no Dolphin code copied into this project. |
| RPCS3 | `https://github.com/RPCS3/rpcs3/blob/master/rpcs3/Emu/Io/Skylander.cpp` inspected on 2026-10-26 | **Not pinned.** The current web view did not expose an immutable commit SHA for the exact file snapshot, and the local workspace has no network/DNS access to run `git ls-remote`. Do not claim a fully pinned RPCS3 source audit yet. | Protocol comparison only; no RPCS3 code copied into this project. |

## License / code-reuse policy

- Dolphin's repository is GPL-2.0-or-later; RPCS3's repository states GPL-2.0-only for most files, subject to file-specific headers.
- This project's portable C state machine and tests are independently written/maintained project code. They reference observable protocol behavior and do not copy upstream source functions or code blocks.
- If code is copied or adapted later, stop first: pin the exact source commit, inspect the specific file header and repository license, retain required notices, and decide whether the resulting distribution is compatible with the selected project license. Do not assume that protocol facts and copied implementation code have the same obligations.

## Current parity decisions

- R reply byte is explicit: `SKY_R_PROFILE_DOLPHIN = 0x1B`, `SKY_R_PROFILE_RPCS3 = 0x18`.
- The default remains Dolphin-like (`0x1B`) for backward compatibility with the existing project default, not because the PS5 Trap Team target has been proven to require it.
- `sky_base_set_r_profile()` only accepts the two named values; unknown values and a null state pointer fail.
- R commands now accept only the documented short 2-byte command or padded 32-byte report. One-byte R is rejected; tests cover both malformed and padded input.
- This is a core-level contract. A future USB/game transport adapter must normalize the actual transfer format before passing bytes to the core.

## Verification performed

From `build_v12/`:

```sh
make clean && make test && make sanitize
```

Results on 2026-10-26: 7 Python unit tests passed; C core tests passed under `-Wall -Wextra -Wpedantic -Werror`; AddressSanitizer + UndefinedBehaviorSanitizer run passed.

## Still open

1. Re-open Dolphin's target file at the exact recorded SHA and verify the R/J/Q/W observations against that immutable source.
2. Capture RPCS3's exact master SHA and re-open its target file at that SHA. Until then, RPCS3 observations are current-page observations, not a fully pinned revision.
3. Add real target-game captured traffic when available; reference emulator parity alone cannot select the correct PS5 Trap Team response profile.
