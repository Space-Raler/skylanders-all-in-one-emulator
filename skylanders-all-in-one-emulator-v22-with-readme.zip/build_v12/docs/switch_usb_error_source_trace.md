# Switch Portal USB Error Source Trace

Date: 2026-10-26
Scope: Source-level trace of the two error patterns visible in the user's Switch debug photos, using `skyportal-switch-v11.zip`.

## Findings

### 1. `ERR post IN/OUT: 0x2628C`

The labels correspond to the failure branches in `source/usb_device.cpp`:

- `UsbDevice::postIn()` calls `usbDsEndpoint_PostBufferAsync(epIn_, inBuf_, kReportSize, &urb)`.
- `UsbDevice::postOut()` calls `usbDsEndpoint_PostBufferAsync(epOut_, outBuf_, kReportSize, &urb)`.
- If either call returns a failed `Result`, the code increments its error counter and logs `post IN failed: 0x%X` or `post OUT failed: 0x%X`.

Therefore, this photo message means posting an asynchronous endpoint transfer failed at the USB-device API boundary. It is not a portal-command parser error. The source shown does not decode `0x2628C` into a symbolic cause.

### 2. `ERR IN/OUT transfer: 0x828C`

The labels correspond to the completion handlers in `source/usb_device.cpp`:

- `UsbDevice::completeIn()` obtains endpoint report data, then calls `usbDsParseReportData(&rd, inUrb_, nullptr, &sent)`. A failed parse/result produces `noteError(rc, "IN transfer")`.
- `UsbDevice::completeOut()` similarly calls `usbDsParseReportData(&rd, outUrb_, nullptr, &got)`. A failed result produces `noteError(rc, "OUT transfer")`.
- `isNotFound(rc)` is treated specially as a transfer still in flight; other failed results are logged as transfer errors.

Therefore, `0x828C` is being reported by the completion/report-data processing path, not by `postIn()`/`postOut()`. The exact symbolic meaning still needs to be decoded against the matching libnx/USB service definitions and the actual event/URB lifecycle. Do not infer a definitive root cause from the numeric value alone.

### 3. Why the working photos look different

The source handles HID `SET_REPORT` in `HidFunction::onSetup()`: it returns a control-OUT receive action, and `UsbDevice::handleSetup()` passes the received data to `hid_.onControlOut()`, which calls `portal_.handleCommand(data, len)`. That path can increment the portal-command counter without any interrupt-OUT endpoint completion.

This matches the user's working screenshots showing many portal commands and IN completions while `OUT done` remains zero. It is a consistent explanation, not a full USB trace: the screenshots do not show every raw control request or payload byte.

### 4. Repeated report-descriptor request

The visible setup line `SETUP 81 06 v2200 i0000 l29 -> sent` is consistent with a standard device-to-host `GET_DESCRIPTOR` request for a HID report descriptor (`wValue` high byte `0x22`, length 41/0x29). In this code, the HID report descriptor is returned by `HidFunction::onSetup()`.

The source comments explicitly discuss an earlier failure where the PS5 repeatedly read the report descriptor and the host-side device-add operation timed out; the code adds a control status-stage option because a missing status stage can leave a control transfer incomplete. This is a documented hypothesis/known issue in the reference, not proof that every observed PS5 or Switch failure has that cause.

## What is established vs. unknown

Established from source:
- `0x2628C` appears in endpoint-post failure log branches.
- `0x828C` appears in endpoint transfer completion/report parsing failure branches.
- Portal commands may arrive through control `SET_REPORT`, separately from interrupt OUT.
- The USB device implementation is Nintendo Switch `libnx` code and is not a PS5 payload.

Not established yet:
- The exact symbolic meaning of the two numeric result codes.
- Whether the failing screenshot's immediate cause is endpoint lifecycle, configuration, cancellation/race, host behavior, or another service-level condition.
- Whether changing control status, descriptors, strings, or endpoint options fixes the specific failing setup; these need controlled one-variable-at-a-time tests.
- Whether the PS5 can supply/intercept the portal interface entirely in software on the same console.

## Next controlled test

1. Capture a fresh raw debug log from one working and one failing run, if possible.
2. Change only `ctrl_status` between runs; retain the same strings, endpoint addresses/intervals, and launch order.
3. Then test `strings` independently, and only afterward test endpoint address/interval overrides.
4. Record whether descriptor requests repeat, whether `SET_REPORT` is received, whether status-stage success/failure is logged, and whether IN/OUT posts and completions advance.
5. Decode the `Result` values using the exact libnx version/headers used to build this Switch reference before assigning symbolic names.

## Bottom line

The source trace narrows the two visible errors to different layers: endpoint-transfer submission (`0x2628C`) versus transfer completion/report processing (`0x828C`). It does not yet prove why either call fails. The next step is controlled logging and matching-SDK error decoding, while keeping the PS5 same-console transport question separate.
