# PS5 USB-interface research update — controller path vs portal path

Date: 2026-10-26
Target: PS5 firmware 13.42, etaHEN + ELF loader; PS4 version of Skylanders: Trap Team.
Status: source review only; no PS5-side USB code has been built or run for this project.

## New source reviewed: Ghostcontrol PS5 USB Controller Patcher

Repository: https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2

The public project description reports a concrete PS5-side path for a *specific controller use case*:

- it uses `scePadVirtualDeviceAddDevice` to create a virtual DualSense pad;
- it opens raw USB full-speed endpoints for a connected external controller/dongle;
- it decodes that controller's reports and injects equivalent `ScePadData` through `scePadVirtualDeviceInsertData`.

This is useful evidence that PS5 payload projects can combine raw USB host access and the PS5 virtual-controller interface. It does **not** show that arbitrary USB HID devices can be created as virtual devices, that a game can be given a virtual Skylanders portal, or that the approach is compatible with firmware 13.42. Its virtual-device API is specifically for controller input, which is semantically different from the portal's vendor-defined HID interface and command/report protocol.

## Updated assessment

### 1. Virtual USB device on the PS5 itself

Still **unproven**. The reviewed source demonstrates a virtual game controller, not a virtual USB peripheral. Do not treat `scePadVirtualDeviceAddDevice` as a generic HID-device API.

### 2. Raw USB host access plus proxy/translation

A real research lead now exists for how another PS5 payload obtains raw USB full-speed endpoint access. The next source-level investigation should inspect the repository's USB helper and setup code for the exact symbols and assumptions it uses. However, even if those routines can read an external device, they do not automatically intercept Trap Team's own USB requests or inject portal reports into the game's USB service.

### 3. Game-side I/O interception

Still **unproven**. Need evidence of the PS4 title's actual USB path under PS5 backward compatibility, and a supported/validated way to observe or intercept that path on firmware 13.42. A controller virtual-device API is not a substitute for that evidence.

### 4. External bridge as diagnostic only

A USB-device-capable external board/computer remains the most straightforward architecture to test the portal descriptors and protocol against a USB host, but it is outside the requested final no-external-hardware design. Do not silently treat this fallback as satisfying the requirement.

## Revised investigation sequence

1. Build and load the official SDK `hello_world` sample on the user's Mint machine. This confirms toolchain/loader operation only.
2. Review Ghostcontrol's `usb_helpers.c`, endpoint-opening logic, and virtual-device lifecycle to identify which USB APIs are available and whether any generic HID emulation facility exists. Do not copy firmware-specific offsets or controller-only logic into the project without understanding its prerequisites.
3. Search for documented PS5 USB FS/virtual-device APIs and firmware 13.42-specific evidence. Record exact source paths/symbols, not just claims from repository descriptions.
4. Establish how Trap Team accesses the portal: trace or source evidence for its USB service/library and the point where a portal response is consumed. If there is no safe observation path, mark this as blocked.
5. Only after steps 2–4 show a viable interface, create a minimal diagnostic prototype. It must log a real observed request and a controlled response; it must not just print that it sent data.
6. Connect the tested transport to `sky_core.c`, test one user-owned dump, then add overlay/slot switching.

## Success criteria and non-claims

- A virtual DualSense is not a virtual Skylanders portal.
- Opening raw USB endpoints for an external device is not equivalent to intercepting the game's own USB operations.
- A payload compiling or running does not prove that the game can receive portal reports.
- No software-only PS5 portal route has been demonstrated yet.

## Sources

- PS5 SDK overview and current documented scope: https://github.com/PS5Dev/PS5SDK
- Dynamic payload SDK and hello-world workflow: https://github.com/ps5-payload-dev/sdk
- Ghostcontrol PS5 USB Controller Patcher (source project and description): https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2
