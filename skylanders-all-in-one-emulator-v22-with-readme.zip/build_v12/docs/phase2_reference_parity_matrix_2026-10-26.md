# Phase 2 — Reference protocol parity matrix
Date: 2026-10-26

## Source basis and revision discipline

Sources inspected for this matrix:

- Dolphin `Source/Core/Core/IOS/USB/Emulated/Skylanders/Skylander.cpp`: https://github.com/dolphin-emu/dolphin/blob/master/Source/Core/Core/IOS/USB/Emulated/Skylanders/Skylander.cpp
- RPCS3 `rpcs3/Emu/Io/Skylander.cpp`: https://github.com/RPCS3/rpcs3/blob/master/rpcs3/Emu/Io/Skylander.cpp
- PortalSync, a Windows USB/IP bridge that documents its protocol source lineage: https://github.com/rhsts/portalsync
- Project-local portable core and tests: `src/sky/core/sky_core.c`, `tests/core_test.c`.

**Revision caveat:** these source pages were inspected on 2026-10-26 while pointed at moving branches (`master`/`main`). The Dolphin repository head was observed in its public activity feed at commit `b5f580e6f9b5ba442248ac62a25cb4db246aa69c` on 2026-10-24, but this is a repository-head reference, not a claim that the portal source itself changed in that commit. RPCS3's exact commit SHA was not independently captured in this pass. Before copying/adapting upstream code, freeze exact commit SHAs for both repositories and record the applicable file headers/license notices. Do not call this a fully immutable/pinned audit yet.

## Command-by-command matrix (observed source behavior)

| Command / area | Dolphin source observation | RPCS3 source observation | Portable core / testing consequence |
|---|---|---|---|
| USB identity | VID `1430`, PID `0150`, device version `0100`; HID interface, 32-byte interrupt endpoints `0x81` IN and `0x02` OUT | Same VID/PID and similar HID descriptor shape | Descriptor facts are reference context only; this project core is not a USB device implementation. |
| `A` activate | 2-byte command supported in control SET_REPORT; queues 32-byte reply beginning `41 <mode> FF 77`; activates portal | Source accepts length 2 and queues interrupt reply; notes mode byte indicates activate/deactivate | Tests cover activation and queued response. Exact transport completion behavior must be tested separately. |
| `C` color | Four-byte command accepted; stores RGB; no required queued portal reply in the shown handler | Four-byte command accepted; stores RGB and prepares a control response | Do not assume the control-transfer completion/acknowledgement behavior is identical. Core models state, not USB control-transfer byte counts. |
| `J` side color/sync | Source accepts 7-byte form; queues `J` response and applies side/color values | 7-byte form is side/RGB/fade duration; queues a one-byte `J` interrupt reply | This is a key semantic difference from implementations that treat `J` as a generic sync/status command. Needs a targeted compatibility test before claiming exact parity. |
| `L` portal side lights | 5-byte command accepted; light-side structure noted as incomplete/TODO in RPCS3 source | 5-byte command accepted; documents side, RGB, and special trap LED handling | Current core accepts the command shape but does not model real LEDs; this is nonessential to dump reads, but source-level behavior differs. |
| `M` audio firmware | 2-byte command; queued reply begins `4D <arg> 00 19` | 2-byte command; queued reply begins `4D <arg> 00 19` | Existing test covers reply order and reset; audio streaming itself is not implemented. |
| `Q` read block | Command has 3-byte form; slot index is low nibble; block is 0–63; queues a reply with slot/block/data or empty-slot state | 3-byte or padded 32-byte form accepted; slot index is low nibble; rejects slot >= 8; block must be < 64; reply is queued | Project core supports 16 slots and tests all 64 blocks. Exact reference compatibility must account for RPCS3's 8-slot model and report padding/transport rules. |
| `R` ready/shutdown | 2-byte form; queues `R` response (wired default observed as `52 02 1B 00...` in current source comments) | Accepts 2-byte or 32-byte form; queues `52 02 18 00...`; deactivates portal | **Reply bytes differ:** `0x1B` (Dolphin source comments) vs `0x18` (RPCS3 current source). Do not unify them without a target-specific decision. Existing core tests verify state reset, not a universal upstream byte constant. |
| `S` status | 1-byte command; status is emitted through interrupt/status path, not a queued ordinary response | Accepts 1-byte or 32-byte form; does not queue a normal reply in the shown switch | Core tests check packed status and slot transition queues. A transport adapter must preserve periodic status reports and expected lengths. |
| `V` unknown/other | 4-byte command; echoed control response in the current source | 4-byte command accepted; no special portal state action shown | Current core command acceptance should not be mistaken for a full USB-level echo contract. |
| `W` write block | 19-byte command; slot low nibble and block/data; queues write reply | Accepts 19-byte or padded 32-byte form; slot index low nibble; rejects slot >= 8; block < 64; queues response | Project tests cover 19-byte writes, block 0–63, read-back, dirty/export state, malformed lengths. Need a deliberate compatibility policy for 32-byte padded OUT reports. |
| Figure data | 64 blocks × 16 bytes = 1,024 bytes | Same 1,024-byte / 64-block layout | Full 64-block read/write/read-back sweep passes on host core. Does not validate real dump cryptography or game-specific figure validity. |
| Slot capacity | Source comments describe a maximum 16 unique Skylanders tracked; particular portal types may track fewer | Current implementation loops over 8 slots | Core uses 16 slots to match the Switch reference / broader protocol representation; it must not be described as identical to RPCS3's slot count. |
| Arrival/removal transitions | Status uses 2 bits per slot; arrival/removal are queued transitions consumed by status polling | Queues arrival `3 -> 1`; removal `2 -> 0`; status queue is consumed during status reporting | Existing tests cover arrival/removal queue behavior, including stale transitions and higher slots. Exact status byte ordering should be kept in tests. |
| Audio payloads | Audio command is identified; actual audio behavior is a separate path | Returns firmware version `0x0019` to avoid/enable the expected portal audio path; audio/side lights have additional behavior | Core only tracks speaker state; adapter must not misroute audio payload bytes as portal commands. Audio data path remains unimplemented. |
| Persistence | Figure data stored as 1,024-byte image; implementation's save/write lifecycle is emulator-specific | `W` writes figure block and calls save on active figure | Project core marks modified data and exports a copy; host filesystem loader and atomic file replacement are still separate tasks. |

## Important interpretation

These are two emulator implementations of a portal inside their own emulated USB stacks. They are valuable protocol references, but not evidence that a PS5 payload can register a generic virtual USB HID device or that Trap Team on PS5 will route portal traffic to this core.

The current source pages show genuine implementation differences, especially the `R` reply byte and slot limits. A protocol core that chooses one response must document its target profile instead of describing all emulator behavior as interchangeable.

## Tests already present

- All 64 blocks: Q -> W -> Q read-back, per-block data verification.
- Invalid block 64 and malformed Q/W lengths rejected.
- Identical write acknowledged without dirtying/incrementing changed-write count.
- Export/persistence-copy safety and original input-buffer immutability.
- FIFO reply ordering for A, M, R; R reset-state checks.
- Existing activation/deactivation, status packing for 16 slots, empty slots, slot retention, queue overflow, report-ID-prefix, and malformed command tests.

## New targeted tests recommended before claiming parity

1. Define an explicit profile enum/constant for `Dolphin-like` vs `RPCS3-like` only if the product actually needs both; otherwise document the chosen Trap Team target behavior.
2. Add assertions for exact `R` reply bytes per selected profile (`0x1B` vs `0x18`) after source revisions are pinned.
3. Test `J` as a 7-byte side-light/fade command; do not test it as generic sync without source evidence.
4. Test accepted length variants (short and padded 32-byte reports) at the *transport adapter* boundary; keep the portable core's normalization contract explicit.
5. Test empty-slot Q/W reply bytes against the selected target profile.
6. Add filesystem tests for exact 1,024-byte dump validation, failed/truncated loads, write-back, and atomic save/replace.
7. Only after the above, compare captured target-game traffic against the chosen response profile.

## Follow-up implemented on 2026-10-26

- Added named R profiles (`SKY_R_PROFILE_DOLPHIN` = `0x1B`, `SKY_R_PROFILE_RPCS3` = `0x18`) and a setter that rejects unknown profile values.
- Tightened R input length validation: accepts 2-byte and padded 32-byte reports; rejects one-byte malformed input.
- Added tests for invalid profile selection, null profile state, malformed R length, and padded R report.
- Added `docs/phase2_reference_source_lock_2026-10-26.md` documenting the source lock state and code-reuse policy.

## Status

- Command matrix and targeted R profile/length tests: implemented and host-tested.
- Dolphin repository revision recorded, but exact target-file behavior at that SHA still needs immutable URL verification.
- RPCS3 source SHA: still not pinned; local DNS/network prevented `git ls-remote`, and the fetched web view did not expose the exact file revision. This is explicitly not marked complete.
- No upstream implementation code has been copied into the core.
- PS5 firmware 13.42 transport proof and in-game recognition remain separate integration goals.
