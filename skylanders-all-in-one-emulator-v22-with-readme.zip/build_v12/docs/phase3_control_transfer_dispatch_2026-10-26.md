# Phase 3 — decoded USB control-transfer dispatcher

Date: 2026-10-26
Target: PS5 firmware 13.42, etaHEN + ELF loader, PS4 edition of Skylanders: Trap Team.
Status: portable host implementation and tests complete; no PS5 transport or game-I/O proof.

## Source-backed finding

The pinned Dolphin Skylander implementation exposes the concrete control request shape:

- It rejects a control request unless `bmRequestType == 0x21`.
- `bRequest == 0x09` dispatches the command payload (A/C/J/L/M/Q/R/S/V/W) and produces command-specific immediate control-response bytes.
- Requests `0x0A` and `0x0B` are accepted as Get Interface / Set Interface paths in the emulation abstraction.
- When a command needs a separate reply, that reply is queued for a later interrupt transfer; if no command reply is queued, the interrupt-IN path returns status.
- For example, `A` has a two-byte immediate response plus a queued 32-byte interrupt reply; `R` has immediate `R 00` plus queued `R 02 1B ...`; `J` echoes its seven meaningful bytes and queues a one-byte `J`; `Q` echoes its three meaningful bytes and queues block data; `W` echoes its 19 meaningful bytes and queues a write acknowledgement.

Pinned reference: https://github.com/dolphin-emu/dolphin/blob/3eb30c7620b4475b2e0404228ba0d2b238a132f1/Source/Core/Core/IOS/USB/Emulated/Skylanders/Skylander.cpp
Relevant source ranges in that immutable file: descriptor setup around lines 607–640; control dispatcher around 687–980; interrupt-IN path around 990–1042.

The `expected_count` values are consistently the meaningful immediate response length plus eight in this emulator IPC abstraction (e.g. two command bytes -> 10, 19 command bytes -> 27). This is an observation about Dolphin's transfer wrapper, not a claim that a physical USB transfer includes an extra eight bytes.

## Implemented

Added:
- `src/sky/core/sky_usb_control.h`
- `src/sky/core/sky_usb_control.c`

`sky_usb_control_dispatch()` takes an already-decoded control request and its data payload. It validates the reference request type, dispatches command request `0x09` through the existing adapter/core, reports request/length/command/buffer errors explicitly, and keeps immediate response bytes separate from the interrupt-IN queue. It also models `0x0A` and `0x0B` as successful no-data requests for the portable layer.

The dispatcher is deliberately *not* a raw USB stack. It does not parse the eight-byte USB setup packet, enumerate the device, serve descriptors, perform the hardware status stage, register endpoints, schedule transfers, hook the game, or provide a PS5 device-side USB implementation. Those duties belong to a platform layer whose existence on firmware 13.42 has not been demonstrated.

## Tests

`tests/adapter_test.c` now checks:
- a valid `0x21/0x09` M command produces an immediate echo and a separate queued interrupt reply;
- an incorrect request type is rejected;
- a `wLength`/payload-length mismatch is rejected;
- `0x0A` and `0x0B` no-data paths are accepted/rejected for the tested lengths;
- insufficient response capacity is reported;
- audio-like interrupt-OUT data beginning with `W` is not interpreted as a figure write;
- wrong endpoints and invalid arguments are rejected.

Validation run in this workspace:

```sh
make clean && make test && make sanitize
```

Result: 7 Python tests passed, core C tests passed, adapter/control-dispatch C tests passed, ASan passed, UBSan passed. These are host tests only.

## SDK bundle audit

The uploaded `ps5-payload-sdk.zip` contains FreeBSD-derived USB headers (`usb.h`, `libusb.h`, `dev/usb/usb_ioctl.h`, `dev/usb/usb_device.h`, and related definitions). The `usb.h` compatibility header declares `usb_open`, bulk/interrupt I/O, and `usb_control_msg`, which describe access to existing USB devices from the host side. The archive's presence of kernel USB controller/transfer headers is not evidence that a payload can instantiate a device-side USB gadget; headers alone do not prove the corresponding driver or API is usable at runtime on the PS5.

This narrows the investigation: the SDK bundle is useful for host-side device access and request definitions, but it does not establish a virtual Skylanders portal on the console's host ports.

## Current decision

The protocol adapter is now one layer closer to reference-shaped control handling, and the exact control request structure is source-backed. The software-only transport remains blocked pending one of:

1. a firmware-13.42-compatible, source-backed interception path for Trap Team's USB calls; or
2. evidence of a PS5 device-side USB capability/API that can enumerate as a portal.

No guessed kernel offsets, memory patches, or unsupported USB gadget assumptions were added. The next practical milestone requires the user's Linux Mint and PS5 to build/run the benign official SDK sample and provide the exact result; that validates the build/loader route but still does not prove portal transport.
