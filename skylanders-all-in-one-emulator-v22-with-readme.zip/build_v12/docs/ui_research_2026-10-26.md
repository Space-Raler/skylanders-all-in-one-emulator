# UI and PS5 Homebrew Research — 2026-10-26

## Fresh findings

- PuckbridgePS5 documents a phone-friendly web remap portal, USB controller threads, virtual DualSense, and game hooks under `payload/game_hooks.c` and `payload/bridge/`. It explicitly says it was tested on firmware 13.60; that is not proof for our 13.42 target, and its bridge is controller-oriented, not a Skylanders portal. https://github.com/ThisIsAkill/PuckbridgePS5
- Prospero Explorer lists file browsing, removable storage, network file serving, and launching installed titles. This is a useful feature reference, not proof it can provide virtual USB portal support. https://prosperostore.net/app/PPSA99109/
- `ps5-homebrew-ui` documents a native OpenGL UI toolkit with 21 designs, 30 themes, reusable components, and a validated console build. https://github.com/blackbearreloaded/ps5-homebrew-ui
- `ps5-native-app-boilerplate` describes a native app build/packaging route; its listed hardware validation is firmware 6.02 and 12.70, so firmware 13.42 must be tested independently. https://github.com/blackbearreloaded/ps5-native-app-boilerplate
- PS5 SDK README cautions that the SDK is work in progress and intended mostly for payloads/simple homebrew, not full proper applications. https://github.com/PS5Dev/PS5SDK
- ProsperoStore is a catalog/installer, not itself a portal emulator. Its repository notes firmware support is experimental outside explicitly tested versions. https://github.com/darkxex/ProsperoStore

## UI prototype

`ui-prototype/index.html` is a responsive, interactive browser prototype. It includes a library view, category filters, local file selection, eight local slot assignments, and an activity log. It is a UI-only prototype: file selection is local to the browser session, figure dumps are not parsed, and no PS5/USB connection is made. Do not describe its simulated connection check as hardware support.

## Suggested direction

1. Keep the UI prototype separate from runtime/transport code.
2. At home, confirm Linux Mint version and build environment.
3. Build the official payload SDK sample and verify it loads.
4. Read Puckbridge `game_hooks.c` and `bridge/` plus the licenses before reusing any code.
5. Identify an observable portal-related game operation and prove one end-to-end response before promising emulation.
6. Only after the transport proof, port the UI to a native PS5 app using `ps5-homebrew-ui` / `ps5-native-app-boilerplate`, if their build/runtime is verified on the user's firmware.
