# Pre-home research update — 2026-10-26

## Purpose

Prepare the next investigation steps before the user has access to the Linux Mint computer and PS5. This is a source-based research note, not proof that portal emulation works.

## Findings from PuckbridgePS5

Repository: https://github.com/ThisIsAkill/PuckbridgePS5

The public README says the project is a PS5 payload built on Ghostcontrol. It reads a physical Steam Controller over USB and makes games see a virtual DualSense. The project uses `payload/gc_main.c` for USB-controller threads and virtual DualSense behavior, and `payload/game_hooks.c` plus `payload/bridge/` for in-game input, rumble, and speaker hooks. Its phone-friendly web portal is served by the payload. It says tested on firmware 13.60.

What is reusable as a research lead:
- Payload build structure and use of `ps5-payload-sdk`.
- Physical USB HID host access patterns.
- In-game hook/bridge organization.
- Local web UI pattern for selecting profiles and viewing logs.

What this does NOT prove:
- That PS5 software can create a generic virtual USB peripheral.
- That game hooks can intercept or replace Trap Team's portal USB transactions.
- That firmware 13.42 is compatible with its offsets, hooks, or runtime assumptions.
- That a virtual DualSense can stand in for a Skylanders portal. It cannot be assumed to do so.

## SDK build gate

Repository: https://github.com/ps5-payload-dev/sdk

The documented quick start on Debian-flavored systems is to install `bash clang-18 lld-18 wget`, obtain the SDK release bundle, set `PS5_PAYLOAD_SDK`, then run `make -C samples/hello_world`. The optional network test uses `PS5_HOST` and `PS5_PORT=9021`. Linux Mint's exact release and package availability must be checked before installing dependencies; do not add third-party repositories blindly.

When the user is home, first run:

```sh
cat /etc/linuxmint/info
apt-cache policy clang-18 lld-18
```

Then choose the correct installation method for that Mint base. Build the benign hello-world sample before attempting any portal code. A successful build proves only that the toolchain works; successful loading proves only that the ELF loader path works.

## Launcher decision

A launcher/selector is a useful parallel component, but not a substitute for portal transport. A launcher can store and select user-owned figure dumps, show slots, and start the game if supported. It cannot by itself make the PS5's USB host port behave as a USB peripheral or cause Trap Team to receive portal command responses.

Preferred architecture if the transport path proves feasible:
1. Native launcher/selector and user-owned dump library.
2. Separate payload/bridge for runtime integration, if it can safely and reliably remain active while the game runs.
3. Existing portable 16-slot portal core behind a transport adapter.
4. Minimal one-figure test before traps, multiple slots, and UI polish.

Do not assume a resident payload survives game launch or that hooks can be installed on firmware 13.42 until tested.

## Next tests in strict order

1. Identify Linux Mint release and check package candidates.
2. Build the official SDK `hello_world` sample.
3. Load only the benign diagnostic ELF using the user's existing loader and confirm observable success.
4. Research and, if feasible, obtain read-only evidence of what Trap Team asks from the portal on the target PS5. Do not infer USB transactions from a UI overlay or a command counter alone.
5. Only if the relevant request/response path can be observed and safely intercepted, design a minimal transport proof.
6. Test one user-owned dump; expand to the 16-slot core only after one figure is recognized.
7. Develop the launcher/overlay in parallel only where it does not delay the transport proof.

## Current confidence

- Portable portal protocol core: host tests and sanitizers previously passed; not a PS5 build.
- SDK/toolchain on user's Linux Mint: not yet tested.
- Payload loading on user's PS5: not yet tested with this project.
- Portal transport on PS5 firmware 13.42: unproven.
- Trap Team recognizing a software-only figure: unproven.
- Complete hardware-free design: still a low-confidence research project. The previous rough 10–20% estimate remains subjective and should be updated only after evidence from the SDK and game-I/O milestones.

## Sources checked

- PuckbridgePS5 README: https://github.com/ThisIsAkill/PuckbridgePS5
- PS5 payload SDK: https://github.com/ps5-payload-dev/sdk
- PS5Dev SDK notes: https://github.com/PS5Dev/PS5SDK
- ProsperoStore catalog: https://prosperostore.net/

The PS5Dev SDK README states that it is work-in-progress and that its documented kernel-offset examples list firmware through 4.51. This is not evidence that no 13.42 method exists; it means the public README does not establish compatibility for those kernel examples. Prefer the dynamic payload SDK's benign build/load gate before kernel-specific experimentation.
