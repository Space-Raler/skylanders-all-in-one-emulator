# PS5 transport source audit — Steps 2 and 3

Date: 2026-10-26
Target: PS5 firmware 13.42, etaHEN + ELF loader; PS4 edition of Skylanders: Trap Team running on PS5.
Status: public source inspection and test design complete; no console-side transport test has been run.

## Step 2 — inspect the Ghostcontrol source

Source reviewed:
- Repository: https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2
- Main source: https://raw.githubusercontent.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2/main/payload/gc_main.c
- USB helper: https://raw.githubusercontent.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2/main/payload/usb_helpers.c

### Observed implementation details

In `payload/gc_main.c`:

- Includes PS5 USB host headers (`<dev/usb/usb.h>`, `usb_ioctl.h`, `usb_endian.h`) near the top of the file.
- Declares `scePadVirtualDeviceAddDevice`, `scePadVirtualDeviceDeleteDevice`, and `scePadVirtualDeviceInsertData` as virtual controller calls.
- Scans `/dev/ugen*` nodes and reads connected physical USB device descriptors to identify external controllers.
- Uses `USB_FS_INIT`, `USB_IFACE_DRIVER_DETACH`, `USB_FS_OPEN`, and related USB-FS ioctls to access a *physically connected USB device as a host*.
- Creates a virtual DualSense (`VIRTUAL_DEVICE_TYPE_DUALSENSE` is 3), acquires/binds its virtual-device handle, parses physical controller input, and injects translated controller state with `scePadVirtualDeviceInsertData`.

In `payload/usb_helpers.c`:

- `usb_send_out()` configures an existing USB-FS endpoint, starts a transfer with `USB_FS_START`, then polls `USB_FS_COMPLETE` until success, a non-`EBUSY` error, or timeout.
- `usb_send_cmd()` wraps that helper for short controller initialization commands.

### What this proves

The source is a concrete example of two distinct PS5 capabilities in this project:

1. **Host-side raw USB access** to an attached physical controller/dongle through `/dev/ugen*` and USB-FS ioctls.
2. **Virtual controller input injection** through the PS5 virtual-pad interface.

### What this does not prove

It does **not** show a PS5 USB device/gadget mode, a way to make a PS5 port enumerate as a USB peripheral, or a way to intercept a different game's USB transactions and answer them as a Skylanders portal. The VDI path supplies controller input to the system; it is not a generic HID peripheral and it does not deliver a 32-byte portal response to Trap Team.

The source is useful as an architectural reference only. It should not be copied wholesale into the portal implementation: its USB code reads *physical devices*, and its virtual device represents a *game controller*.

## Step 2b — broadened source search

The public PS5 SDK documentation describes payload ELF development and firmware-specific kernel examples, but the reviewed material does not document a generic USB gadget/virtual-HID API or a supported game USB interception API. The kernel-offset examples listed in the public PS5Dev SDK README stop at firmware 4.51; that is not a basis for using those offsets on firmware 13.42.

A separate public Ghostpad project also documents virtual controller creation and input redirection. It reinforces that virtual controller injection is a separate feature from portal HID transport; it does not establish a portal emulation mechanism. Its implementation details may be firmware-sensitive and are not a reason to attempt guessed patches on 13.42.

Useful source links:
- Ghostcontrol repository: https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2
- Ghostcontrol raw USB-FS helper: https://raw.githubusercontent.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2/main/payload/usb_helpers.c
- PS5Dev SDK and its firmware notes: https://github.com/PS5Dev/PS5SDK
- Dynamic payload SDK: https://github.com/ps5-payload-dev/sdk
- Ghostpad virtual controller research: https://github.com/srbraboo/Ghostpad

## Step 3 — minimum transport-proof test definition

A valid proof must be performed on the target console/game; host-side unit tests cannot prove the game transport works. Define the following narrow diagnostic test before implementing a portal hook:

### Required evidence fields

Each event in a capture should include:

- monotonic timestamp;
- process/service identity and firmware/game context, when available;
- direction (`GAME_TO_PORTAL` or `PORTAL_TO_GAME`);
- operation/command and payload length;
- request bytes (or a reproducible hash plus a separately saved hex dump);
- response bytes and response length;
- return/error code and elapsed time;
- evidence source (instrumented call, supported trace, or external USB capture).

### Pass conditions

A transport proof passes only when all are demonstrated in the same run:

1. A request attributable to Trap Team's running process or its actual USB service is observed; a random USB event or overlay click is insufficient.
2. The request's command and payload length are recorded without truncation.
3. A controlled, protocol-valid response is delivered through the candidate transport path.
4. A subsequent observable event confirms the response was consumed (e.g. next protocol state/request, or game-side recognition). A function returning success by itself is not enough.
5. The test is repeatable at least three times with bounded timeouts and no uncontrolled retry loop.

### Safety and scope

- Start with read-only observation; do not change kernel memory or use offsets from another firmware.
- If the title exposes no observable/interceptable USB path to the payload, record the result as **blocked** rather than fabricate a successful trace.
- Do not test figure swapping or slot data until the transport proof passes.

### Current result

**Test specification complete; actual transport proof blocked pending console-side observation.** This workspace has no PS5 attached and no trace from the running Trap Team process. Therefore Step 3's acceptance test has been defined but cannot honestly be marked as passed. The next actionable input is the Linux Mint SDK `hello_world` build/load result, then a safe console-side observation method compatible with firmware 13.42.

## Decision after Steps 2–3

The software-only portal transport is still unproven. Ghostcontrol confirms useful host USB and virtual controller primitives exist in a public payload, but neither primitive is equivalent to virtualizing Trap Team's portal. No PS5 ELF, USB hook, virtual portal, or in-game recognition was built in this step.
