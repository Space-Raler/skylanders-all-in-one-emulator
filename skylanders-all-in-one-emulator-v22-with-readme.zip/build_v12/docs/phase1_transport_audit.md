# Phase 1: Skylanders portal transport audit

Date: 2026-10-26
Scope: source-level comparison of the uploaded Flipper SkyBase reference and `skyportal-switch-v11`. This is not a live PS5 USB trace and does not establish that the PS5 game opened the device.

## Source-confirmed device shape

The Flipper `sky/usb_skylander.c` and Switch `source/hid_function.cpp` use the same 29-byte vendor-defined HID report descriptor:

- Usage page `0xFF00`, application usage `1`.
- One 32-byte input report and one 32-byte output report.
- No report IDs in the descriptor.
- USB VID:PID `1430:0150`.
- HID interface with two interrupt endpoints.
- IN endpoint address `0x81`, 32-byte packet, nominal polling interval 22 ms in the Flipper source.
- OUT endpoint address `0x02`, 32-byte packet, interval 1 ms in the Flipper source.

The Switch source can vary descriptors and polling intervals. Its default Skylanders mode uses IN `0x81`, OUT `0x02`, and has explicit configurable control-transfer status stages. Those are implementation options in the Switch experiment, not proof of the real PS5 game's expected values.

## Command transport paths found in source

There are two possible host-to-device paths in the Switch reference:

1. HID class control request `SET_REPORT` (`bRequest 0x09`, interface recipient). The control OUT data stage is passed to `Portal::handleCommand`.
2. Interrupt OUT endpoint data. The Switch `HidFunction::onInterruptOut()` routes it to `Portal::handleOut()`. With speaker mode off, this is treated as a portal command; while speaker mode is on, it is counted as audio and not parsed as a command.

The Flipper implementation differs: `REQ_SET_REPORT` is explicitly parsed as a portal command, while its interrupt OUT endpoint handler is used for speaker audio when audio is enabled. It does not call the portal command handler from the OUT endpoint callback.

Therefore, source code alone does **not** establish whether Trap Team on PS5 uses control `SET_REPORT`, interrupt OUT, or both. Since the reported PS5 experiment saw zero IN/OUT endpoint completions and zero portal commands, it has not yet reached the point where that question can be answered from traffic.

## Report and control-request handling

Both implementations answer HID report-descriptor requests and support the standard HID class request family used by these devices, including `GET_REPORT`, `GET_IDLE`, `GET_PROTOCOL`, `SET_IDLE`, and `SET_PROTOCOL`; both accept `SET_REPORT` output data.

The Switch source documents an earlier host-side failure where Linux re-requested the report descriptor and timed out (`usbhid` error `-110`). The Switch implementation added optional explicit zero-length control status stages. The README describes that as a diagnostic/compatibility setting, not a confirmed fix for the PS5 game-side detection problem.

## What the reported PS5 symptoms mean

Reported observation: PS5 reads the HID report descriptor repeatedly, but `IN done`, `OUT done`, and portal-command counts stay at zero.

Supported conclusion: USB enumeration reached at least the descriptor-fetch stage; no evidence yet shows that the game opened the interface or began exchanging portal reports.

Not established: the exact reason for rejection, whether a specific descriptor field is wrong, whether the game requires a particular control-transfer status-stage behavior, or whether the game would accept any reports after opening the interface.

Do not tune figure dumps or slot data to address this symptom. Those operate after the transport starts.

## Ordered diagnostic experiment (requires the external Switch-as-USB-device setup)

Keep one setting changed per run and save the debug log/screenshot each time:

1. Cold boot the Switch portal app and capture its counters before connecting.
2. Connect the Switch device to the PS5 **before launching Trap Team**; wait for the device's configured/linked state, then launch the game.
3. Record the raw setup requests, whether descriptor requests repeat, control-transfer status-stage outcomes, IN completion count, OUT completion count, and portal-command count.
4. If the game is already running, test the app's re-plug function once and record the same counters.
5. Only if descriptor requests repeat or the log reports status-stage failure, compare `ctrl_status=1` with `ctrl_status=0`. Do not infer the cause from a setting change unless the logs show a reproducible difference.
6. If still no endpoint activity, compare `strings=1` with `strings=0`, changing nothing else.
7. If IN/OUT activity begins, capture the first packets and lengths. Then determine whether command bytes arrive through control `SET_REPORT`, interrupt OUT, or both.

Interpretation:

- Repeated descriptor fetches plus status-stage failures: investigate control-transfer completion first.
- Configured state, no status-stage failures, and zero endpoint completions after game launch: game/interface-open or matching issue remains likely, but the exact cause is unknown.
- IN/OUT completions with zero recognized commands: investigate report length, optional leading zero report ID, endpoint path, and speaker/audio mode.
- Recognized commands but no figure recognition: only then investigate portal state transitions and figure data.

## PS5 software-only feasibility gate

The Switch USB implementation uses Nintendo Switch `usb:ds`/`libnx` and makes a separate Switch act as a USB device for a USB host. It is not a PS5-side virtual USB device implementation. A PS5 host port cannot become a peripheral just by reusing this code. Before building the in-game UI, a distinct, demonstrable PS5-side mechanism must be identified for the running PS4 game to receive portal operations (for example, a supported virtual-device facility or a verified game I/O interception path).

No such mechanism is demonstrated in the uploaded sources. The next step requires either a real transport log from the external-device experiment or concrete PS5-side API/payload evidence. Do not mark software-only emulation as feasible until that gate is passed.
