# PS5 Payload Build Workflow — Research Gate

Date: 2026-10-26
Target reported by user: PS5 firmware 13.42, Linux development host, etaHEN and an ELF loader already working.

## Research result

There are two SDK paths with different goals. Do not mix their build instructions.

### Option A — PS5Dev/PS5SDK

Repository: https://github.com/PS5Dev/PS5SDK

The upstream README describes a work-in-progress SDK for ELF payloads and simple homebrew. It uses CMake/Ninja and a toolchain file (`cmake/toolchain-ps5.cmake`). Its documented kernel-hacking firmware profiles currently listed in the README are 3.00, 3.20, 3.21, 4.02, 4.03, 4.50, and 4.51. Firmware 13.42 is not on that documented list. Therefore do not use its firmware-specific kernel examples or offsets for this project.

### Option B — ps5-payload-dev/sdk

Repository: https://github.com/ps5-payload-dev/sdk

Its README describes a dynamically linked payload SDK and gives a sample workflow:

```sh
# after installing the SDK's documented prerequisites and release archive
export PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk
make -C samples/hello_world

# Optional: only if a network ELF loader is listening on the PS5
export PS5_HOST=<PS5-IP>
export PS5_PORT=9021
make -C samples/hello_world test
```

The README lists `clang-18`, `lld-18`, `wget`, and `bash` as required on Debian-flavored systems, with other tools optional. Use the current release's own README because the SDK and sample layout can change.

The existence of this build path does **not** prove that a payload is compatible with firmware 13.42, nor does it supply a USB virtual device or a game I/O hook. A harmless hello-world sample is the appropriate first test; do not begin with kernel writes or offsets.

## Build gate checklist

1. On the Linux development machine, check the installed SDK path and its own `samples/hello_world` example.
2. Build the upstream sample exactly as its README specifies.
3. Preserve the build log and verify the generated ELF path and architecture with the SDK's provided tools.
4. Only send a known-safe hello-world payload after confirming the correct loader endpoint and a recovery method.
5. Record whether the payload starts, exits, and reports output. A successful load only validates the toolchain/loader path.
6. Do not integrate USB code, controller hooks, kernel offsets, or overlay code at this stage.
7. If the sample does not build, capture the first compiler/linker error, SDK release/version, Linux distro, and the exact commands. Do not guess missing APIs.

## Current environment gap

No PS5 SDK checkout or installed SDK path was supplied in the files available for this work. Therefore the target-specific payload cannot honestly be reported as built or tested here. This report is research and a reproducible next-step checklist, not a compiled PS5 ELF.

## The portal feasibility gate remains separate

Even a successful diagnostic payload does not make the PS5 USB host port behave as a USB peripheral. Before a portal implementation is attempted, a separate source-backed method must be identified for the game to receive the portal's expected HID operations (for example, a supported game-side interception path, if one can be established). An overlay can provide the selector UI but cannot by itself provide the USB protocol to the game.
