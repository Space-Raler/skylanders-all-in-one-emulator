SKYLANDERS PORTAL — SWITCH DEBUG PHOTO ANALYSIS
Date: 2026-10-26
Source: user-provided photos of the Switch portal app's USB debug page
Scope: Skylanders portal transport only; no inference from the Infinity code.

OBSERVED WORKING CASE (last two photos, as identified by user)
The visible counters include:
- USB state: Configured; speed: high.
- Game: connected.
- Setup requests: approximately 277 in the clearest final image.
- IN done: approximately 282 in the clearest final image.
- OUT done: 0.
- Portal commands: approximately 413.
- Unknown: 0.
- Status reports: approximately 278.
- Errors: 0 in one photo; an earlier/later working-state photo shows 1 error with last error 0x828C.
- Last command bytes appear as `J 02 00` in one photo; another appears to show `C 28 D0`. These byte readings are low-confidence due to angle/resolution.

Interpretation:
The working case proves the app is receiving host-to-device control requests and is recognizing portal commands. It also shows that interrupt-OUT is not necessarily required for the app's current working mode; the portal command count is increasing while OUT done remains 0. This is consistent with portal commands arriving through HID control SET_REPORT, which the Switch implementation routes to the portal state machine. Confirm in source/logging before treating it as definitive.

OBSERVED FAILING CASES (earlier photos)
Case A:
- State: Configured; speed: full.
- Setup requests: 1.
- IN done: 0; OUT done: 0.
- Portal commands: 0; Unknown: 0.
- Status reports: 456 in one screenshot, then 516 in another.
- Errors: 913, last error 0x2628C.
- Log repeatedly shows `ERR post OUT: 0x2628C` and `ERR post IN: 0x2628C`.

Case B:
- State: Configured; speed: high.
- Setup requests: 3; IN done: 0; OUT done: 0.
- Portal commands: 0; Unknown: 0; status reports: 1.
- Errors: 2, last error 0x828C.
- Visible control setup entries include `SETUP 81 06 v2200 i0000 l29 -> sent` (repeated).
- Then `ERR OUT transfer: 0x828C`, `ERR IN transfer: 0x828C`, and `host disconnected`.

Interpretation:
These failing cases are not equivalent to the working case. They have no completed IN/OUT transfers and no recognized portal commands. Repeated posting/transfer errors suggest the host transfer path is failing or being torn down, but the numeric error values cannot be mapped confidently without the app's error-code definitions and the exact API return context. `SETUP 81 06 ... v2200 ... l29` looks like a standard HID GET_DESCRIPTOR request for a report descriptor (request type 0x81, request 0x06, descriptor type 0x22, length 0x29/41 decimal if the display is hexadecimal/decimal as formatted). The display's formatting must be confirmed from code. This request being sent is not itself evidence that the game opened the interface.

IMPORTANT CONCLUSION
The last two photos show the Switch portal app can reach a working state: it reports Game: connected and the portal command counter grows. The earlier photos show a distinct failing state with repeated transfer-posting errors or immediate transfer failures. This narrows the next task to comparing what changed between these sessions, rather than assuming all PS5 attempts fail in the same way.

WHAT THESE PHOTOS DO NOT PROVE
- They do not prove that the PS5 version of Trap Team recognizes a figure.
- They do not reveal the exact cause of 0x2628C or 0x828C.
- They do not establish whether the error is caused by endpoint configuration, transfer cancellation/disconnection, timing, interface selection, or another USB stack issue.
- They do not prove the same USB-device architecture can be implemented in software on the PS5 itself.

NEXT DIAGNOSTIC ACTIONS
1. Preserve one full log from a working session and one full log from a failing session; include the events immediately before the first error.
2. Keep host, cable/adapter, app build, device connection order, and game launch order identical except for one variable at a time.
3. In the Switch source, find where `0x2628C` and `0x828C` are logged; record the underlying USB API and the operation that returned each value. Do not assign meaning based only on the numeric values.
4. Compare the working and failing setup sequences, especially descriptor requests, interface/alternate-setting selection, endpoint addresses, transfer-post calls, disconnect/reconnect, and whether `Game: connected` is reached.
5. Add a diagnostic log line for each endpoint-post result and each completion/cancel/disconnect reason if the source does not already expose them.
6. For the PS5 software-only goal, continue treating a PS5-side virtual/intercepted portal transport as an unresolved feasibility requirement. The Switch device-side implementation is not a PS5 payload.

SOURCE CONFIDENCE
High confidence: the visible counter values and labels listed above where legible; the user says the final two photos are the working ones.
Medium confidence: the interpretation that control SET_REPORT is carrying portal commands, because the working image has commands increasing while OUT done is zero and the source architecture routes control SET_REPORT into the portal.
Low confidence: exact last-command bytes and interpretation of error numeric values, due to photo quality and absent error-code definitions.
