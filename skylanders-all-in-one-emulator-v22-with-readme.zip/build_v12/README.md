# Skylanders Trap Team — PS5 Virtual Portal Foundation

This is the first engineering foundation for the project, built from the user's uploaded All-in-One-Toypad-Emulator reference.

## What is included

- `src/sky/core/sky_core.c` and `.h`: the portable SkyBase portal state machine from the supplied repository, with the two fixes listed under "Review and fixes" below.
- `tests/core_test.c`: host-side tests for figure load/removal and slot retention, status packet flow, every portal command (A, R, M, C, J, L, Q, W), report-ID-prefixed input, malformed input, and queue overflow.
- `Makefile`: `make test` runs the suite; `make sanitize` runs it under AddressSanitizer and UBSan.
- This document: current architecture and constraints.

## Run the host tests on Linux

Requirements: GCC or Clang and Make.

```sh
make test        # plain build, -Werror
make sanitize    # same tests with ASan + UBSan (catches buffer over-reads)
```

Expected output:

```text
SkyBase core tests passed.
```

## Review and fixes (2026-10-26)

Both fixes are in `sky_base_handle_command()`. Each is covered by a new test, and the original
`sky_core.c` fails those tests under `make sanitize`.

1. **Out-of-bounds read.** A 1-byte `A` command read `buf[1]` past the end of the buffer. The
   source comments say some hosts send 1-byte `A`. The Flipper never hit it because its buffers
   are always 32+ bytes. A PS5 layer might not have that guarantee.
2. **HID report-ID prefix.** Some hosts prefix the payload with a report ID of 0 (33 bytes instead
   of 32). The core treated that as an unknown command `0x00` and ignored it. The Flipper strips the
   prefix in its USB layer, so a new host layer would have had to remember to do the same. The core
   now strips it itself.

Not changed, but worth knowing:

- `M`, `J`, `Q` and `W` check exact lengths. That is right for control-transfer SET_REPORT, but a host
  that delivers commands as a padded 32-byte interrupt-OUT packet would have its `M` and `J` ignored.
  Decide this when the PS5-side transport is known.
- While the speaker is on (`M`), interrupt-OUT packets are audio, not commands. The core only records
  the flag (`speaker_on`); the transport layer must not pass those packets to
  `sky_base_handle_command()`, or sample bytes that look like `W` will overwrite figure data.
- The core now models 16 generic slots; Trap Team labels (Figure/Trap/Item per player) remain a UI mapping, not protocol slot types.
- Links and claims in the sections below about Prospero-Menu, the PS5 SDKs and firmware 13.42 were
  carried over and have not been verified here.

## Trap Team behavior

The reference README describes Trap Team's portal as using the same base protocol as Swap Force, with slot labels `Figure 1`, `Trap 1`, `Item 1`, `Item 2` for each player. The portal core itself has eight generic slots; the labels belong to the user interface, not to the core protocol.

Each figure dump is 1024 bytes (64 blocks of 16 bytes). The core handles portal commands and status packets without depending on Flipper APIs, which makes it suitable for reuse in a different host application.

## Architecture plan

1. Keep the portable SkyBase core separate from platform-specific code.
2. Build a roster/slot model around the user's own dumps under `apps_data/skybase/trap_team/` and, if desired, the read-only bundled asset tree.
3. Investigate integration with a PS5 overlay menu system. Prospero-Menu documents an in-game menu opened with L3 + R3; that may provide the UI entry point, but it does not itself make the game accept virtual portal data.
4. Independently validate how Trap Team's portal USB communication could be provided or intercepted on the PS5.
5. Only then connect selection events from the overlay to the game-compatible portal layer.

## Important limitations

This is **not a PS5 ELF payload**, does not install an overlay, does not hook the controller, and does not make Trap Team recognize figures on its own. It is a tested host-side foundation for the reusable portal state machine. The PS5-specific overlay and game communication path remain to be implemented and verified.

A webpage, payload UI, or menu overlay alone cannot make the PS5's USB host port become a USB peripheral. The primary unresolved technical task is finding a reliable PS5-side way to provide the game's expected portal interface while the game is running.

## Reference projects

- User's reference repository: https://github.com/Space-Raler/All-in-One-Toypad-Emulator
- PS5 SDK (work in progress): https://github.com/PS5Dev/PS5SDK
- PS5 payload SDK: https://github.com/ps5-payload-dev/sdk
- PS5 web server/payload launcher: https://github.com/ps5-payload-dev/websrv
- Prospero-Menu (L3 + R3 overlay menu): https://github.com/StonedModder/Prospero-Menu

The external projects have their own licenses and requirements; inspect them before redistributing or incorporating their code.

## Overlay research update (2026-10-26)

Prospero-Menu is a plausible UI integration target because its documentation says it can show overlays over running games, opens with L3 + R3, and supports program overlays written in C using its SDK. It uses a separate overlay process and a local socket protocol rather than running overlay code inside ShellUI. The project documents firmware profiles through 13.60 but says the current release has only been tested on 13.60 hardware; firmware 13.42 compatibility therefore remains to be tested, not assumed.

This is a UI entry point only. It does not solve the portal-data path into Trap Team. The next major research task is to establish whether a PS5-side mechanism can provide the game's expected portal interface while the game is running. The normal USB ports operate as host ports, so software cannot simply turn the console into the portal peripheral by opening a webpage.


## Switch-reference parity update (2026-10-26)

The core now models 16 slots and emits all four packed slot-status bytes (report bytes 1-4), matching the Switch reference's `kSlots = 16` and `statusReport()` layout. The earlier 8-slot implementation only emitted a 16-bit status mask, so figures in slots 8-15 could not be represented correctly in status reports. Host tests cover slots 8 and 15, plus rapid removal before an arrival is polled. The removal queue now discards stale arrival transitions, matching the Switch reference. This improves protocol-core parity only; it does not solve the PS5 USB transport/virtual-device feasibility question.

## Phase 1 transport audit

`docs/phase1_transport_audit.md` compares the uploaded Flipper and Switch Skylanders portal transport code. It records the descriptor shape, control `SET_REPORT` versus interrupt-OUT differences, and a diagnostic sequence for the previously reported PS5 symptom (descriptor reads but zero endpoint traffic). The cause remains unproven without a real transfer log.

`tools/analyze_portal_debug.py <saved-log.txt>` summarizes a saved text copy of the Switch portal debug page. It is an offline log helper only; it does not capture USB traffic or prove PS5 compatibility. `make test` runs the C core tests and the helper's Python unit tests.


## User-provided Switch USB debug photos (2026-10-26)

See `docs/switch_debug_photo_analysis.md` for a careful comparison of the working and failing screenshots. The final two photos show Game: connected, increasing portal-command and IN-completion counters, and OUT done remaining zero. Earlier photos show no completed transfers or recognized commands alongside repeated transfer errors. Error-code meanings remain unverified; the report does not claim PS5 compatibility.

## Switch vs Flipper parity audit

`docs/switch_vs_flipper_protocol_parity.md` records the source-supported protocol facts and the transport differences that still need verification. It explicitly separates the reusable 16-slot portal core from USB-device transport and PS5 game integration.

## PS5 SDK build workflow research

`docs/ps5_sdk_build_workflow.md` distinguishes the PS5Dev SDK from the `ps5-payload-dev/sdk` dynamic payload SDK and gives a conservative hello-world build gate. No target ELF is claimed as built because no installed SDK checkout/toolchain was present in this workspace. Firmware 13.42 compatibility and the software-only portal transport remain unverified.

## PS5 virtual-portal transport research (2026-10-26)

`docs/ps5_virtual_portal_transport_research.md` records the current decision gate: no documented PS5 SDK route for software-only USB-device emulation was found; game-I/O interception remains a hypothesis requiring firmware-13.42-specific evidence. It separates the SDK hello-world build/load test from actual transport proof and in-game figure recognition. No PS5 payload or transport hook is claimed as implemented.

## PS5 USB-interface research update (2026-10-26)

`docs/ps5_usb_interface_research_update.md` adds a source-backed lead from the public Ghostcontrol PS5 controller payload: it describes raw USB full-speed endpoint access for an external controller and PS5 virtual-controller injection. This is **not** evidence of a generic virtual USB HID device or a Skylanders portal path. The document updates the investigation sequence and lists the evidence still required before any transport implementation.


## PS5 transport source audit — Steps 2 and 3 (2026-10-26)

`docs/ps5_transport_source_audit_step2_step3.md` inspects the public Ghostcontrol USB-FS and virtual-controller paths and defines the minimum evidence required for a real Trap Team transport proof. The audit distinguishes host access to a physical USB controller from a virtual Skylanders portal. The test definition is complete, but its console-side execution is blocked because no target-console trace is available in this workspace.

Reference link requested for the master checklist: https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2

## Latest transport investigation (2026-10-26)

See `docs/ps5_transport_investigation_decision_2026-10-26.md` for the current
route ranking, source links, transport proof criteria, and Linux Mint SDK setup
checks. The main unresolved blocker remains proving a software-only path for
Trap Team to receive portal I/O on PS5 firmware 13.42. Ghostcontrol's USB host
and virtual gamepad mechanisms do not by themselves provide a virtual portal.

## New UI research and prototype (2026-10-26)

See `docs/ui_research_2026-10-26.md` for source-backed findings on PuckbridgePS5, Prospero Explorer, the native PS5 UI toolkit, and firmware caveats. Open `ui-prototype/index.html` in a browser for an interactive launcher/figure-library mockup. It supports local-session file selection, category filters, local slot assignment, and a UI activity log. It does not parse dump contents or communicate with the PS5/portal; connection status is intentionally reported as unimplemented.


## Phase 2 protocol test expansion — 2026-10-26

The portable core tests now sweep all 64 figure blocks with read/write/read-back
checks, validate malformed block-command boundaries, confirm unchanged writes
do not mark a dump dirty, and verify FIFO ordering of selected command replies.
See `docs/phase2_protocol_tests_2026-10-26.md` for exact coverage and results.

Validation: `make test` and `make sanitize` pass on the current host. This is a
host-side protocol-core result only; no PS5 transport or in-game portal
recognition is claimed.

### Phase 2 continued — targeted parity tests (2026-10-26)

The protocol test suite now covers `J` fade semantics, both observed `R` firmware-version byte choices (`0x1B` and `0x18`), padded 32-byte `Q`/`W` reports, block 63, and empty-slot `Q`/`W` reply payloads. Run `make clean && make test && make sanitize` to repeat the host checks. These are portable-core tests; they do not prove USB transport or in-game PS5 recognition.

See `docs/phase2_protocol_tests_2026-10-26.md` and `docs/phase2_reference_parity_matrix_2026-10-26.md`. Exact upstream file-level commit SHAs remain open; do not adapt upstream code until revisions and applicable license obligations are pinned.


### Phase 2 tightening — R reply profile and command length

The core exposes named `SKY_R_PROFILE_DOLPHIN` (`0x1B`) and
`SKY_R_PROFILE_RPCS3` (`0x18`) reply profiles. `sky_base_set_r_profile()`
rejects unknown values rather than allowing accidental undocumented bytes.
The R command accepts a 2-byte payload or a padded 32-byte report; malformed
one-byte R commands are ignored. The default is Dolphin-like for continuity,
not because Trap Team on PS5 has been proven to require that value.

See `docs/phase2_reference_source_lock_2026-10-26.md` for the earlier audit notes. The RPCS3 revision gap noted there is resolved in the newer command comparison: both reference files now have immutable commit URLs. No upstream emulator code has been copied into this project.

### Phase 2 source comparison update — 2026-10-26

See `docs/phase2_source_comparison_2026-10-26.md` for the command-by-command comparison against pinned Dolphin and RPCS3 snapshots. The important integration boundary is that USB control-transfer acknowledgements are separate from interrupt-IN command replies; the portable core currently models only the interrupt-IN packet stream. The transport adapter must implement the USB-level response path. The RPCS3 snapshot is immutable commit `62ab226344735abfee5e5be4c1c3d27ba6724b89` (September 30, 2026), not a claim about the latest master.

- Phase 2 immutable source comparison: `docs/phase2_source_comparison_2026-10-26.md` (Dolphin and RPCS3 pinned source snapshots; documents control-transfer versus interrupt-IN response paths).


### Control-transfer response API (2026-10-26)

`sky_base_handle_control_command()` models the immediate command-data response
separately from queued interrupt-IN replies. Tests cover `A/C/J/L/M/Q/R/S/V/W`,
including `R 00` versus `R 02 <profile>`, padded `M` reports, J side-2 acknowledgement,
and invalid-buffer handling. It is an adapter-facing protocol helper only: USB setup/status
stages, descriptors, endpoint scheduling, PS5 transport, and in-game recognition remain
unimplemented/unverified. Run `make clean && make test && make sanitize`.


## Phase 3 HID adapter contract (2026-10-26)

`src/sky/core/sky_hid_adapter.c` is a platform-neutral adapter boundary. It routes already-decoded SET_REPORT payloads to the core, keeps interrupt-IN packet production separate, and prevents interrupt-OUT audio data from being mistaken for `W`/other commands while speaker mode is enabled. `tests/adapter_test.c` verifies these paths and endpoint checks.

This is not a USB driver or PS5 transport: USB setup packets, descriptors, endpoint registration, transfer scheduling/status stages, and a console-side game-I/O route remain unimplemented. See `docs/phase3_hid_adapter_contract_2026-10-26.md`.

## Decoded USB control-transfer dispatch (2026-10-26)

`src/sky/core/sky_usb_control.c` adds a host-testable dispatcher for the decoded
Dolphin-shaped control request path (`0x21/0x09` command reports and the
`0x0A`/`0x0B` interface requests). It keeps command-data echoes separate from
queued interrupt-IN replies. See `docs/phase3_control_transfer_dispatch_2026-10-26.md`.
This is still not a USB controller/descriptor/status-stage implementation or a
PS5 transport. The SDK bundle's FreeBSD USB headers show host-side USB APIs but
do not prove that device-side gadget mode is available on firmware 13.42.
