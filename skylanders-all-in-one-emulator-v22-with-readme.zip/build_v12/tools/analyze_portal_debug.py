#!/usr/bin/env python3
"""Summarize a saved Switch portal debug log; this does not capture USB traffic."""
import argparse
import re
from pathlib import Path


def find_last_count(text: str, label: str):
    patterns = [
        rf"{re.escape(label)}[ \t]*[:=][ \t]*(\d+)",
        rf"(\d+)[ \t]+{re.escape(label)}",
    ]
    values = []
    for pattern in patterns:
        values.extend(int(m.group(1)) for m in re.finditer(pattern, text, re.I))
    return values[-1] if values else None


def analyze(text: str) -> str:
    low = text.lower()
    lines = []
    in_done = find_last_count(text, "IN done")
    out_done = find_last_count(text, "OUT done")
    commands = find_last_count(text, "portal commands")
    setup_count = len(re.findall(r"SETUP\s+(?:81\s+06|0x81\s+0x06)", text, re.I))
    descriptor_count = len(re.findall(r"(?:report descriptor|v2200)", text, re.I))
    status_fail = bool(re.search(r"status\s+(?:FAILED|fail|error)|ack failed|no completion", text, re.I))

    lines.append("Skylanders portal debug-log summary")
    lines.append("Note: interpretation only; this script does not access USB or the console.")
    lines.append(f"IN done: {in_done if in_done is not None else 'not found'}")
    lines.append(f"OUT done: {out_done if out_done is not None else 'not found'}")
    lines.append(f"portal commands: {commands if commands is not None else 'not found'}")
    lines.append(f"descriptor-fetch clues: {max(setup_count, descriptor_count)}")
    lines.append(f"control status-stage error clue: {'yes' if status_fail else 'not seen'}")

    endpoints_zero = in_done == 0 and out_done == 0
    if endpoints_zero and commands == 0:
        if status_fail:
            lines.append("Assessment: first investigate control-transfer/status-stage completion.")
        elif setup_count or descriptor_count or "configured" in low:
            lines.append("Assessment: enumeration/descriptor handling is visible, but no endpoint traffic is evidenced. Game/interface opening or device matching remains unresolved.")
        else:
            lines.append("Assessment: no endpoint traffic is evidenced; log may be incomplete or the device may not have reached enumeration.")
    elif any(x is not None and x > 0 for x in (in_done, out_done, commands)):
        if commands == 0:
            lines.append("Assessment: some transport activity is visible but no recognized portal commands are evidenced. Inspect packet bytes/lengths and command path.")
        else:
            lines.append("Assessment: portal commands are being recognized; next investigate protocol state and figure data if the game still rejects figures.")
    else:
        lines.append("Assessment: counters are incomplete or not recognized. Include the full debug page/log and exact labels.")
    lines.append("This summary cannot identify the exact cause without raw setup requests, transfer results, and packet bytes.")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("logfile", type=Path, help="saved text log copied from the portal debug screen")
    args = parser.parse_args()
    try:
        text = args.logfile.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        parser.error(str(exc))
    print(analyze(text))


if __name__ == "__main__":
    main()
