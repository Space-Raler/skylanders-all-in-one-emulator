#!/usr/bin/env python3
"""Strict 1024-byte Skylanders figure dump validation and atomic save helpers."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import tempfile

DUMP_SIZE = 1024


class DumpValidationError(ValueError):
    """Raised when a figure dump is not exactly the expected size."""


def validate_dump_bytes(data: bytes) -> bytes:
    if len(data) != DUMP_SIZE:
        raise DumpValidationError(f"expected exactly {DUMP_SIZE} bytes, got {len(data)}")
    return data


def load_dump(path: str | os.PathLike[str]) -> bytes:
    data = Path(path).read_bytes()
    return validate_dump_bytes(data)


def atomic_save_dump(path: str | os.PathLike[str], data: bytes) -> None:
    """Validate and atomically replace a dump using a temp file in the same directory."""
    validate_dump_bytes(data)
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp",
                                     dir=str(destination.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, destination)
        # Best-effort directory sync so the rename is durable on POSIX filesystems.
        try:
            dir_fd = os.open(destination.parent, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError:
            pass
    except BaseException:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dump", type=Path, help="path to a raw 1024-byte dump")
    args = parser.parse_args()
    try:
        data = load_dump(args.dump)
    except (OSError, DumpValidationError) as exc:
        parser.error(str(exc))
    print(f"OK: {args.dump} is exactly {len(data)} bytes")
    print(f"Serial (little-endian block 0 bytes 0..3): {int.from_bytes(data[:4], 'little'):08X}")
    print(f"Toy ID (little-endian block 1 bytes 0..1): {int.from_bytes(data[16:18], 'little'):04X}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
