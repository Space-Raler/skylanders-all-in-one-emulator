#pragma once
/* Reference-shaped control-transfer dispatcher. This models the decoded
 * control request contract seen in Dolphin's SkylanderUSB::SubmitTransfer;
 * it is not a USB controller, setup-stage engine, or PS5 transport. */
#include "sky_hid_adapter.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SKY_USB_CTRL_OK = 0,
    SKY_USB_CTRL_INVALID_ARGUMENT,
    SKY_USB_CTRL_UNSUPPORTED_REQUEST,
    SKY_USB_CTRL_INVALID_LENGTH,
    SKY_USB_CTRL_COMMAND_ERROR,
    SKY_USB_CTRL_RESPONSE_TOO_SMALL
} SkyUsbControlResult;

/* Dispatch a decoded request. `payload` is the OUT data supplied by the host;
 * `response` receives the command-data echo returned by the reference model.
 * `response_len == 0` represents a successful request with no data payload;
 * the platform layer must still complete the USB status stage itself.
 *
 * Supported reference-shaped requests:
 *   bmRequestType=0x21, bRequest=0x09: Skylanders command payload
 *   bmRequestType=0x21, bRequest=0x0A/0x0B: Get/Set Interface control path
 */
SkyUsbControlResult sky_usb_control_dispatch(
    SkyBase *base,
    uint8_t request_type,
    uint8_t request,
    uint16_t value,
    uint16_t index,
    uint16_t w_length,
    const uint8_t *payload,
    size_t payload_len,
    uint8_t *response,
    size_t response_capacity,
    size_t *response_len);

#ifdef __cplusplus
}
#endif
