#include "sky_hid_adapter.h"

SkyControlResult sky_hid_adapter_set_report(
    SkyBase *base, const uint8_t *payload, size_t payload_len,
    uint8_t *response, size_t response_capacity, size_t *response_len) {
    return sky_base_handle_control_command(base, payload, payload_len,
                                           response, response_capacity,
                                           response_len);
}

SkyAdapterResult sky_hid_adapter_interrupt_out(
    SkyBase *base, uint8_t endpoint, const uint8_t *payload, size_t payload_len) {
    if (!base || (!payload && payload_len != 0))
        return SKY_ADAPTER_INVALID_ARGUMENT;
    if (endpoint != SKY_HID_EP_INTERRUPT_OUT)
        return SKY_ADAPTER_WRONG_ENDPOINT;
    if (payload_len == 0)
        return SKY_ADAPTER_IGNORED;
    if (base->speaker_on)
        return SKY_ADAPTER_AUDIO_DATA;
    /* Command reports are dispatched through SET_REPORT, not guessed from an
     * interrupt-OUT payload. This avoids corrupting figure blocks if an audio
     * packet happens to start with 'W' or another recognized command byte. */
    return SKY_ADAPTER_IGNORED;
}

SkyAdapterResult sky_hid_adapter_interrupt_in(
    SkyBase *base, uint8_t endpoint, uint8_t out[SKY_PACKET_SIZE],
    bool *was_command_reply) {
    if (!base || !out || !was_command_reply)
        return SKY_ADAPTER_INVALID_ARGUMENT;
    if (endpoint != SKY_HID_EP_INTERRUPT_IN)
        return SKY_ADAPTER_WRONG_ENDPOINT;
    *was_command_reply = sky_base_next_packet(base, out);
    return SKY_ADAPTER_OK;
}
