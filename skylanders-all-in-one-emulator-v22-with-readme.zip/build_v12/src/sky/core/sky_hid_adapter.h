#pragma once
/* Platform-neutral adapter contract for the SkyBase protocol core.
 * This is NOT a PS5 USB driver: a platform layer must still implement USB
 * descriptors, setup packets, endpoint registration, transfer completion and
 * status-stage behavior using its actual USB APIs. */
#include "sky_core.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SKY_HID_EP_INTERRUPT_OUT 0x02u
#define SKY_HID_EP_INTERRUPT_IN  0x81u

typedef enum {
    SKY_ADAPTER_OK = 0,
    SKY_ADAPTER_INVALID_ARGUMENT,
    SKY_ADAPTER_WRONG_ENDPOINT,
    SKY_ADAPTER_IGNORED,
    SKY_ADAPTER_AUDIO_DATA
} SkyAdapterResult;

/* Dispatch a payload that the platform USB layer has already identified as a
 * HID SET_REPORT command-data stage. Returns the core's immediate response
 * bytes separately from any interrupt-IN reply queued by the command. */
SkyControlResult sky_hid_adapter_set_report(
    SkyBase *base, const uint8_t *payload, size_t payload_len,
    uint8_t *response, size_t response_capacity, size_t *response_len);

/* Dispatch interrupt OUT traffic. When M has enabled the speaker, endpoint 02
 * carries audio samples and MUST NOT be parsed as portal commands: audio bytes
 * can coincidentally begin with command letters such as 'W'. Audio decoding is
 * deliberately left to a platform/audio implementation. When speaker is off,
 * this core does not assume interrupt OUT carries commands and ignores it. */
SkyAdapterResult sky_hid_adapter_interrupt_out(
    SkyBase *base, uint8_t endpoint, const uint8_t *payload, size_t payload_len);

/* Produce one interrupt-IN packet (queued command reply first, then status). */
SkyAdapterResult sky_hid_adapter_interrupt_in(
    SkyBase *base, uint8_t endpoint, uint8_t out[SKY_PACKET_SIZE],
    bool *was_command_reply);

#ifdef __cplusplus
}
#endif
