#include "sky_usb_control.h"

SkyUsbControlResult sky_usb_control_dispatch(
    SkyBase *base,
    uint8_t request_type,
    uint8_t request,
    uint16_t value,
    uint16_t index,
    uint16_t w_length,
    const uint8_t *payload,
    size_t payload_len,
    uint8_t *response,
    size_t response_capacity,
    size_t *response_len) {
    if (!base || !response_len || (!payload && payload_len != 0) ||
        (!response && response_capacity != 0))
        return SKY_USB_CTRL_INVALID_ARGUMENT;

    *response_len = 0;
    if (request_type != 0x21 || index != 0)
        return SKY_USB_CTRL_UNSUPPORTED_REQUEST;

    /* Dolphin's reference path accepts these interface requests and completes
     * them with no data bytes in its transfer abstraction. The real platform
     * must translate this into the appropriate USB status-stage completion. */
    if (request == 0x0A || request == 0x0B) {
        if (w_length != 0 || payload_len != 0 || value != 0)
            return SKY_USB_CTRL_INVALID_LENGTH;
        return SKY_USB_CTRL_OK;
    }

    if (request != 0x09)
        return SKY_USB_CTRL_UNSUPPORTED_REQUEST;
    if (w_length == 0 || payload_len != (size_t)w_length)
        return SKY_USB_CTRL_INVALID_LENGTH;
    if (!response || response_capacity == 0)
        return SKY_USB_CTRL_RESPONSE_TOO_SMALL;

    SkyControlResult core_result = sky_hid_adapter_set_report(
        base, payload, payload_len, response, response_capacity, response_len);
    switch (core_result) {
    case SKY_CONTROL_OK:
        return SKY_USB_CTRL_OK;
    case SKY_CONTROL_BUFFER_TOO_SMALL:
        return SKY_USB_CTRL_RESPONSE_TOO_SMALL;
    case SKY_CONTROL_INVALID_ARGUMENT:
        return SKY_USB_CTRL_INVALID_ARGUMENT;
    case SKY_CONTROL_INVALID_LENGTH:
        return SKY_USB_CTRL_INVALID_LENGTH;
    case SKY_CONTROL_UNSUPPORTED_COMMAND:
    default:
        return SKY_USB_CTRL_COMMAND_ERROR;
    }
}
