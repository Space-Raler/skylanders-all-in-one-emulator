import importlib.util
import unittest
from pathlib import Path

SCRIPT = Path(__file__).parents[1] / "tools" / "analyze_portal_debug.py"
spec = importlib.util.spec_from_file_location("analyze_portal_debug", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class DebugAnalyzerTests(unittest.TestCase):
    def test_descriptor_loop_without_transfers(self):
        log = "state: Configured\nSETUP 81 06 v2200\nSETUP 81 06 v2200\nIN done: 0\nOUT done: 0\nportal commands: 0"
        result = module.analyze(log)
        self.assertIn("no endpoint traffic is evidenced", result)
        self.assertIn("IN done: 0", result)

    def test_status_stage_failure(self):
        log = "report descriptor\nIN done: 0\nOUT done: 0\nportal commands: 0\nstatus FAILED"
        self.assertIn("control-transfer/status-stage completion", module.analyze(log))

    def test_commands_seen(self):
        log = "IN done: 100\nOUT done: 20\nportal commands: 5"
        self.assertIn("portal commands are being recognized", module.analyze(log))


if __name__ == "__main__":
    unittest.main()
