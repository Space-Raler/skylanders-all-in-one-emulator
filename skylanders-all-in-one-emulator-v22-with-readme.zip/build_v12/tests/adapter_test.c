#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "sky_hid_adapter.h"
#include "sky_usb_control.h"

int main(void) {
    SkyBase base;
    sky_base_init(&base);
    uint8_t response[SKY_PACKET_SIZE] = {0};
    size_t response_len = 0;
    uint8_t packet[SKY_PACKET_SIZE] = {0};
    bool was_reply = false;

    /* Reference-shaped control dispatch validates request type and wLength,
     * then keeps the command-data echo separate from the interrupt-IN queue. */
    const uint8_t m_on[] = {'M', 1};
    assert(sky_usb_control_dispatch(&base, 0x21, 0x09, 0x0200, 0,
        sizeof m_on, m_on, sizeof m_on, response, sizeof response,
        &response_len) == SKY_USB_CTRL_OK);
    assert(response_len == 2 && response[0] == 'M' && response[1] == 1);
    assert(base.speaker_on && base.r_count == 1);

    assert(sky_usb_control_dispatch(&base, 0xA1, 0x09, 0, 0,
        sizeof m_on, m_on, sizeof m_on, response, sizeof response,
        &response_len) == SKY_USB_CTRL_UNSUPPORTED_REQUEST);
    assert(sky_usb_control_dispatch(&base, 0x21, 0x09, 0, 0,
        3, m_on, sizeof m_on, response, sizeof response,
        &response_len) == SKY_USB_CTRL_INVALID_LENGTH);
    assert(sky_usb_control_dispatch(&base, 0x21, 0x0A, 0, 0,
        0, NULL, 0, response, sizeof response,
        &response_len) == SKY_USB_CTRL_OK && response_len == 0);
    assert(sky_usb_control_dispatch(&base, 0x21, 0x0B, 0, 0,
        1, m_on, sizeof m_on, response, sizeof response,
        &response_len) == SKY_USB_CTRL_INVALID_LENGTH);
    assert(sky_usb_control_dispatch(&base, 0x21, 0x09, 0, 0,
        sizeof m_on, m_on, sizeof m_on, NULL, 0,
        &response_len) == SKY_USB_CTRL_RESPONSE_TOO_SMALL);

    /* Audio OUT payload intentionally begins with 'W' and contains plausible
     * block data. It must not be interpreted as a figure write. */
    uint8_t audio[19] = {'W', 0, 0};
    memset(audio + 3, 0xA5, 16);
    const uint8_t figure[SKY_FIGURE_SIZE] = {0};
    assert(sky_base_load_figure_at(&base, 0, figure) == 0);
    assert(sky_hid_adapter_interrupt_out(&base, SKY_HID_EP_INTERRUPT_OUT,
        audio, sizeof audio) == SKY_ADAPTER_AUDIO_DATA);
    assert(base.block_writes == 0 && base.r_count == 1);
    assert(base.slots[0].data[3] == 0);

    /* Interrupt-IN consumes the queued M reply, not the control response. */
    assert(sky_hid_adapter_interrupt_in(&base, SKY_HID_EP_INTERRUPT_IN,
        packet, &was_reply) == SKY_ADAPTER_OK);
    assert(was_reply && packet[0] == 'M' && packet[1] == 1 && packet[3] == 0x19);

    /* Reset disables audio routing; unknown interrupt OUT remains ignored. */
    const uint8_t reset[] = {'R', 0};
    assert(sky_hid_adapter_set_report(&base, reset, sizeof reset, response,
        sizeof response, &response_len) == SKY_CONTROL_OK);
    assert(!base.speaker_on);
    assert(sky_hid_adapter_interrupt_out(&base, SKY_HID_EP_INTERRUPT_OUT,
        audio, sizeof audio) == SKY_ADAPTER_IGNORED);
    assert(base.block_writes == 0 && base.slots[0].data[3] == 0);

    assert(sky_hid_adapter_interrupt_in(&base, 0x82, packet, &was_reply) == SKY_ADAPTER_WRONG_ENDPOINT);
    assert(sky_hid_adapter_interrupt_out(&base, 0x83, audio, sizeof audio) == SKY_ADAPTER_WRONG_ENDPOINT);
    assert(sky_hid_adapter_interrupt_in(NULL, SKY_HID_EP_INTERRUPT_IN, packet,
        &was_reply) == SKY_ADAPTER_INVALID_ARGUMENT);
    puts("Sky HID adapter contract tests passed.");
    return 0;
}
