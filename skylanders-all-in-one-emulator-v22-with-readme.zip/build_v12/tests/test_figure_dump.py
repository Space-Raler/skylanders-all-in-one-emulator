import tempfile
import unittest
from pathlib import Path

import importlib.util

SCRIPT = Path(__file__).parents[1] / "tools" / "figure_dump.py"
spec = importlib.util.spec_from_file_location("figure_dump", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
DumpValidationError = module.DumpValidationError
atomic_save_dump = module.atomic_save_dump
load_dump = module.load_dump
validate_dump_bytes = module.validate_dump_bytes


class FigureDumpTests(unittest.TestCase):
    def test_accepts_exactly_1024_bytes(self):
        data = bytes((i % 256 for i in range(1024)))
        self.assertEqual(validate_dump_bytes(data), data)

    def test_rejects_short_and_oversized(self):
        with self.assertRaises(DumpValidationError):
            validate_dump_bytes(b"x" * 1023)
        with self.assertRaises(DumpValidationError):
            validate_dump_bytes(b"x" * 1025)

    def test_load_rejects_wrong_size_and_save_is_atomic(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "figure.sky"
            original = b"A" * 1024
            atomic_save_dump(target, original)
            self.assertEqual(load_dump(target), original)
            with self.assertRaises(DumpValidationError):
                atomic_save_dump(target, b"B" * 1023)
            # Invalid replacement must leave the original file untouched.
            self.assertEqual(target.read_bytes(), original)
            replacement = b"B" * 1024
            atomic_save_dump(target, replacement)
            self.assertEqual(load_dump(target), replacement)
            self.assertEqual(sorted(p.name for p in Path(tmp).iterdir()), ["figure.sky"])

    def test_missing_file_is_not_silently_accepted(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileNotFoundError):
                load_dump(Path(tmp) / "missing.sky")


if __name__ == "__main__":
    unittest.main()
