#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sky_core.h"

static void make_figure(uint8_t data[SKY_FIGURE_SIZE], uint32_t serial, uint16_t type) {
    memset(data, 0, SKY_FIGURE_SIZE);
    data[0] = (uint8_t)serial;
    data[1] = (uint8_t)(serial >> 8);
    data[2] = (uint8_t)(serial >> 16);
    data[3] = (uint8_t)(serial >> 24);
    data[SKY_BLOCK_SIZE] = (uint8_t)type;
    data[SKY_BLOCK_SIZE + 1] = (uint8_t)(type >> 8);
    for (size_t i = 4; i < SKY_FIGURE_SIZE; i++) {
        if (i != SKY_BLOCK_SIZE && i != SKY_BLOCK_SIZE + 1) data[i] = (uint8_t)(i * 13u + serial);
    }
}

static uint8_t take(SkyBase* b, uint8_t pkt[SKY_PACKET_SIZE]) {
    return sky_base_next_packet(b, pkt) ? 1 : 0;
}

/* Drain status packets until a queued reply (or give up). */
static bool next_reply(SkyBase* b, uint8_t pkt[SKY_PACKET_SIZE]) {
    for(int i = 0; i < 80; i++) if(take(b, pkt)) return true;
    return false;
}

static void test_commands(void) {
    SkyBase b;
    uint8_t pkt[SKY_PACKET_SIZE];
    sky_base_init(&b);

    /* 1-byte 'A' (some hosts): exact-size heap buffer so ASan catches an over-read. */
    uint8_t* one = (uint8_t*)malloc(1);
    one[0] = 'A';
    sky_base_handle_command(&b, one, 1);
    free(one);
    assert(next_reply(&b, pkt) && pkt[0] == 0x41 && pkt[1] == 0 && pkt[2] == 0xFF && pkt[3] == 0x77);

    /* 'A' echoes its argument and always activates, even with 0. */
    const uint8_t a1[] = {'A', 1};
    sky_base_handle_command(&b, a1, sizeof a1);
    assert(next_reply(&b, pkt) && pkt[1] == 1 && b.activated);

    /* 'R': firmware reply, then reset (deactivate); the next 'A' re-announces figures. */
    uint8_t fig[SKY_FIGURE_SIZE];
    make_figure(fig, 0xAABBCCDDu, 0x0102u);
    assert(sky_base_load_figure(&b, fig) == 0);
    const uint8_t r[] = {'R', 0};
    sky_base_handle_command(&b, r, sizeof r);
    assert(next_reply(&b, pkt) && pkt[0] == 0x52 && pkt[1] == 0x02 && pkt[2] == 0x1B);
    assert(!b.activated);
    sky_base_handle_command(&b, a1, sizeof a1);
    assert(next_reply(&b, pkt) && b.activated);
    assert(sky_base_slot_present_settled(&b, 0));

    /* Report-ID-prefixed commands (33-byte SET_REPORT) work like plain ones. */
    uint8_t pre[33] = {0};
    pre[1] = 'Q'; pre[2] = 0; pre[3] = 1;
    sky_base_handle_command(&b, pre, sizeof pre);
    assert(next_reply(&b, pkt) && pkt[0] == 'Q' && pkt[1] == 0x10 && pkt[2] == 1);
    assert(memcmp(pkt + 3, fig + SKY_BLOCK_SIZE, SKY_BLOCK_SIZE) == 0);

    /* 'M' speaker flag and reply; 'R' clears it. */
    const uint8_t m1[] = {'M', 1};
    sky_base_handle_command(&b, m1, sizeof m1);
    assert(b.speaker_on && next_reply(&b, pkt) && pkt[0] == 0x4D && pkt[1] == 1 && pkt[3] == 0x19);
    sky_base_handle_command(&b, r, sizeof r);
    assert(!b.speaker_on);
    sky_base_clear_replies(&b);

    /* Lights: 'C' ring colour, 'J' fade (7 bytes, acked), capped fade. */
    const uint8_t c[] = {'C', 1, 2, 3};
    sky_base_handle_command(&b, c, sizeof c);
    assert(b.lights.ring[0] == 1 && b.lights.ring[1] == 2 && b.lights.ring[2] == 3 && b.lights.fade_ms == 0);
    const uint8_t j[] = {'J', 0, 9, 8, 7, 0xFF, 0xFF};
    sky_base_handle_command(&b, j, sizeof j);
    assert(b.lights.fade_ms == SKY_LIGHT_FADE_MAX_MS);
    assert(next_reply(&b, pkt) && pkt[0] == 'J');

    /* Malformed input is ignored: short Q/W, bad slot, bad block, truncated light commands. */
    uint32_t seq = b.lights.seq;
    sky_base_clear_replies(&b);
    const uint8_t bad_q[] = {'Q', 1};
    const uint8_t bad_block[] = {'Q', 0, 0x40};
    const uint8_t short_c[] = {'C', 1, 2};
    const uint8_t short_l[] = {'L', 0, 1};
    sky_base_handle_command(&b, bad_q, sizeof bad_q);
    sky_base_handle_command(&b, bad_block, sizeof bad_block);
    sky_base_handle_command(&b, short_c, sizeof short_c);
    sky_base_handle_command(&b, short_l, sizeof short_l);
    sky_base_handle_command(&b, NULL, 3);
    sky_base_handle_command(&b, c, 0);
    assert(b.r_count == 0 && b.lights.seq == seq);

    /* Q on an empty slot answers "no figure" (no 0x10 flag). */
    const uint8_t q_empty[] = {'Q', 5, 0};
    sky_base_handle_command(&b, q_empty, sizeof q_empty);
    assert(next_reply(&b, pkt) && pkt[1] == 5);
}

static void test_status_flow(void) {
    SkyBase b;
    uint8_t pkt[SKY_PACKET_SIZE], fig[SKY_FIGURE_SIZE];
    sky_base_init(&b);
    make_figure(fig, 0x01020304u, 0x1111u);
    assert(sky_base_load_figure(&b, fig) == 0);

    /* Insertion: status goes 3 (present+changed), then 1 (present). */
    assert(!sky_base_next_packet(&b, pkt) && pkt[0] == 0x53 && (pkt[1] & 3) == 3 && pkt[6] == 1);
    assert(!sky_base_next_packet(&b, pkt) && (pkt[1] & 3) == 1);
    assert(!sky_base_next_packet(&b, pkt) && (pkt[1] & 3) == 1); /* stays present */
    uint8_t counter = pkt[5];
    assert(!sky_base_next_packet(&b, pkt) && pkt[5] == (uint8_t)(counter + 1));

    /* Removal: 2 (gone+changed) then 0; settled presence flips before the game has read it. */
    assert(sky_base_remove_figure(&b, 0));
    assert(!sky_base_remove_figure(&b, 0));
    assert(!sky_base_slot_present_settled(&b, 0));
    assert(!sky_base_next_packet(&b, pkt) && (pkt[1] & 3) == 2);
    assert(!sky_base_next_packet(&b, pkt) && (pkt[1] & 3) == 0);

    /* Remove-before-first-poll suppresses stale arrival transitions. */
    SkyBase rapid;
    sky_base_init(&rapid);
    assert(sky_base_load_figure_at(&rapid, 4, fig) == 4);
    assert(sky_base_remove_figure(&rapid, 4));
    assert(!sky_base_next_packet(&rapid, pkt));
    assert(((pkt[2] >> 0) & 3) == 2); /* slot 4 is low bits of status byte 2 */
    assert(!sky_base_next_packet(&rapid, pkt));
    assert(((pkt[2] >> 0) & 3) == 0);

    /* Slot retention: the same figure goes back to the slot it last used. */
    uint8_t other[SKY_FIGURE_SIZE];
    make_figure(other, 0x0A0B0C0Du, 0x2222u);
    assert(sky_base_load_figure(&b, other) == 0);   /* lowest free slot */
    assert(sky_base_load_figure(&b, fig) == 1);
    assert(sky_base_remove_figure(&b, 0) && sky_base_remove_figure(&b, 1));
    assert(sky_base_load_figure(&b, fig) == 1);     /* remembers slot 1 */

    /* Full portal, bad slots, and a slot-specific load into an occupied slot. */
    SkyBase full;
    sky_base_init(&full);
    for(int i = 0; i < SKY_SLOT_COUNT; i++) {
        uint8_t f[SKY_FIGURE_SIZE];
        make_figure(f, 100u + (uint32_t)i, 5);
        assert(sky_base_load_figure(&full, f) == i);
    }
    assert(sky_base_load_figure(&full, fig) == -1);
    assert(sky_base_load_figure_at(&full, 0, fig) == -1);
    assert(sky_base_load_figure_at(&full, 9, fig) == -1);
    assert(!sky_base_remove_figure(&full, 16) && !sky_base_slot_present(&full, 16));

    /* The real portal status report has four packed bytes for 16 slots. */
    SkyBase wide;
    sky_base_init(&wide);
    uint8_t f8[SKY_FIGURE_SIZE], f15[SKY_FIGURE_SIZE];
    make_figure(f8, 808u, 5);
    make_figure(f15, 1515u, 5);
    assert(sky_base_load_figure_at(&wide, 8, f8) == 8);
    assert(sky_base_load_figure_at(&wide, 15, f15) == 15);
    assert(!sky_base_next_packet(&wide, pkt));
    assert(pkt[0] == 0x53);
    assert((pkt[3] & 0x03) == 0x03); /* slot 8 arrived */
    assert((pkt[4] & 0xC0) == 0xC0); /* slot 15 arrived */
    assert(!sky_base_next_packet(&wide, pkt));
    assert((pkt[3] & 0x03) == 0x01); /* slot 8 present */
    assert((pkt[4] & 0xC0) == 0x40); /* slot 15 present */

    /* High-numbered slots must also support normal figure block reads/writes. */
    const uint8_t q15[] = {'Q', 15, 0};
    sky_base_handle_command(&wide, q15, sizeof q15);
    assert(sky_base_next_packet(&wide, pkt));
    assert(pkt[0] == 'Q' && pkt[1] == 0x1F && pkt[2] == 0);
    assert(memcmp(pkt + 3, f15, SKY_BLOCK_SIZE) == 0);
    uint8_t w15[19] = {'W', 15, 2};
    for(int i = 0; i < SKY_BLOCK_SIZE; i++) w15[3 + i] = (uint8_t)(0xD0 + i);
    sky_base_handle_command(&wide, w15, sizeof w15);
    assert(sky_base_next_packet(&wide, pkt));
    assert(pkt[0] == 'W' && pkt[1] == 0x1F && pkt[2] == 2);
    uint8_t changed15[SKY_FIGURE_SIZE];
    assert(sky_base_take_dirty(&wide, 15, changed15));
    assert(memcmp(changed15 + 2 * SKY_BLOCK_SIZE, w15 + 3, SKY_BLOCK_SIZE) == 0);

    /* Status queue overflow (host not polling) drops the oldest without corrupting state. */
    SkyBase q;
    sky_base_init(&q);
    for(int i = 0; i < 40; i++) {
        assert(sky_base_load_figure_at(&q, 2, fig) == 2);
        assert(sky_base_remove_figure(&q, 2));
    }
    for(int i = 0; i < SKY_STATUS_QUEUE_DEPTH + 4; i++) (void)sky_base_next_packet(&q, pkt);
    assert(!sky_base_slot_present(&q, 2));
}


static void test_reference_block_matrix_and_persistence(void) {
    SkyBase b;
    uint8_t original[SKY_FIGURE_SIZE], pkt[SKY_PACKET_SIZE];
    sky_base_init(&b);
    make_figure(original, 0x78563412u, 0xBEEF);
    uint8_t original_before[SKY_FIGURE_SIZE];
    memcpy(original_before, original, sizeof original_before);
    assert(sky_base_load_figure_at(&b, 0, original) == 0);

    /* Exercise every valid block index (0..63), not just a representative block. */
    for (uint8_t block = 0; block < SKY_BLOCK_COUNT; ++block) {
        const uint8_t q[] = {'Q', 0, block};
        sky_base_handle_command(&b, q, sizeof q);
        assert(sky_base_next_packet(&b, pkt));
        assert(pkt[0] == 'Q' && pkt[1] == 0x10 && pkt[2] == block);
        assert(memcmp(pkt + 3, original + (size_t)block * SKY_BLOCK_SIZE,
                      SKY_BLOCK_SIZE) == 0);

        uint8_t w[19] = {'W', 0, block};
        for (size_t i = 0; i < SKY_BLOCK_SIZE; ++i)
            w[3 + i] = (uint8_t)(0xA5u ^ (uint8_t)(block * 7u + i));
        sky_base_handle_command(&b, w, sizeof w);
        assert(sky_base_next_packet(&b, pkt));
        assert(pkt[0] == 'W' && pkt[1] == 0x10 && pkt[2] == block);
        assert(memcmp(b.slots[0].data + (size_t)block * SKY_BLOCK_SIZE,
                      w + 3, SKY_BLOCK_SIZE) == 0);

        /* Read-after-write proves the changed bytes are visible through Q. */
        sky_base_handle_command(&b, q, sizeof q);
        assert(sky_base_next_packet(&b, pkt));
        assert(pkt[0] == 'Q' && pkt[2] == block);
        assert(memcmp(pkt + 3, w + 3, SKY_BLOCK_SIZE) == 0);
    }
    assert(b.block_writes == SKY_BLOCK_COUNT);
    assert(b.slots[0].dirty);

    /* Dirty export is a copy; it must not modify the caller's original dump. */
    uint8_t saved[SKY_FIGURE_SIZE];
    assert(sky_base_take_dirty(&b, 0, saved));
    assert(memcmp(original, saved, SKY_FIGURE_SIZE) != 0);
    assert(!b.slots[0].dirty);
    assert(!sky_base_take_dirty(&b, 0, saved));
    assert(memcmp(original, original_before, sizeof original) == 0); /* caller-owned source is untouched */
}

static void test_malformed_block_edges_and_idempotent_writes(void) {
    SkyBase b;
    uint8_t fig[SKY_FIGURE_SIZE], pkt[SKY_PACKET_SIZE];
    sky_base_init(&b);
    make_figure(fig, 0x10203040u, 0x1234u);
    assert(sky_base_load_figure_at(&b, 3, fig) == 3);

    /* Exact lengths are required for Q/W, and block 64 is out of range. */
    const uint8_t q_short[] = {'Q', 3};
    const uint8_t q_long[] = {'Q', 3, 1, 0};
    const uint8_t q_bad_block[] = {'Q', 3, SKY_BLOCK_COUNT};
    uint8_t w_short[18] = {'W', 3, 1};
    uint8_t w_long[20] = {'W', 3, 1};
    sky_base_handle_command(&b, q_short, sizeof q_short);
    sky_base_handle_command(&b, q_long, sizeof q_long);
    sky_base_handle_command(&b, q_bad_block, sizeof q_bad_block);
    sky_base_handle_command(&b, w_short, sizeof w_short);
    sky_base_handle_command(&b, w_long, sizeof w_long);
    assert(b.r_count == 0);

    /* A byte-identical write is acknowledged but must not mark dirty or count as a change. */
    uint8_t w_same[19] = {'W', 3, 1};
    memcpy(w_same + 3, fig + SKY_BLOCK_SIZE, SKY_BLOCK_SIZE);
    sky_base_handle_command(&b, w_same, sizeof w_same);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 'W' && pkt[1] == 0x13 && pkt[2] == 1);
    assert(!b.slots[3].dirty && b.block_writes == 0);

    /* A changed write to the last valid block works; an invalid block is ignored. */
    uint8_t w_last[19] = {'W', 3, 63};
    memset(w_last + 3, 0x6D, SKY_BLOCK_SIZE);
    sky_base_handle_command(&b, w_last, sizeof w_last);
    assert(sky_base_next_packet(&b, pkt) && pkt[0] == 'W' && pkt[2] == 63);
    assert(b.slots[3].dirty && b.block_writes == 1);
    sky_base_clear_replies(&b);
    uint8_t w_bad[19] = {'W', 3, 64};
    memset(w_bad + 3, 0x99, SKY_BLOCK_SIZE);
    sky_base_handle_command(&b, w_bad, sizeof w_bad);
    assert(b.r_count == 0 && b.block_writes == 1);
}

static void test_reply_fifo_order_and_reset(void) {
    SkyBase b;
    uint8_t pkt[SKY_PACKET_SIZE];
    sky_base_init(&b);
    const uint8_t a[] = {'A', 0x21};
    const uint8_t m[] = {'M', 1};
    const uint8_t r[] = {'R', 0};
    sky_base_handle_command(&b, a, sizeof a);
    sky_base_handle_command(&b, m, sizeof m);
    sky_base_handle_command(&b, r, sizeof r);
    assert(b.r_count == 3);
    assert(sky_base_next_packet(&b, pkt) && pkt[0] == 0x41 && pkt[1] == 0x21);
    assert(sky_base_next_packet(&b, pkt) && pkt[0] == 0x4D && pkt[1] == 1);
    assert(sky_base_next_packet(&b, pkt) && pkt[0] == 0x52);
    assert(!b.activated && !b.speaker_on && b.r_count == 0);
}


static void test_j_fade_and_r_profile_bytes(void) {
    SkyBase b;
    uint8_t pkt[SKY_PACKET_SIZE];
    sky_base_init(&b);

    /* J is a seven-byte side/RGB/fade command; only side 0 changes ring state. */
    const uint8_t j_ring[] = {'J', 0, 0x12, 0x34, 0x56, 0x45, 0x23};
    sky_base_handle_command(&b, j_ring, sizeof j_ring);
    assert(b.lights.ring[0] == 0x12 && b.lights.ring[1] == 0x34 && b.lights.ring[2] == 0x56);
    assert(b.lights.fade_ms == SKY_LIGHT_FADE_MAX_MS); /* 0x1234 is capped safely */
    assert(b.lights.seq == 1);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 'J');

    /* A valid non-ring side is acknowledged but does not mutate the ring. */
    const uint8_t j_other[] = {'J', 1, 1, 2, 3, 4, 0};
    sky_base_handle_command(&b, j_other, sizeof j_other);
    assert(b.lights.ring[0] == 0x12 && b.lights.ring[1] == 0x34 && b.lights.ring[2] == 0x56);
    assert(b.lights.seq == 1);
    assert(sky_base_next_packet(&b, pkt) && pkt[0] == 'J');

    /* Malformed J must be ignored without queuing an acknowledgement. */
    const uint8_t j_bad[] = {'J', 0, 1, 2, 3, 4};
    sky_base_handle_command(&b, j_bad, sizeof j_bad);
    assert(b.r_count == 0);

    /* R's version byte is a configurable profile choice: default Dolphin-like 0x1B,
       or RPCS3-like 0x18. Do not silently assume one universal upstream reply. */
    const uint8_t r[] = {'R', 0};
    sky_base_handle_command(&b, r, sizeof r);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 0x52 && pkt[1] == 0x02 && pkt[2] == 0x1B);
    assert(sky_base_set_r_profile(&b, SKY_R_PROFILE_RPCS3));
    sky_base_handle_command(&b, r, sizeof r);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 0x52 && pkt[1] == 0x02 && pkt[2] == 0x18);
    assert(!sky_base_set_r_profile(&b, (SkyRProfile)0x44));
    assert(!sky_base_set_r_profile(NULL, SKY_R_PROFILE_DOLPHIN));

    /* Reject malformed R lengths; accept the standard padded report form. */
    const uint8_t r_bad[] = {'R'};
    sky_base_handle_command(&b, r_bad, sizeof r_bad);
    assert(b.r_count == 0);
    uint8_t r32[SKY_PACKET_SIZE] = {'R', 0};
    sky_base_handle_command(&b, r32, sizeof r32);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 0x52 && pkt[2] == SKY_R_PROFILE_RPCS3);
}

static void test_padded_qw_and_empty_slot_replies(void) {
    SkyBase b;
    uint8_t fig[SKY_FIGURE_SIZE], pkt[SKY_PACKET_SIZE];
    uint8_t q32[SKY_PACKET_SIZE] = {'Q', 4, 63};
    uint8_t w32[SKY_PACKET_SIZE] = {'W', 4, 63};
    sky_base_init(&b);
    make_figure(fig, 0xCAFEBABEu, 0x2468u);
    assert(sky_base_load_figure_at(&b, 4, fig) == 4);

    /* Both reference implementations may receive padded 32-byte command reports. */
    sky_base_handle_command(&b, q32, sizeof q32);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 'Q' && pkt[1] == 0x14 && pkt[2] == 63);
    assert(memcmp(pkt + 3, fig + 63 * SKY_BLOCK_SIZE, SKY_BLOCK_SIZE) == 0);

    for (size_t i = 0; i < SKY_BLOCK_SIZE; ++i) w32[3 + i] = (uint8_t)(0xD0 + i);
    sky_base_handle_command(&b, w32, sizeof w32);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 'W' && pkt[1] == 0x14 && pkt[2] == 63);
    assert(memcmp(b.slots[4].data + 63 * SKY_BLOCK_SIZE, w32 + 3, SKY_BLOCK_SIZE) == 0);

    /* Empty slot still acknowledges Q/W with slot number and no payload data. */
    uint8_t q_empty[] = {'Q', 5, 2};
    uint8_t w_empty[19] = {'W', 5, 2};
    memset(w_empty + 3, 0xAA, SKY_BLOCK_SIZE);
    sky_base_handle_command(&b, q_empty, sizeof q_empty);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 'Q' && pkt[1] == 5 && pkt[2] == 2);
    for (int i = 3; i < SKY_PACKET_SIZE; ++i) assert(pkt[i] == 0);
    sky_base_handle_command(&b, w_empty, sizeof w_empty);
    assert(sky_base_next_packet(&b, pkt));
    assert(pkt[0] == 'W' && pkt[1] == 5 && pkt[2] == 2);
    assert(!b.slots[5].dirty && b.block_writes == 1);
}


static void test_control_transfer_responses(void) {
    SkyBase b;
    uint8_t response[SKY_PACKET_SIZE];
    uint8_t interrupt_reply[SKY_PACKET_SIZE];
    size_t response_len = 0;
    sky_base_init(&b);

    /* R has two independent responses: immediate control-stage R 00, then
     * interrupt-IN R 02 <profile>. */
    const uint8_t r[] = {'R', 0};
    assert(sky_base_handle_control_command(&b, r, sizeof r, response,
        sizeof response, &response_len) == SKY_CONTROL_OK);
    assert(response_len == 2 && response[0] == 'R' && response[1] == 0);
    assert(next_reply(&b, interrupt_reply));
    assert(interrupt_reply[0] == 'R' && interrupt_reply[1] == 2 &&
        interrupt_reply[2] == SKY_R_PROFILE_DOLPHIN);

    /* A immediate echo does not consume its separately queued interrupt reply. */
    const uint8_t a[] = {'A', 1};
    assert(sky_base_handle_control_command(&b, a, sizeof a, response,
        sizeof response, &response_len) == SKY_CONTROL_OK);
    assert(response_len == 2 && response[0] == 'A' && response[1] == 1);
    assert(next_reply(&b, interrupt_reply));
    assert(interrupt_reply[0] == 'A' && interrupt_reply[1] == 1 &&
        interrupt_reply[2] == 0xFF && interrupt_reply[3] == 0x77);

    const uint8_t c[] = {'C', 0x12, 0x34, 0x56};
    assert(sky_base_handle_control_command(&b, c, sizeof c, response,
        sizeof response, &response_len) == SKY_CONTROL_OK);
    assert(response_len == 4 && memcmp(response, c, 4) == 0);
    assert(b.r_count == 0); /* C has no interrupt reply. */

    /* Padded M reports return a 2-byte control echo and still enqueue the
     * canonical M interrupt reply (the padding is not part of the command). */
    uint8_t padded_m[SKY_PACKET_SIZE] = {'M', 1};
    assert(sky_base_handle_control_command(&b, padded_m, sizeof padded_m,
        response, sizeof response, &response_len) == SKY_CONTROL_OK);
    assert(response_len == 2 && response[0] == 'M' && response[1] == 1);
    assert(b.speaker_on && next_reply(&b, interrupt_reply));
    assert(interrupt_reply[0] == 'M' && interrupt_reply[1] == 1 && interrupt_reply[3] == 0x19);

    /* J side 2 must be acknowledged even though the current LED renderer only
     * visualizes side 0; control success is not tied to renderer support. */
    const uint8_t j[] = {'J', 2, 9, 8, 7, 0xF4, 0x01};
    uint32_t light_seq = b.lights.seq;
    assert(sky_base_handle_control_command(&b, j, sizeof j, response,
        sizeof response, &response_len) == SKY_CONTROL_OK);
    assert(response_len == sizeof j && memcmp(response, j, sizeof j) == 0);
    assert(b.lights.seq == light_seq);
    assert(next_reply(&b, interrupt_reply) && interrupt_reply[0] == 'J');

    const uint8_t s[] = {'S'};
    assert(sky_base_handle_control_command(&b, s, sizeof s, response,
        sizeof response, &response_len) == SKY_CONTROL_OK);
    assert(response_len == 1 && response[0] == 'S');
    assert(b.r_count == 0); /* status continues through next_packet(). */

    /* A report-ID prefix is stripped for the control response too. */
    const uint8_t prefixed_q[] = {0, 'Q', 0, 3};
    assert(sky_base_handle_control_command(&b, prefixed_q, sizeof prefixed_q,
        response, sizeof response, &response_len) == SKY_CONTROL_OK);
    assert(response_len == 3 && response[0] == 'Q' && response[1] == 0 && response[2] == 3);
    assert(next_reply(&b, interrupt_reply) && interrupt_reply[0] == 'Q');

    /* Malformed commands and undersized output buffers must not mutate state
     * or queue replies. */
    const uint8_t bad_j[] = {'J', 2, 9, 8, 7, 0, 0};
    uint32_t before_seq = b.lights.seq;
    assert(sky_base_handle_control_command(&b, bad_j, 6, response,
        sizeof response, &response_len) == SKY_CONTROL_INVALID_LENGTH);
    assert(b.lights.seq == before_seq && b.r_count == 0);
    assert(sky_base_handle_control_command(&b, a, sizeof a, response, 1,
        &response_len) == SKY_CONTROL_BUFFER_TOO_SMALL);
    assert(response_len == 2 && b.r_count == 0);
    const uint8_t unknown[] = {'X'};
    assert(sky_base_handle_control_command(&b, unknown, sizeof unknown, response,
        sizeof response, &response_len) == SKY_CONTROL_UNSUPPORTED_COMMAND);
    assert(sky_base_handle_control_command(&b, NULL, 0, response,
        sizeof response, &response_len) == SKY_CONTROL_INVALID_ARGUMENT);
}

static void test_reply_queue(void) {
    SkyBase b;
    uint8_t pkt[SKY_PACKET_SIZE];
    sky_base_init(&b);
    const uint8_t q[] = {'Q', 0, 0};
    for(int i = 0; i < SKY_REPLY_QUEUE_DEPTH + 10; i++) sky_base_handle_command(&b, q, sizeof q);
    assert(b.r_count == SKY_REPLY_QUEUE_DEPTH);      /* full: extra replies dropped, no overflow */
    int n = 0;
    while(sky_base_next_packet(&b, pkt)) n++;
    assert(n == SKY_REPLY_QUEUE_DEPTH && b.r_count == 0);
    sky_base_handle_command(&b, q, sizeof q);
    sky_base_clear_replies(&b);
    assert(!sky_base_next_packet(&b, pkt));
}

int main(void) {
    SkyBase base;
    uint8_t figure[SKY_FIGURE_SIZE], packet[SKY_PACKET_SIZE];
    sky_base_init(&base);
    assert(base.fw_version == 0x1B);

    make_figure(figure, 0x12345678u, 0x4321u);
    int slot = sky_base_load_figure_at(&base, 1, figure);
    assert(slot == 1);
    assert(sky_base_slot_present(&base, 1));

    SkySlotInfo info;
    sky_base_slot_info(&base, 1, &info);
    assert(info.present && info.serial == 0x12345678u && info.type_id == 0x4321u);

    /* Drain initial insertion status packets, then check a read-block command. */
    for (int i = 0; i < 4; i++) (void)sky_base_next_packet(&base, packet);
    const uint8_t read_block[] = {'Q', 1, 1};
    sky_base_handle_command(&base, read_block, sizeof(read_block));
    assert(sky_base_next_packet(&base, packet));
    assert(packet[0] == 'Q' && packet[1] == 0x11 && packet[2] == 1);
    assert(memcmp(packet + 3, figure + SKY_BLOCK_SIZE, SKY_BLOCK_SIZE) == 0);

    /* A game write changes the figure and marks the slot dirty. */
    uint8_t write_block[19] = {'W', 1, 1};
    for (int i = 0; i < SKY_BLOCK_SIZE; i++) write_block[3 + i] = (uint8_t)(0xA0 + i);
    sky_base_handle_command(&base, write_block, sizeof(write_block));
    assert(sky_base_next_packet(&base, packet));
    assert(packet[0] == 'W' && packet[1] == 0x11 && packet[2] == 1);
    uint8_t changed[SKY_FIGURE_SIZE];
    assert(sky_base_take_dirty(&base, 1, changed));
    assert(memcmp(changed + SKY_BLOCK_SIZE, write_block + 3, SKY_BLOCK_SIZE) == 0);
    assert(!sky_base_take_dirty(&base, 1, changed));

    assert(sky_base_remove_figure(&base, 1));
    assert(!sky_base_slot_present(&base, 1));
    assert(sky_base_load_figure_at(&base, 1, figure) == 1);

    test_commands();
    test_status_flow();
    test_reply_queue();
    test_control_transfer_responses();
    test_reference_block_matrix_and_persistence();
    test_malformed_block_edges_and_idempotent_writes();
    test_reply_fifo_order_and_reset();
    test_j_fade_and_r_profile_bytes();
    test_padded_qw_and_empty_slot_replies();

    puts("SkyBase core tests passed.");
    return 0;
}
