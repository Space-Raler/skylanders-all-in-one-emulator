"""PS4/PS5 symbol NIDs (verified against printf, malloc and sceKernelLoadStartModule) and the
candidate USB-library function names. The candidate NAMES are assumptions (the PS4 USB library is
believed to mirror libusb-1.0); a name is only confirmed when its NID shows up in the game binary."""
import base64
import hashlib

_SUFFIX = bytes.fromhex("518D64A635DED8C1E6B039B1C3E55230")


def nid(name: str) -> str:
    digest = hashlib.sha1(name.encode() + _SUFFIX).digest()[:8][::-1]
    return base64.b64encode(digest).decode().rstrip("=").replace("/", "-")


_LIBUSB = """Init Exit SetDebug GetDeviceList FreeDeviceList RefDevice UnrefDevice GetBusNumber
GetPortNumber GetDeviceAddress GetDevice GetMaxPacketSize GetDeviceDescriptor
GetActiveConfigDescriptor GetConfigDescriptor FreeConfigDescriptor Open OpenDeviceWithVidPid Close
GetConfiguration SetConfiguration ClaimInterface ReleaseInterface SetInterfaceAltSetting ClearHalt
ResetDevice KernelDriverActive DetachKernelDriver AttachKernelDriver ControlTransfer BulkTransfer
InterruptTransfer AllocTransfer FreeTransfer SubmitTransfer CancelTransfer HandleEvents
HandleEventsTimeout HandleEventsCompleted LockEvents UnlockEvents EventHandlingOk""".split()

CANDIDATES = {"sceUsbd" + n: nid("sceUsbd" + n) for n in _LIBUSB}
