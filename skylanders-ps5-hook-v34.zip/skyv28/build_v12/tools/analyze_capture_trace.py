#!/usr/bin/env python3
"""Analyze an imported SkyPortal JSON/JSONL capture trace; never captures USB itself."""
import argparse
import collections
import json
from pathlib import Path


def load_events(text: str):
    try:
        root = json.loads(text)
    except json.JSONDecodeError:
        root = [json.loads(line) for line in text.splitlines() if line.strip()]
    if isinstance(root, list):
        events = root
    elif isinstance(root, dict) and isinstance(root.get("events"), list):
        events = root["events"]
    elif isinstance(root, dict) and isinstance(root.get("records"), list):
        events = root["records"]
    else:
        raise ValueError("expected an event array or object with events[]/records[]")
    if any(not isinstance(event, dict) for event in events):
        raise ValueError("every event must be a JSON object")
    return events


def payload_hex(event):
    value = event.get("payloadHex", event.get("payload_hex", event.get("hex", event.get("dataHex", event.get("payload", "")))))
    if isinstance(value, list):
        try:
            return bytes(int(item) & 0xFF for item in value).hex()
        except (TypeError, ValueError):
            return ""
    if not isinstance(value, str):
        return ""
    return "".join(ch for ch in value.lower() if ch in "0123456789abcdef")


def analyze_events(events):
    types = collections.Counter(str(e.get("type", e.get("event_type", "unknown"))).lower() for e in events)
    directions = collections.Counter(str(e.get("direction", "unspecified")).lower() for e in events)
    packets = collections.Counter(payload_hex(e) for e in events if payload_hex(e))
    errors = sum(1 for e in events if "error" in str(e.get("type", e.get("event_type", ""))).lower()
                 or str(e.get("status", "")).lower() in {"error", "failed", "stall", "timeout"})
    drops = sum(int(e.get("dropped", e.get("drop_count", 0)) or 0) for e in events
                if str(e.get("type", e.get("event_type", ""))).lower() in {"drop_summary", "drops"})
    lines = [
        "SkyPortal imported capture analysis",
        "This is offline analysis of the supplied file; it does not capture or validate live PS5 traffic.",
        f"Events: {len(events)}",
        f"Events with raw payload: {sum(1 for e in events if payload_hex(e))}",
        f"Error/failed/timeout events: {errors}",
        f"Reported dropped events: {drops}",
        "Event types:",
    ]
    lines.extend(f"  {key}: {value}" for key, value in sorted(types.items()))
    lines.append("Directions:")
    lines.extend(f"  {key}: {value}" for key, value in sorted(directions.items()))
    lines.append("Repeated raw payloads (hex, up to 10):")
    repeated = [(payload, count) for payload, count in packets.most_common() if count > 1][:10]
    lines.extend(f"  {payload}: {count} occurrences" for payload, count in repeated)
    if not any(payload_hex(e) for e in events):
        lines.append("Assessment: metadata-only trace; raw bytes are absent, so protocol commands cannot be inferred from payloads.")
    elif errors or drops:
        lines.append("Assessment: inspect error/drop events and surrounding timestamps before drawing protocol conclusions.")
    else:
        lines.append("Assessment: payload bytes are available for manual protocol comparison; repeated bytes alone do not establish command meaning.")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path, help="JSON or JSONL trace exported by a capture source")
    args = parser.parse_args()
    try:
        events = load_events(args.capture.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    print(analyze_events(events))


if __name__ == "__main__":
    main()
