#!/usr/bin/env python3
"""List which USB-library functions a game binary imports.

Usage: list_usb_imports.py <decrypted-eboot.elf> [--all]
Needs a DECRYPTED ELF (starts with 7F 45 4C 46), e.g. from your own legally dumped copy.
Prints the candidate sceUsbd* functions whose NIDs appear in the binary, plus any library
names mentioning Usb/Hid. --all also prints every NID found, so unknown names can be sent for lookup.
"""
import re
import sys

sys.path.insert(0, __file__.rsplit("/", 1)[0] if "/" in __file__ else ".")
from usb_nids import CANDIDATES  # noqa: E402

NID_RE = re.compile(rb"([A-Za-z0-9+\-]{11})#([A-Za-z0-9+\-])#([A-Za-z0-9+\-])")
LIB_RE = re.compile(rb"lib[A-Za-z0-9_]*(?:Usb|Hid)[A-Za-z0-9_]*(?:\.sprx)?")


def analyze(data: bytes):
    """Return dict: kind ('elf'|'self'|'unknown'), matched {name: nid}, libs, all_nids."""
    kind = "elf" if data[:4] == b"\x7fELF" else "self" if data[:4] == b"\x4f\x15\x3d\x1d" else "unknown"
    all_nids = sorted({m.group(1).decode() for m in NID_RE.finditer(data)})
    by_nid = {v: k for k, v in CANDIDATES.items()}
    matched = {by_nid[n]: n for n in all_nids if n in by_nid}
    libs = sorted({m.group(0).decode() for m in LIB_RE.finditer(data)})
    return {"kind": kind, "matched": matched, "libs": libs, "all_nids": all_nids}


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    with open(argv[1], "rb") as f:
        r = analyze(f.read())
    if r["kind"] == "self":
        print("This is an encrypted SELF. Decrypt it to a plain ELF first (this tool only reads ELF).")
        return 1
    if r["kind"] == "unknown":
        print("Warning: not an ELF file; scanning raw bytes anyway.")
    print(f"NIDs found in binary: {len(r['all_nids'])}")
    print("USB/HID library names:", ", ".join(r["libs"]) or "none found")
    print("Candidate USB functions imported:")
    for name, n in sorted(r["matched"].items()):
        print(f"  {name}  {n}")
    if not r["matched"]:
        print("  none matched: the game may not use these names; rerun with --all and send the output")
    if "--all" in argv:
        print("All NIDs:")
        print("\n".join(r["all_nids"]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
