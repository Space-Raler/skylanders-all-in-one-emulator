#include "sky_ps5_transport.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static void make_setup(uint8_t p[8], uint8_t type, uint8_t req, uint16_t value, uint16_t len) {
    p[0]=type; p[1]=req; p[2]=(uint8_t)value; p[3]=(uint8_t)(value>>8);
    p[4]=0; p[5]=0; p[6]=(uint8_t)len; p[7]=(uint8_t)(len>>8);
}
int main(void) {
    SkyBase base; SkyPs5Transport t; uint8_t setup[8], response[128]; size_t n=0;
    sky_base_init(&base); sky_ps5_transport_init(&t, &base);
    assert(sky_ps5_transport_require_backend(&t)==SKY_PS5_TRANSPORT_NO_BACKEND);
    assert(!t.backend_attached);

    make_setup(setup,0x80,0x06,0x0100,18);
    assert(sky_ps5_transport_setup(&t,setup,NULL,0,response,sizeof response,&n)==SKY_PS5_TRANSPORT_OK);
    assert(n==18 && response[0]==18 && response[1]==1);

    make_setup(setup,0x00,0x05,9,0);
    assert(sky_ps5_transport_setup(&t,setup,NULL,0,response,sizeof response,&n)==SKY_PS5_TRANSPORT_OK);
    assert(t.usb.address==0 && t.usb.address_pending);
    assert(sky_ps5_transport_status_failed(&t)==SKY_PS5_TRANSPORT_OK);
    assert(t.usb.address==0 && !t.usb.address_pending);

    make_setup(setup,0x00,0x05,4,0);
    assert(sky_ps5_transport_setup(&t,setup,NULL,0,response,sizeof response,&n)==SKY_PS5_TRANSPORT_OK);
    assert(sky_ps5_transport_status_ok(&t)==SKY_PS5_TRANSPORT_OK);
    assert(t.usb.address==4 && !t.usb.address_pending);

    SkyPs5TransportEvent events[8];
    size_t got=sky_ps5_transport_trace_read(&t,0,events,8);
    assert(got==6);
    assert(events[0].type==SKY_PS5_EVENT_BACKEND_MISSING);
    assert(events[1].type==SKY_PS5_EVENT_SETUP && events[1].request==0x06);
    assert(events[2].type==SKY_PS5_EVENT_SETUP && events[2].request==0x05);
    assert(events[3].type==SKY_PS5_EVENT_STATUS_FAILED);
    assert(events[4].type==SKY_PS5_EVENT_SETUP && events[4].request==0x05);
    assert(events[5].type==SKY_PS5_EVENT_STATUS_OK);
    sky_ps5_transport_trace_clear(&t);
    assert(sky_ps5_transport_trace_read(&t,0,events,8)==0);
    puts("PS5 transport adapter contract tests passed (host model only)");
    return 0;
}
