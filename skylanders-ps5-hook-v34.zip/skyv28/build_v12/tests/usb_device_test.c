#include "sky_usb_device.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static void setup(uint8_t p[8], uint8_t type, uint8_t req, uint16_t value, uint16_t index, uint16_t len) {
    p[0]=type; p[1]=req; p[2]=(uint8_t)value; p[3]=(uint8_t)(value>>8);
    p[4]=(uint8_t)index; p[5]=(uint8_t)(index>>8); p[6]=(uint8_t)len; p[7]=(uint8_t)(len>>8);
}
int main(void) {
    SkyUsbDevice d; SkyBase base; uint8_t s[8], out[128]; size_t n=99;
    sky_usb_device_init(&d); sky_base_init(&base);

    setup(s,0x80,0x06,0x0100,0,18); /* GET_DESCRIPTOR device */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK);
    assert(n==18 && out[0]==18 && out[1]==1 && out[8]==0x30 && out[9]==0x14);
    assert(out[10]==0x50 && out[11]==0x01);

    setup(s,0x80,0x06,0x0200,0,9); /* short config header */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK);
    assert(n==9 && out[2]==41 && out[4]==1);

    setup(s,0x81,0x06,0x2200,0,64); /* HID report descriptor */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK);
    assert(n==SKY_USB_REPORT_DESCRIPTOR_SIZE && out[0]==0x06 && out[20]==0x81);

    uint8_t packet[SKY_PACKET_SIZE]; bool is_reply=false;
    assert(sky_usb_device_interrupt_in(&d,&base,SKY_USB_EP_IN,packet,&is_reply)==SKY_USB_DEVICE_NOT_CONFIGURED);

    setup(s,0x00,0x05,7,0,0); /* SET_ADDRESS */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK);
    assert(d.address==0 && d.address_pending && n==0);
    sky_usb_device_complete_status(&d,&base);
    assert(d.address==7 && !d.address_pending);
    setup(s,0x00,0x09,1,0,0); /* SET_CONFIGURATION */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK);
    assert(!d.configured && d.configuration==0 && d.configuration_pending);
    sky_usb_device_complete_status(&d,&base);
    assert(d.configured && d.configuration==1 && !d.configuration_pending);
    setup(s,0x80,0x08,0,0,1); /* GET_CONFIGURATION */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK);
    assert(n==1 && out[0]==1);
    assert(sky_usb_device_interrupt_in(&d,&base,SKY_USB_EP_IN,packet,&is_reply)==SKY_USB_DEVICE_OK);
    assert(sky_usb_device_interrupt_in(&d,&base,0x82,packet,&is_reply)==SKY_USB_DEVICE_WRONG_ENDPOINT);

    setup(s,0x80,0x06,0x9900,0,16);
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_STALL);
    assert(d.setup_count==7 && d.descriptor_count==3 && d.unsupported_count==1);

    /* HID class housekeeping seen in the working Switch trace (SETUP 21 0A ... acked) */
    setup(s,0x21,0x0A,0,0,0); /* SET_IDLE */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK && n==0);
    setup(s,0xA1,0x02,0,0,1); /* GET_IDLE */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK && n==1 && out[0]==0);
    setup(s,0xA1,0x03,0,0,1); /* GET_PROTOCOL */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK && n==1 && out[0]==1);
    setup(s,0xA1,0x01,0x0100,0,32); /* GET_REPORT */
    assert(sky_usb_device_setup(&d,&base,s,NULL,0,out,sizeof out,&n)==SKY_USB_DEVICE_OK && n==32 && out[0]==0x53);

    puts("USB device enumeration tests passed");
    return 0;
}
