/* Fake "game" + fake original USB library + fake import slots. Verifies that the hook installs
 * all-or-nothing, shows the virtual portal next to a real device, passes real traffic through
 * untouched, and restores the slots on uninstall. Host model only. */
#include "sky_libusb_hook.h"
#include "sky_hook_nids.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct desc { uint8_t bLength, bDescriptorType; uint16_t bcdUSB; uint8_t c, s, p, mps; uint16_t vid, pid, bcd; uint8_t i1, i2, i3, nc; };
struct xfer { void *dev_handle; uint8_t flags; unsigned char endpoint, type; unsigned int timeout; int status, length, actual_length;
              void (*callback)(struct xfer *); void *user_data; unsigned char *buffer; int num_iso_packets; };

/* ---- fake original library: one real device (VID 0x1234) ---- */
static int real_dev, real_handle, free_calls, real_interrupt_calls, real_events_calls, real_submit_calls;
static void **real_list_seen;
static ptrdiff_t f_get_list(void *c, void ***l) { (void)c; void **a = malloc(2 * sizeof *a); a[0] = &real_dev; a[1] = NULL; *l = a; return 1; }
static void f_free_list(void **l, int u) { (void)u; free_calls++; real_list_seen = l; free(l); }
static int f_get_desc(void *d, struct desc *o) { assert(d == &real_dev); memset(o, 0, sizeof *o); o->vid = 0x1234; o->pid = 0x5678; return 0; }
static int f_open(void *d, void **h) { assert(d == &real_dev); *h = &real_handle; return 0; }
static void f_close(void *h) { assert(h == &real_handle); }
static int f_claim(void *h, int n) { (void)n; assert(h == &real_handle); return 0; }
static int f_release(void *h, int n) { (void)n; assert(h == &real_handle); return 0; }
static int f_interrupt(void *h, unsigned char ep, unsigned char *d, int len, int *t, unsigned to) { (void)ep; (void)d; (void)to; assert(h == &real_handle); *t = len; real_interrupt_calls++; return 77; }
static int f_submit(struct xfer *t) { (void)t; real_submit_calls++; return 0; }
static int f_events(void *c) { (void)c; real_events_calls++; return 0; }

/* ---- fake import slots (the "GOT") ---- */
#define NSLOT 16
static SkyFn got[NSLOT]; static const char *got_nid[NSLOT]; static int got_n;
static SkyFn *find_slot(void *ctx, const char *nid) { (void)ctx; for (int i = 0; i < got_n; i++) if (!strcmp(got_nid[i], nid)) return &got[i]; return NULL; }
static const char *nid_for(const char *name) { for (size_t i = 0; i < SKY_HOOK_NID_COUNT; i++) if (!strcmp(sky_hook_nids[i].name, name)) return sky_hook_nids[i].nid; return NULL; }
static void add_import(const char *name, SkyFn fn) { got_nid[got_n] = nid_for(name); assert(got_nid[got_n]); got[got_n++] = fn; }
#define SLOT(name) (*find_slot(NULL, nid_for(name)))

static void setup_game(bool with_free_list) {
    got_n = 0; memset(got, 0, sizeof got);
    add_import("sceUsbdGetDeviceList", (SkyFn)f_get_list);
    if (with_free_list) add_import("sceUsbdFreeDeviceList", (SkyFn)f_free_list);
    add_import("sceUsbdGetDeviceDescriptor", (SkyFn)f_get_desc);
    add_import("sceUsbdOpen", (SkyFn)f_open); add_import("sceUsbdClose", (SkyFn)f_close);
    add_import("sceUsbdClaimInterface", (SkyFn)f_claim); add_import("sceUsbdReleaseInterface", (SkyFn)f_release);
    add_import("sceUsbdInterruptTransfer", (SkyFn)f_interrupt); add_import("sceUsbdSubmitTransfer", (SkyFn)f_submit);
    add_import("sceUsbdHandleEvents", (SkyFn)f_events);
}

static int cb_count; static void on_done(struct xfer *t) { (void)t; cb_count++; }

int main(void) {
    SkyBase base; SkyUsbShim shim; SkyHookState st; SkyHookEntry e[SKY_HOOK_MAX]; size_t patched = 0;
    SkyHookPlatform plat = { NULL, find_slot };
    sky_base_init(&base); skyusb_init(&shim, &base);
    size_t n = sky_libusb_hook_build_entries(e, SKY_HOOK_MAX); assert(n > 10);
    for (size_t i = 0; i < n; i++) assert(e[i].nid && e[i].replacement);

    /* all-or-nothing: a game missing a required function (FreeDeviceList) is left untouched */
    setup_game(false); SkyFn before[NSLOT]; memcpy(before, got, sizeof got);
    assert(sky_hook_install(&st, &plat, e, n, &patched) == SKY_HOOK_MISSING_REQUIRED && patched == 0);
    assert(!memcmp(before, got, sizeof got) && !st.installed);

    /* normal install */
    setup_game(true); memcpy(before, got, sizeof got);
    assert(sky_libusb_hook_attach(&shim) == SKYUSB_OK);
    assert(sky_hook_install(&st, &plat, e, n, &patched) == SKY_HOOK_OK && patched == (size_t)got_n);
    assert(sky_hook_install(&st, &plat, e, n, &patched) == SKY_HOOK_ALREADY_INSTALLED);
    for (int i = 0; i < got_n; i++) assert(got[i] != before[i]);

    /* the game's view: real + virtual device in one list */
    void **list = NULL;
    ptrdiff_t cnt = ((ptrdiff_t (*)(void *, void ***))SLOT("sceUsbdGetDeviceList"))(NULL, &list);
    assert(cnt == 2 && list[0] == &real_dev && list[2] == NULL && list[1] != NULL);
    struct desc d;
    assert(((int (*)(void *, struct desc *))SLOT("sceUsbdGetDeviceDescriptor"))(list[1], &d) == 0 && d.vid == 0x1430 && d.pid == 0x0150);
    assert(((int (*)(void *, struct desc *))SLOT("sceUsbdGetDeviceDescriptor"))(list[0], &d) == 0 && d.vid == 0x1234);   /* passthrough */

    /* real device traffic passes through untouched */
    void *rh = NULL, *vh = NULL; int tr = 0; unsigned char buf[32];
    assert(((int (*)(void *, void **))SLOT("sceUsbdOpen"))(list[0], &rh) == 0 && rh == &real_handle);
    assert(((int (*)(void *, unsigned char, unsigned char *, int, int *, unsigned))SLOT("sceUsbdInterruptTransfer"))(rh, 0x81, buf, 32, &tr, 0) == 77);
    assert(real_interrupt_calls == 1);

    /* virtual portal: open, claim, command, reply */
    assert(((int (*)(void *, void **))SLOT("sceUsbdOpen"))(list[1], &vh) == 0 && vh != NULL && vh != rh);
    assert(((int (*)(void *, int))SLOT("sceUsbdClaimInterface"))(vh, 0) == 0);
    assert(real_interrupt_calls == 1);
    assert(((int (*)(void *, unsigned char, unsigned char *, int, int *, unsigned))SLOT("sceUsbdInterruptTransfer"))(vh, 0x81, buf, 32, &tr, 0) == 0 && tr == 32 && buf[0] == 0x53);
    assert(real_interrupt_calls == 1);                                   /* never reached the real library */

    /* async transfer on the virtual handle completes in handle_events, without calling the real one */
    unsigned char ibuf[32];
    struct xfer t = { .dev_handle = vh, .endpoint = 0x81, .type = 3, .length = 32, .buffer = ibuf, .callback = on_done };
    assert(((int (*)(struct xfer *))SLOT("sceUsbdSubmitTransfer"))(&t) == 0 && real_submit_calls == 0);
    assert(((int (*)(void *))SLOT("sceUsbdHandleEvents"))(NULL) == 0);
    assert(cb_count == 1 && t.status == 0 && t.actual_length == 32 && ibuf[0] == 0x53 && real_events_calls == 0);
    /* with nothing virtual pending, handle_events reaches the real library */
    ((int (*)(void *))SLOT("sceUsbdHandleEvents"))(NULL); assert(real_events_calls == 1);
    /* a real transfer is passed through */
    struct xfer rt = { .dev_handle = &real_handle }; ((int (*)(struct xfer *))SLOT("sceUsbdSubmitTransfer"))(&rt); assert(real_submit_calls == 1);

    /* closing, freeing the list: our array freed, real list handed back to the real library */
    ((void (*)(void *))SLOT("sceUsbdClose"))(vh); ((void (*)(void *))SLOT("sceUsbdClose"))(rh);
    ((void (*)(void **, int))SLOT("sceUsbdFreeDeviceList"))(list, 1);
    assert(free_calls == 1);

    /* unplug: the virtual device disappears from new lists */
    skyusb_detach(&shim);
    cnt = ((ptrdiff_t (*)(void *, void ***))SLOT("sceUsbdGetDeviceList"))(NULL, &list); assert(cnt == 1);
    ((void (*)(void **, int))SLOT("sceUsbdFreeDeviceList"))(list, 1); assert(free_calls == 2);

    /* uninstall restores every slot */
    sky_hook_uninstall(&st);
    assert(!memcmp(before, got, sizeof got) && !st.installed);

    puts("USB hook layer tests passed (host model only)");
    return 0;
}
