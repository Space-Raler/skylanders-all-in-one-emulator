import importlib.util
import unittest
from pathlib import Path

SCRIPT = Path(__file__).parents[1] / "tools" / "analyze_capture_trace.py"
spec = importlib.util.spec_from_file_location("analyze_capture_trace", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class CaptureTraceTests(unittest.TestCase):
    def test_json_object_with_events(self):
        events = module.load_events('{"events":[{"type":"host_out","direction":"host-to-portal","payloadHex":"01 02"},{"type":"portal_in","direction":"portal-to-host","payload_hex":"0102"}]}')
        result = module.analyze_events(events)
        self.assertIn("Events: 2", result)
        self.assertIn("0102: 2 occurrences", result)

    def test_jsonl_and_byte_array(self):
        events = module.load_events('{"type":"setup","payload":[1,2]}\n{"type":"usb_error","status":"failed"}')
        self.assertEqual(len(events), 2)
        self.assertIn("inspect error/drop events", module.analyze_events(events))

    def test_drop_count_reported(self):
        result = module.analyze_events([{"type": "drop_summary", "drop_count": 4}])
        self.assertIn("Reported dropped events: 4", result)

    def test_invalid_root(self):
        with self.assertRaises(ValueError):
            module.load_events('{"hello":"world"}')


if __name__ == "__main__":
    unittest.main()
