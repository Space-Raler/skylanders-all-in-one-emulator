/* Plays the part of a game talking to a USB library: enumerate, open, claim,
 * control + interrupt traffic, async transfers. Host model only. */
#include "sky_usbd_shim.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static int g_cb_count, g_last_status, g_last_len;
static void on_done(SkyUsbTransfer *t) { g_cb_count++; g_last_status = t->status; g_last_len = t->actual_length; }

static void send_cmd(SkyUsbShim *s, const uint8_t *cmd, uint16_t n) {
    uint8_t buf[32] = {0};
    memcpy(buf, cmd, n);
    assert(skyusb_control_transfer(s, 0x21, 0x09, 0x0200, 0, buf, 32) == 32);   /* HID SET_REPORT */
}

int main(void) {
    SkyBase base; SkyUsbShim s; uint8_t d[64], rep[32]; int got = 0;
    sky_base_init(&base); skyusb_init(&s, &base);

    /* nothing works before the device is attached */
    assert(!skyusb_find_device(&s, SKY_USB_VID, SKY_USB_PID));
    assert(skyusb_open(&s) == SKYUSB_ERROR_NO_DEVICE);
    assert(skyusb_attach(&s) == SKYUSB_OK);

    assert(skyusb_find_device(&s, 0x1430, 0x0150) && !skyusb_find_device(&s, 0x1430, 0x0151));
    assert(skyusb_get_device_descriptor(&s, d) == SKYUSB_OK && d[8] == 0x30 && d[9] == 0x14 && d[10] == 0x50 && d[11] == 0x01);
    assert(skyusb_open(&s) == SKYUSB_OK);
    assert(skyusb_claim_interface(&s, 1) == SKYUSB_ERROR_NOT_FOUND);
    assert(skyusb_interrupt_transfer(&s, 0x81, rep, 32, &got) == SKYUSB_ERROR_NO_DEVICE); /* not claimed yet */
    assert(skyusb_claim_interface(&s, 0) == SKYUSB_OK && skyusb_claim_interface(&s, 0) == SKYUSB_ERROR_BUSY);

    /* HID descriptors */
    assert(skyusb_control_transfer(&s, 0x81, 0x06, 0x2200, 0, d, 64) == 29);
    assert(skyusb_control_transfer(&s, 0x81, 0x06, 0x2100, 0, d, 64) == 9);
    assert(skyusb_control_transfer(&s, 0x80, 0x06, 0x0900, 0, d, 64) == SKYUSB_ERROR_PIPE); /* bad descriptor stalls */

    /* class housekeeping a HID host sends before polling */
    assert(skyusb_control_transfer(&s, 0x21, 0x0A, 0, 0, NULL, 0) == 0);          /* SET_IDLE */
    assert(skyusb_control_transfer(&s, 0xA1, 0x01, 0x0100, 0, d, 32) == 32 && d[0] == 0x53);

    /* load a figure, game polls status */
    uint8_t fig[SKY_FIGURE_SIZE]; for (int i = 0; i < SKY_FIGURE_SIZE; i++) fig[i] = (uint8_t)(i * 3 + 1);
    fig[0] = 9; fig[1] = fig[2] = fig[3] = 0;
    assert(sky_base_load_figure(&base, fig) == 0);
    assert(skyusb_interrupt_transfer(&s, 0x81, rep, 32, &got) == SKYUSB_OK && got == 32 && rep[0] == 0x53);

    /* command reply arrives on interrupt IN: Q block 3 of slot 0 */
    { uint8_t q[3] = {'Q', 0x20, 3}; send_cmd(&s, q, 3); }
    assert(skyusb_interrupt_transfer(&s, 0x81, rep, 32, &got) == SKYUSB_OK);
    assert(rep[0] == 'Q' && rep[1] == 0x10 && rep[2] == 3 && memcmp(rep + 3, fig + 48, 16) == 0);

    /* write a block and read it back */
    { uint8_t w[19] = {'W', 0, 5}; for (int i = 0; i < 16; i++) w[3 + i] = (uint8_t)(0xC0 + i); send_cmd(&s, w, 19); }
    assert(skyusb_interrupt_transfer(&s, 0x81, rep, 32, &got) == SKYUSB_OK && rep[0] == 'W' && rep[1] == 0x10);
    assert(base.slots[0].data[80] == 0xC0 && base.slots[0].dirty);

    /* interrupt OUT is accepted (ACKed) even when the core ignores it */
    { uint8_t out[32] = {'W', 0, 6}; assert(skyusb_interrupt_transfer(&s, 0x02, out, 32, &got) == SKYUSB_OK && got == 32); }
    assert(skyusb_interrupt_transfer(&s, 0x03, rep, 32, &got) == SKYUSB_ERROR_INVALID_PARAM);

    /* async: one control (SET_REPORT 'R') + one interrupt IN */
    { uint8_t cbuf[8 + 32] = {0x21, 0x09, 0x00, 0x02, 0, 0, 32, 0, 'R'};
      uint8_t ibuf[32];
      SkyUsbTransfer c = { .type = SKYUSB_TRANSFER_CONTROL, .buffer = cbuf, .length = sizeof cbuf, .callback = on_done };
      SkyUsbTransfer in = { .type = SKYUSB_TRANSFER_INTERRUPT, .endpoint = 0x81, .buffer = ibuf, .length = 32, .callback = on_done };
      g_cb_count = 0;
      assert(skyusb_submit_transfer(&s, &c) == SKYUSB_OK && skyusb_submit_transfer(&s, &in) == SKYUSB_OK);
      assert(skyusb_submit_transfer(&s, &in) == SKYUSB_ERROR_BUSY);
      assert(skyusb_handle_events(&s) == SKYUSB_OK);
      assert(g_cb_count == 2 && in.status == SKYUSB_STATUS_COMPLETED && in.actual_length == 32 && ibuf[0] == 0x52); /* R reply */
      assert(c.status == SKYUSB_STATUS_COMPLETED && c.actual_length == 32);
      /* cancel */
      g_cb_count = 0;
      assert(skyusb_submit_transfer(&s, &in) == SKYUSB_OK && skyusb_cancel_transfer(&s, &in) == SKYUSB_OK);
      skyusb_handle_events(&s);
      assert(g_cb_count == 1 && g_last_status == SKYUSB_STATUS_CANCELLED);
      /* unplug with a transfer pending */
      assert(skyusb_submit_transfer(&s, &in) == SKYUSB_OK);
      skyusb_detach(&s);
      skyusb_handle_events(&s);
      assert(in.status == SKYUSB_STATUS_NO_DEVICE);
      assert(skyusb_open(&s) == SKYUSB_ERROR_NO_DEVICE);
      /* re-plug works and keeps the figure */
      assert(skyusb_attach(&s) == SKYUSB_OK && skyusb_open(&s) == SKYUSB_OK && skyusb_claim_interface(&s, 0) == SKYUSB_OK);
      assert(sky_base_slot_present(&base, 0)); }

    /* long run does not exhaust the debug trace */
    for (int i = 0; i < 500; i++) assert(skyusb_interrupt_transfer(&s, 0x81, rep, 32, &got) == SKYUSB_OK);

    (void)g_last_len;
    puts("USB shim tests passed (host model only)");
    return 0;
}
