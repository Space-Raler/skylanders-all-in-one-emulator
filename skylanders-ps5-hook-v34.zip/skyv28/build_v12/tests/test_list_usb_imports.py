import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
from usb_nids import nid, CANDIDATES
from list_usb_imports import analyze


class UsbNidTests(unittest.TestCase):
    def test_nid_algorithm_known_values(self):
        self.assertEqual(nid("printf"), "hcuQgD53UxM")
        self.assertEqual(nid("malloc"), "gQX+4GDQjpM")
        self.assertEqual(nid("sceKernelLoadStartModule"), "wzvqT4UqKX8")

    def test_candidates_unique(self):
        self.assertEqual(len(set(CANDIDATES.values())), len(CANDIDATES))

    def test_finds_usb_imports_in_fake_elf(self):
        blob = b"\x7fELF" + b"\0" * 12
        for name in ("sceUsbdOpen", "sceUsbdInterruptTransfer"):
            blob += (CANDIDATES[name] + "#A#B").encode() + b"\0"
        blob += b"hcuQgD53UxM#A#B\0libSceUsbd.sprx\0"
        r = analyze(blob)
        self.assertEqual(r["kind"], "elf")
        self.assertEqual(sorted(r["matched"]), ["sceUsbdInterruptTransfer", "sceUsbdOpen"])
        self.assertIn("libSceUsbd.sprx", r["libs"])
        self.assertIn("hcuQgD53UxM", r["all_nids"])

    def test_detects_encrypted_self_and_empty(self):
        self.assertEqual(analyze(b"\x4f\x15\x3d\x1d" + b"\0" * 8)["kind"], "self")
        self.assertEqual(analyze(b"")["matched"], {})


if __name__ == "__main__":
    unittest.main()
