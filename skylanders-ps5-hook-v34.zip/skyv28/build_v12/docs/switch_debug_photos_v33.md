# Switch portal USB-debug photos (IMG_4765, IMG_4766) — what they establish

Both photos show the Switch-as-portal app's USB debug page with the host console linked
(high speed) and "Game: connected". Readings are from blurry phone photos; digits can be off by one.

| Counter | Photo A | Photo B |
|---|---|---|
| state / speed | Configured / high | Configured / high |
| configured N times | 1 | 2 |
| errors | 0 (last 0x0) | 1 (last 0x828C) |
| setup requests | 278 | 417 |
| IN done | 281 | 2773 |
| OUT done | 0 | 0 |
| raw events | setup 278, IN 281, OUT 0 | setup 417, IN 2774, OUT 1 |
| portal commands / unknown | 276 / 0 | 413 / 0 |
| status reports | 278 | 2758 |
| last command | `C 2B D0` | `J 02 00` |

Log pane: `SETUP 21 09 ...` lines each followed by "received+status" (command accepted, status
stage done), and `SETUP 21 0A ...` (SET_IDLE) followed by "acked".

## What this shows
1. **The game sends portal commands as HID SET_REPORT control requests** (`21 09`). Setup requests
   ≈ portal commands in both photos (278/276, 417/413), and "unknown" stays 0.
2. **Interrupt OUT is not used for commands.** OUT done is 0 in both photos (one raw OUT event in B
   did not complete). The shim's choice to ACK OUT without treating it as a command matches this.
3. **The game polls interrupt IN continuously** (thousands of completions) and the replies are
   mostly status packets, so the IN path needs the same "queued reply, else status" rule.
4. **The host sends SET_IDLE (`21 0A`) and expects it acknowledged.** The device model stalled every
   class request except SET_REPORT; v33 now acknowledges SET_IDLE/SET_PROTOCOL and answers
   GET_REPORT/GET_IDLE/GET_PROTOCOL. A stalled SET_IDLE is a plausible contributor to the earlier
   "descriptors read, no traffic" symptom, but that is a hypothesis, not proven.

## What it does not show
- The photos do not say which console or game this was. I assumed the PS5 + Trap Team setup in
  PROJECT_CHECKLIST.txt; if it was another console, items 1-4 still describe that host only.
- It is a Switch acting as the USB device. It says nothing about how the PS5 console would let a
  PS4 title talk to a software portal, which remains the unsolved hook.
- Error 0x828C is unexplained.
