# PS5 transport adapter — V28

## What was implemented

`src/sky/core/sky_ps5_transport.{h,c}` is the boundary between a future firmware-specific/game-I/O backend and the portable USB device model. It provides:

- one entry point for forwarding an observed 8-byte SETUP packet plus its OUT data stage;
- explicit success/failure status-stage calls so deferred address/configuration state is committed only on success;
- interrupt-IN and interrupt-OUT forwarding into the existing HID adapter;
- a bounded 64-event trace containing event sequence, result, byte count, endpoint, and request number;
- an explicit `SKY_PS5_TRANSPORT_NO_BACKEND` result when no target backend has been attached;
- host tests for descriptor forwarding, successful and failed status stages, and trace ordering.

## What this is not

This is an adapter contract, **not a working PS5 transport backend**. It does not hook the PS4 title, intercept kernel/userland calls, make the PS5 USB host port act as a device, create a gadget, or access a physical USB bus. No verified firmware 13.42 API or game-facing USB call path has been found yet. The project must not set `backend_attached` merely to silence the diagnostic; a real backend must be evidenced and tested first.

## Backend contract

A future backend must:

1. identify the exact game/service USB I/O boundary and ABI on the target firmware;
2. capture setup/data/status events without changing behavior at first;
3. only after read-only observation succeeds, route setup packets to `sky_ps5_transport_setup`;
4. pass the real control-transfer result to `sky_ps5_transport_status_ok` or `_status_failed`;
5. forward interrupt endpoint operations to the corresponding adapter functions;
6. log repeated trials and show the game consumes responses without retry loops.

No guessed offsets, syscall IDs, or firmware-specific function pointers are included.

## Validation

Run `make test` and `make sanitize` in `build_v12`. The host-side tests pass with the current toolchain. This validates the adapter/model contract only; it is not evidence of a PS5 payload build, on-console USB transport, or Trap Team figure recognition.
