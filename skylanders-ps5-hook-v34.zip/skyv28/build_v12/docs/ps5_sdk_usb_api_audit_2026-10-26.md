# PS5 SDK USB API audit — 2026-10-26

## Sources checked

- Public PS5 payload SDK repository: https://github.com/ps5-payload-dev/sdk
- `include/freebsd/dev/usb/usb_ioctl.h`
- `include/freebsd/dev/usb/usb_dev.h`
- `include/freebsd/dev/usb/usb_device.h`
- GitHub code search for `USB_FS` and for USB device-mode / gadget / peripheral symbols in the SDK.

## What the source establishes

The SDK exposes FreeBSD-derived USB host stack structures and ioctl contracts. For example, `usb_ioctl.h` defines `usb_ctl_request`, generic descriptor requests, device information, and the `ugen` generic USB device naming used for host-side device access. USB file-system (`usb_fs`) structures describe userland access to USB endpoints/transfers for devices already attached to a host controller.

The repository search did not reveal a documented USB gadget/peripheral API that would make the PS5's physical host connector enumerate as a new USB HID device. This is a bounded search result, not proof that no internal/private facility exists.

## Consequence for this project

Do not try to use `USB_FS_*` as though it creates a virtual USB peripheral. Those interfaces are for accessing attached physical devices. Likewise, virtual DualSense injection is a controller path, not a generic portal HID device path.

The current `sky_usb_device` module is still only a portable protocol model. A genuine PS5 implementation would need an independently validated route, likely one of:

1. an evidenced game-side USB API/service interception point that can mediate the title's requests and provide responses; or
2. an actual USB device/gadget capability exposed by the platform (none documented by the SDK search above); or
3. an external hardware bridge that presents the required USB device to the PS5 and relays messages to the payload/host.

## Safe next research step

Audit public PS4 SDK / backward-compatibility game-facing USB interfaces and inspect available title logs or import/symbol information from a legally obtained game executable. Determine if the game talks to a userland service/library and whether a payload can observe it without guessed offsets. No hook has been added: we do not yet have a verified symbol, ABI, lifecycle, or a reliable test plan for firmware 13.42.

## Validation status

V26 host tests and sanitizer runs passed after the control status-stage state fix. No PS5 payload was built or loaded, and no on-console USB enumeration or figure recognition has been tested.
