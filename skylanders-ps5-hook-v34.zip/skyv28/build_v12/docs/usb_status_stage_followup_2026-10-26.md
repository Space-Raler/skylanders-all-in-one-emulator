# USB enumeration state follow-up — 2026-10-26 (V26)

## Change implemented

The portable USB device model previously committed `SET_ADDRESS` and `SET_CONFIGURATION` immediately when parsing the SETUP packet. USB control transfers require the state change to take effect only after successful completion of the status stage. The model now stores pending values and exposes `sky_usb_device_complete_status()` for the platform backend to call only after its status-stage completion succeeds.

- `SET_ADDRESS` now sets `pending_address` and `address_pending`; `address` changes only on `sky_usb_device_complete_status()`.
- `SET_CONFIGURATION` similarly defers `configuration` / `configured` state changes until status-stage completion.
- Clearing configuration clears queued replies when the change is committed and a `SkyBase` is supplied.
- Unit tests assert both the pending state and committed state.

## Validation run

From `build_v12`:

- `make test` — passed: 7 Python tests, core C tests, HID adapter tests, USB-device tests.
- `make sanitize` — passed for core, adapter, and USB-device C tests with AddressSanitizer and UndefinedBehaviorSanitizer.

## Important limit

This improves correctness of the *model* but does not implement a physical USB controller/backend, PS5 USB device mode, or a game USB API interception path. The platform backend must invoke `sky_usb_device_complete_status()` only after it knows the status stage succeeded. No such backend is currently connected to this model.

## Next transport research gate

Before coding a PS5 hook, identify a documented or source-verified interface available to payloads on the target firmware that can observe or mediate the PS4 title's USB operations. Require evidence of symbols/API availability, lifecycle, and a safe test strategy. Do not use guessed kernel offsets or assume controller injection APIs provide generic USB-device emulation.
