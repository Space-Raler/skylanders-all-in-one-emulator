# PS5 portal transport investigation — update 2

Date: 2026-10-26  
Target: PS5 firmware 13.42, etaHEN + ELF loader, PS4 edition of Skylanders: Trap Team.  
Status: source research and host tests only; no live PS5 transport trace or in-game portal recognition has been demonstrated.

## New source-backed findings

### 1. Portal emulation requires a USB device endpoint, not only figure logic

The public `skylanders-portal-emulator` project describes a Raspberry Pi Pico W using TinyUSB to present itself to the console as a portal. Its documentation says the authors captured the real portal's USB device, configuration, HID-report, and string descriptors, then relayed USB packets in both directions and analyzed them. This is useful evidence for the *shape* of a valid portal implementation: the game/console must see a USB peripheral with matching descriptors and working HID/control transfers. It does not demonstrate that a PS5 payload can make the PS5's own USB host port act as a device.

Source: https://github.com/alexander-shaffer/skylanders-portal-emulator

### 2. A modern emulator solves this by virtualizing USB outside the game, not by using a virtual gamepad

PortalSync presents a virtual portal to PC emulators over USB/IP; it uses portal descriptors and protocol handling derived from emulator code. Its docs list Trap Team among tested games in Cemu and say it has also been used with shadPS4 for another Skylanders title. This confirms that a virtual USB portal is feasible in an emulator that controls the USB-device layer. It does **not** prove the same interception/virtual-device mechanism is available inside a retail PS4 game running under PS5 backward compatibility.

Source: https://github.com/rhsts/portalsync

### 3. The reviewed PS5 payload examples do not establish a generic USB gadget API

Ghostcontrol and related projects demonstrate host-side USB access to physically attached devices plus virtual DualSense input injection. Those are separate capabilities. Neither a host-side `/dev/ugen*`/USB-FS path nor a virtual controller API is a substitute for making a portal enumerate as a USB HID peripheral.

Sources:
- https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2
- https://github.com/ps5-payload-dev/sdk
- https://github.com/PS5Dev/PS5SDK

### 4. PS4 backward compatibility is not evidence of peripheral compatibility

Sony says most PS4 games run on PS5 but warns that some PS4 functionality may not be available and some games can behave unexpectedly. That general statement does not confirm that Trap Team's portal interface is available to a payload or that USB interception works on firmware 13.42.

Source: https://www.playstation.com/en-us/support/games/ps5-backward-compatibility-games/

## Updated hypothesis ranking

1. **Observe the game's portal I/O path without modifying it** — still the highest-priority software-only research step. We need evidence identifying the process/service and API or kernel path that handles portal USB operations on this exact firmware/game combination.
2. **Intercept or redirect that path** — only pursue after step 1 identifies a real, stable call path. Do not guess kernel offsets or reuse offsets from unrelated firmware.
3. **Generic PS5 virtual USB peripheral** — still unsupported by reviewed source. Do not treat controller virtualization as proof.
4. **External USB device-capable bridge** — conventional way to prove the protocol, but it adds hardware and is not the desired software-only end state.

## Minimum proof criteria

A transport test is only a pass if a target-console capture shows all of the following in the same run:

- an operation attributable to Trap Team or its actual USB service;
- operation/command and complete request length/bytes;
- the observed return/error status;
- a controlled, valid response through the candidate path;
- a later game/service event showing the response was consumed;
- at least three repeatable trials with bounded timeouts and no uncontrolled retry loop.

Host unit tests, a payload launching, a UI button responding, or virtual DualSense injection do not satisfy these criteria.

## Current decision

**The USB transport remains blocked/unproven.** The public emulator research clarifies what a working portal endpoint must do, but does not reveal a safe software-only endpoint inside PS5 firmware 13.42. The next concrete engineering action is to establish a reproducible PS5 SDK sample build in cloud CI and separately plan a read-only target-side observation test. Until that observation exists, implementing a hook would be guesswork.
