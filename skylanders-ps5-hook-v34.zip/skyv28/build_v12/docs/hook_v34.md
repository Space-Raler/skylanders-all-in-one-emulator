# Hook (v34): redirecting the game's USB-library calls to the virtual portal

## What exists and is host-tested
- `tools/list_usb_imports.py <decrypted eboot.elf>`: lists which candidate USB-library functions
  the game imports (by NID; the NID algorithm is checked against printf, malloc and
  sceKernelLoadStartModule). Run this first: it confirms the real function names.
- `sky_hook.c`: installs replacements into import slots all-or-nothing and restores them on uninstall.
- `sky_libusb_hook.c`: the replacement functions. The virtual portal appears in the device list next
  to any real devices; anything else is passed to the game's original function. Async transfers on
  the virtual handle complete inside handle_events without touching the real library.
- Tests: `make test` and `make sanitize` (fake game, fake library, fake slots; no leaks).

## What does NOT exist yet (needs verification on the console)
1. **The platform backend `find_slot(nid)`**: locating the writable import slot for a NID inside
   the running PS4 game's memory, and running this code inside that process. Not implemented: it
   depends on APIs of etaHEN / the payload SDK that have not been checked on firmware 13.42, and
   guessed offsets would crash the game.
2. **Signatures and struct layouts** are libusb-1.0's. If the game's library differs, the
   handlers must change. Confirm with the import tool and a trace.
3. **Lazy binding**: if the game's imports are resolved on first call, the loader may overwrite a
   patched slot. Patch after the first resolution or force eager binding.
4. Which functions the game actually imports. Unknown until the tool is run on the real binary.

## Steps
1. Dump your own copy of the game and obtain the DECRYPTED eboot ELF.
2. `python3 tools/list_usb_imports.py eboot.elf` and send me the output (add `--all` if nothing matches).
3. With that list I adjust `sky_libusb_hook_build_entries` to the functions it really imports.
4. The backend (item 1) is written once we know how your etaHEN setup exposes the game process.
