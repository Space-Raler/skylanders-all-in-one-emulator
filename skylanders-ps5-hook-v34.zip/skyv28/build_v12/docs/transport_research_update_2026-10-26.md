# USB transport investigation update — 2026-10-26

Target: PS4 edition of Skylanders: Trap Team running on PS5 firmware 13.42 under the user's jailbreak / ELF-loader setup.

## New checks performed

- Re-ran `make test`: passed (7 Python tests, C core tests, HID adapter/control dispatcher tests).
- Re-ran `make sanitize`: both C test programs passed under AddressSanitizer and UndefinedBehaviorSanitizer.
- Inspected the uploaded `ps5-payload-sdk.zip` and the official `samples/hello_world/Makefile`.
- Attempted to invoke the SDK's `prospero-clang` wrapper. It cannot find the LLVM toolchain: `prospero-llvm-config` finds no installed `llvm-config-*`, and the wrapper ultimately looks for `/llvm-clang`. The archive contains SDK wrapper scripts and PS5 target headers/libraries but does not contain the LLVM compiler bundle itself. No PS5 ELF was produced.
- Re-reviewed the documented Ghostcontrol/Puckbridge approach. Its USB-FS path talks to physically connected devices as a USB host, while its virtual-device path creates a virtual DualSense and injects controller reports. Neither is a generic virtual USB HID peripheral or evidence that Trap Team's portal requests can be intercepted.

## Transport assessment

The existing portal core can answer protocol commands after a transport delivers them, but it has no connection to the PS5 game's USB service. A PS5 physical USB port is host-side; writing a USB-device descriptor and endpoint loop in the payload cannot make that same port enumerate the PS5 as a peripheral.

The most promising software-only route to investigate next is **game-side USB API/service interception**, not reusing the virtual-DualSense API:

1. Identify which USB library/service the PS4 version of Trap Team uses under PS5 backward compatibility.
2. Establish whether those calls can be observed from a payload on firmware 13.42 without guessed kernel offsets.
3. If calls are in the game's process and can be intercepted safely, prototype a narrow fake-device response for one enumeration/control request. If USB I/O is owned by a separate service or protected kernel path, identify that boundary before designing a hook.
4. Only after an observed request and consumed response are proven should the hook forward requests into `sky_core` / `sky_usb_control`.

This is a research hypothesis, not a confirmed API or completed implementation. Current public source evidence does not establish the relevant Trap Team call path or a firmware-13.42-compatible hook point. Do not invent function names, offsets, or claim a transport exists.

## Build environment finding and cloud option

The SDK archive is not a self-contained compiler distribution. A reproducible cloud build can be attempted with GitHub Actions by installing a compatible LLVM package (the SDK's wrapper searches for `llvm-config-18` and newer) and building the official `samples/hello_world` sample first. This would validate the SDK toolchain packaging and ELF build only, not portal transport. The GitHub integration write attempt was denied with HTTP 403, so no workflow has been added to the user's repository.

## Status

- Portable portal core: host tests and sanitizers pass.
- PS5 SDK hello-world ELF: blocked on missing LLVM toolchain in this environment.
- PS5 payload integrating the portal core: not built.
- Generic virtual USB device / Trap Team USB interception: unproven.
- In-game figure recognition: not tested.

## Sources reviewed

- Dynamic payload SDK: https://github.com/ps5-payload-dev/sdk
- Ghostcontrol PS5 USB Controller Patcher: https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2
- PuckbridgePS5: https://github.com/ThisIsAkill/PuckbridgePS5
- PS5 backward compatibility notes: https://www.playstation.com/en-us/support/games/ps5-backward-compatibility-games/
