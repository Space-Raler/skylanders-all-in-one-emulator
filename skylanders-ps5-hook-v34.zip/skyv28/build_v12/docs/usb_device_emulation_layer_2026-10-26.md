# USB device emulation layer — 2026-10-26

## Implemented in this iteration

Added `src/sky/core/sky_usb_device.[ch]`, a platform-neutral USB HID device model based on the project's bundled Switch reference source:

- Real portal identity from reference: VID `0x1430`, PID `0x0150`, bcdDevice `0x0100`, USB 1.1 profile.
- Device, configuration, HID, HID report, language, manufacturer and product descriptors.
- Standard setup handling for GET_DESCRIPTOR, SET_ADDRESS, SET_CONFIGURATION, GET_CONFIGURATION, GET_STATUS, GET_INTERFACE and SET_INTERFACE.
- HID class SET_REPORT routing into the existing portal command dispatcher.
- Configured-state gate and interrupt-IN/OUT adapter routing with endpoint validation.
- Enumeration and endpoint-model tests, including short descriptor reads and unsupported-request stalls.

The descriptor structure is copied from `skyportal-switch-v11.zip` in this workspace (`source/usb_device.cpp`, `source/hid_function.cpp`, `source/hid_function.h`). It is a reference-derived baseline, not a capture from Trap Team running on the target PS5. In particular, endpoint intervals, status-stage behavior, interface matching, and the exact host request sequence still need validation against logs from the target.

## Validation

Run from `build_v12`:

```sh
make test
make sanitize
```

The new `USB device enumeration tests passed` check covers descriptor reads, device address/configuration state, endpoint gating, endpoint-address checks, and unsupported descriptor handling. Existing Python, core, and adapter tests remain part of `make test`.

## Critical limitation

This is a USB-device *protocol engine*, not a USB controller backend. It does not put the PS5's physical host port into device mode, implement physical USB electrical signaling, hook the PS4 game's USB APIs, or complete actual USB status stages. There is still no validated PS5-side transport path on firmware 13.42. The next implementation step is to connect this model to a real, evidence-backed platform transport; no such backend should be fabricated using guessed kernel offsets.
