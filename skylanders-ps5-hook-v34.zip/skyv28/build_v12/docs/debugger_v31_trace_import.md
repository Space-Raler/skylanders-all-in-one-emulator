# V31 debugger trace import

## Implemented

- Browser debugger imports JSON arrays, `{ "events": [...] }`, `{ "records": [...] }`, and JSONL/NDJSON.
- Imported records preserve original fields and are marked with an `imported-capture:` source label.
- Event viewer shows timestamp, type, direction, endpoint, length, status, and payload hex when supplied.
- Export format v2 retains source labels and includes explicit capture limitations.
- Offline analyzer summarizes event type/direction counts, payload-bearing events, repeated payloads, errors/timeouts, and reported dropped events.

## Accepted event field aliases

- Type: `type`, `event_type`, `eventType`
- Time: `timestamp`, `time`, `timestamp_us`
- Payload hex: `payloadHex`, `payload_hex`, `hex`, `dataHex`
- Payload byte array: `payload`
- Length: `capturedLength`, `captured_length`, `length`
- Direction: `direction`

## Not implemented

The web page cannot directly inspect PS5 USB transactions, cannot start a Flipper capture over BLE, and cannot attach to an unverified PS5 hook. An external capture producer must generate the JSON/JSONL file. Missing payload bytes or control-transfer stages must be treated as unavailable, not as proof that no traffic occurred.

## Verification

`make test` includes unit tests for the JSON/JSONL analyzer. The UI script should be syntax-checked with Node when available. These are file-analysis tests only and do not validate real hardware capture.
