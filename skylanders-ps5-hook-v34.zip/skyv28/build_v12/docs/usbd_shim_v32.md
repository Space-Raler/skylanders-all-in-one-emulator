# USB shim (v32): software portal behind a libusb-style API

`src/sky/core/sky_usbd_shim.{h,c}` answers the calls a game makes to a USB library
(enumerate, open, claim, control and interrupt transfers, sync and async) using the
existing portal model. `tests/usbd_shim_test.c` plays the game's side of that
conversation. Host-tested only.

## What this is not
It installs no hook. Getting a PS4 title on a PS5 to call these functions instead of
the real USB library is the still-unproven part (see ps5_transport_investigation_decision).
Nothing here has run on a console, and no firmware offsets are used or guessed.

## Mapping a library replacement would use (ASSUMED, verify against a trace)
The PS4 USB library is believed to mirror libusb-1.0, so the likely correspondence is:

| libusb-style call the game makes | shim function |
|---|---|
| device list / find by VID:PID 1430:0150 | `skyusb_find_device` |
| get device descriptor | `skyusb_get_device_descriptor` |
| open / close | `skyusb_open` / `skyusb_close` |
| claim / release interface 0 | `skyusb_claim_interface` / `skyusb_release_interface` |
| control transfer | `skyusb_control_transfer` |
| interrupt transfer | `skyusb_interrupt_transfer` |
| submit / cancel / handle events | `skyusb_submit_transfer` / `_cancel_` / `skyusb_handle_events` |

Error values use libusb numbering. Which of these calls Trap Team actually makes, and
whether it sends commands by control SET_REPORT, interrupt OUT, or both, must come from
a real read-only trace (see the v31 trace import tool).

## Behaviour choices
- `skyusb_attach` performs the host's enumeration (SET_ADDRESS, descriptors, SET_CONFIGURATION 1) and the status stages. `skyusb_detach` then `skyusb_attach` models a re-plug; figures stay loaded.
- Interrupt OUT is always ACKed. Whether the core treats it as a command is the adapter's existing rule (ignored, and never parsed as audio while the speaker is on).
- IN transfers always complete immediately (a status packet when no reply is queued). A real hook should throttle polling to roughly the endpoint interval so the status counter and figure transitions advance at a realistic rate.
- Async: `skyusb_handle_events` completes only the transfers pending when it was called, so a callback that resubmits cannot spin forever.
- The debug trace is cleared when nearly full instead of blocking traffic.
