# Software-only route: phase 1 and phase 2 implementation notes (V29)

Date: 2026-10-26
Target: PS5 firmware 13.42, etaHEN + ELF Loader, PS4 edition of Skylanders: Trap Team.

## Phase 1 — reuse and compare existing portal implementations

The existing implementation research now has an explicit source-derived baseline:

- `alexander-shaffer/skylanders-portal-emulator` describes capturing real portal USB descriptors and packets, then reproducing those descriptors with TinyUSB on an RP2040. It documents that Trap Team adds portal audio.
- `rhsts/portalsync` documents a virtual portal via USB/IP for PC emulators, and states that its portal protocol is ported from Dolphin's emulated portal and cross-checked with RPCS3/Cemu. Its tested targets are PC emulators, not the PS5 hardware USB stack.
- These are protocol/behavior references. They do not provide a generic software-only USB peripheral for the PS5 host connector.

References:
- https://github.com/alexander-shaffer/skylanders-portal-emulator
- https://github.com/rhsts/portalsync
- https://github.com/Der-Floh/SkylanderTools

No external project's source was copied into this change. Preserve the applicable licenses if future code is ported.

## Phase 2 — PS5 payload interfaces and software-only transport

The public PS5 payload SDK documents payload compilation/loading and exposes USB host-side interfaces for devices already attached to the host. The audited SDK interfaces did not reveal a documented generic USB gadget/device-mode API. Virtual DualSense APIs are gamepad input APIs and cannot stand in for a portal's HID protocol.

Sources:
- https://github.com/ps5-payload-dev/sdk
- https://github.com/ps5-payload-dev/elfldr
- https://github.com/H4zeyaf/Ghostcontrol-PS5-USB-Controller-Patcher-Cyclone2

The highest-priority software-only research route remains a **read-only observation of the game's own USB access path**, followed only if successful by a target-specific mediation backend. This is still a hypothesis, not a working implementation. We do not yet have a verified function/service, ABI, process/plugin lifecycle, or successful firmware 13.42 observation. No guessed offsets or hooks were added.

### Go/no-go gate for the next implementation

A target-side diagnostic must capture the actual process/service, operation/request identifier, transfer length, status/error, and at least three repeatable observations. Only after that evidence exists should a hook/backend be written. If the game-facing path cannot be observed, mark this route blocked instead of pretending the host model is live.

## Interface changes in V29

The UI prototype now includes a “Software-only route readiness” panel that separates:
- host protocol model (host-tested);
- existing implementation audit (reference reviewed);
- PS5 SDK build on target (not verified);
- Trap Team USB call path (unknown);
- real request/response transport (not implemented).

Its local audit/report is deliberately static and labelled as a project-state report. It does not contact the console, claim a live connection, or mark any unverified feature as working.

## Validation and limitations

The V28 host suite was run before the interface update: 7 Python tests passed, and C core/HID adapter/USB model/transport adapter tests passed, including ASan+UBSan. The V29 changes are UI and documentation only; these test results do not validate the PS5 payload or live transport. No PS5 ELF was built or loaded and no in-game recognition was tested.
