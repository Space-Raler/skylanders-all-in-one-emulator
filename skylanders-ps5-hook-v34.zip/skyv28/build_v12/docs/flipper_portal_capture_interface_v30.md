# Flipper Portal Protocol Capture Interface — V30 design

Date: 2026-10-26

## Goal

Add an opt-in diagnostic mode to the Flipper Zero Skylanders portal-emulator firmware. The Flipper remains the USB portal device connected to the PS5. The capture module records the traffic the Flipper firmware can actually observe, correlates host requests with portal replies, and exports the session to an iPhone browser (Bluefy DW) over BLE or to the microSD card.

This is an interface design, not a claim that Flipper firmware hooks or iOS BLE transfer are already implemented. The exact insertion points must be verified against the installed Momentum firmware version and the Skylanders app's USB implementation.

## Data path

1. USB device stack receives a setup packet or OUT report.
2. Capture adapter copies a compact event into a bounded RAM queue; it must not block USB callbacks or modify the emulated portal response.
3. Existing portal handler processes the request and creates its normal response.
4. Capture adapter records the reply at the point where the response bytes/status are known, correlating it to the request where possible.
5. A lower-priority worker drains the queue to the SD writer and, when a browser is subscribed, to the BLE stream queue.
6. Browser acknowledges chunks and can request retransmission. SD remains the reliable full-session fallback.

### Important capture boundary

The app can record only what its firmware hooks expose. HID OUT/IN reports may be visible in the Skylanders app callback. USB enumeration and control-transfer SETUP/status stages may be handled inside the USB stack before the app callback; these require an explicit, verified stack-level hook. Do not label missing stack-level events as “no traffic.” Record a capture-coverage field in every session.

## Firmware modules

- `portal_capture.h/.c`: session state, event schema, bounded queue, counters, overflow markers.
- `portal_capture_usb_adapter.c`: thin integration with verified USB callbacks. Copy bytes and metadata only; no file I/O or BLE calls here.
- `portal_capture_writer.c`: SD file worker, chunking, flush policy, final session footer.
- `portal_capture_ble.c`: optional custom GATT service and chunk/ACK protocol.
- Existing portal command handler: remains authoritative for portal behavior. Capture hooks surround it rather than replacing it.

Suggested state machine: `OFF -> ARMING -> CAPTURING -> DRAINING -> COMPLETE`; errors use `DEGRADED` while capture continues where safe. Starting a session clears counters and allocates a unique session ID. Stop disables new capture, drains queues, flushes the file, then emits a summary.

## Event record

Use a versioned, fixed header and variable payload. Suggested logical fields:

| Field | Type | Meaning |
|---|---|---|
| schema_version | u8 | Starts at 1 |
| event_type | u8 | SETUP, HOST_OUT, PORTAL_IN, PORTAL_REPLY, ENUMERATION, TIMEOUT, USB_ERROR, DROP_SUMMARY, SESSION_MARK |
| flags | u16 | Truncated, correlated, control-stage, inferred, etc. |
| sequence | u32 | Monotonic event number within session |
| timestamp_us | u64 | Monotonic clock when available; otherwise document clock resolution |
| transaction_id | u32 | Pair request/reply; zero if unknown |
| direction | u8 | host-to-portal, portal-to-host, or internal |
| endpoint | u8 | Endpoint address, or 0xFF if not applicable |
| transfer_kind | u8 | control, interrupt, other, unknown |
| status | u8 | success, stall, timeout, cancelled, unknown |
| requested_length | u16 | Requested byte count when known |
| captured_length | u16 | Bytes actually stored |
| payload | bytes | Raw captured bytes, capped by configured maximum |

Do not assume that an app-level callback sees a USB SETUP packet. Mark events `inferred` if reconstructed from application-level behavior instead of observed at the USB-stack boundary. Include device VID/PID, firmware build/version, portal app version, capture coverage, start/stop reason, event/drop counts, and clock units in the session metadata.

## Queue and performance rules

- Use a fixed-size ring buffer with no dynamic allocation in USB callbacks.
- Set a conservative maximum payload (for example, 64 bytes per event initially); use chunked records for larger payloads only if a verified transfer path needs them.
- On queue saturation, increment a drop counter and later emit a `DROP_SUMMARY` record. Never silently pretend the trace is complete.
- Avoid SD writes, JSON serialization, UI refreshes, BLE notifications, and blocking locks in USB callbacks.
- Capture mode is opt-in and has a visible indicator. Include a minimal-metadata mode and a raw-byte mode. Raw mode can contain user-supplied figure dump data; warn before export and do not transmit without an explicit user action.

## SD export

Default location:

`/ext/apps_data/skybase/captures/session_YYYYMMDD_HHMMSS/`

Files:

- `session.json`: schema version, firmware/app versions, device identity, capture coverage, clock information, totals, and completeness flags.
- `events.jsonl`: one event per line, hex payload plus metadata; human-readable and easy to inspect.
- `events.bin`: optional compact binary records for exact replay/analysis and smaller files.
- `summary.json`: counts by event type, endpoint, status, and overflow/drop count.

Write to a `.part` file while capturing, flush periodically from the worker, and rename to the final name only after a clean stop. If power is lost, the `.part` file should still be parseable up to the last complete record. Never overwrite an existing session. Include an explicit `complete: false` or `truncated: true` marker when applicable.

## BLE export protocol

Create a custom GATT service with a stable 128-bit UUID namespace reserved by this project. Proposed characteristics:

- `CAPTURE_CONTROL` (write / write-with-response): START, STOP, GET_STATUS, LIST_SESSIONS, GET_SESSION, CANCEL.
- `CAPTURE_STATUS` (read + notify): state, session ID, queue depth, event count, dropped count, capture coverage.
- `CAPTURE_DATA` (notify): chunk header plus payload.
- `CAPTURE_ACK` (write): highest contiguous chunk received and optional retransmit request.

Chunk framing: `protocol_version:u8 | session_id:u32 | chunk_seq:u16 | flags:u8 | payload_len:u16 | payload | crc16:u16`. Use little-endian integers, document the exact CRC polynomial before implementation, and cap each notification to the negotiated ATT payload size (typically MTU minus 3 bytes). Never assume the iPhone negotiated a large MTU. The browser should request a chunk size based on the actual negotiated limit or use a conservative default.

Flow control: send one or a small bounded number of chunks, wait for ACK, retransmit missing chunks, and expose transfer progress. A disconnect must not stop the SD capture. BLE is for export and status, not for transporting the portal's live USB protocol or changing portal replies.

### iPhone browser constraints

Bluefy DW may support Web Bluetooth features not exposed by every iOS browser. Verify that it can scan/connect to the custom service, subscribe to notifications, write ACKs, and transfer a multi-megabyte log without suspension. If Web Bluetooth is unavailable or unstable, use the SD card as the guaranteed path: save the capture on Flipper, then import the file into the website through the iOS file picker. The site cannot read the Flipper SD card directly over Bluetooth without a supported GATT/file-transfer protocol.

## Debug UI contract

- `Start capture`: request Flipper to start; only show `CAPTURING` after Flipper status confirms it.
- `Stop capture`: stop, drain, and finalize.
- `Export over BLE`: transfer an existing or active capture with progress and retry status.
- `Import capture file`: accept `.jsonl`, `.json`, or `.bin` from the iOS file picker.
- Live event table: time, direction, transfer, endpoint, length, status, transaction ID, payload preview.
- Filters: enumeration, control, OUT, IN/reply, errors/timeouts, raw bytes.
- Health indicators: queue high-water mark, dropped events, capture coverage, SD state, BLE link state.
- Never show fabricated packet rows. Empty traffic must say “No events captured”; unavailable instrumentation must say “Not observed by current capture hook.”

## Privacy and safe behavior

- Capture is disabled by default and has a clear on-device indicator.
- Do not write or export figure payload bytes unless raw capture is enabled or the user confirms export.
- No background upload or automatic network transmission. BLE export begins only after explicit user action.
- Preserve the portal handler's original response bytes and timing as much as possible. Add a capture-off comparison test to check that enabling logging does not change behavior materially.

## Implementation sequence / acceptance tests

1. Confirm exact Momentum version, app source, USB library, and the callback used for host OUT reports and portal IN replies.
2. Add schema and ring-buffer module with host-side unit tests independent of Flipper APIs.
3. Integrate report-level hooks and prove raw OUT/IN bytes match the handler inputs/outputs.
4. Determine whether USB stack enumeration/control transfers can be observed safely; report coverage honestly if not.
5. Add SD writer; test clean stop, abrupt power-loss `.part` recovery, full card, write errors, and unique naming.
6. Add BLE GATT export; test low MTU, dropped notifications, duplicate chunks, reconnect, ACK/retry, and long sessions.
7. Test Bluefy DW on the target iPhone; if unsupported, use SD import rather than claiming BLE compatibility.
8. Compare emulator behavior with capture off/on; assert no changes to generated portal responses.
9. Analyze a real session from PS5 startup through portal initialization and controlled figure placement/removal. Mark every observation as captured, inferred, or unavailable.

## Current project status

This document defines the interface and implementation contract only. No Flipper firmware capture hook, custom GATT service, SD writer, or live PS5 capture has been implemented or validated in this repository. The existing C USB model is a platform-neutral host-side model, not the Flipper USB stack. The actual Momentum app integration point must be identified from the relevant firmware/app source before code can be safely connected.
