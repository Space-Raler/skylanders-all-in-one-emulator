#include "sky_hook.h"
#include <string.h>

SkyHookResult sky_hook_install(SkyHookState *st, const SkyHookPlatform *p,
                               const SkyHookEntry *e, size_t n, size_t *patched) {
    SkyFn *found[SKY_HOOK_MAX];
    if (patched) *patched = 0;
    if (!st || !p || !p->find_slot || !e || n == 0 || n > SKY_HOOK_MAX) return SKY_HOOK_INVALID;
    if (st->installed) return SKY_HOOK_ALREADY_INSTALLED;
    for (size_t i = 0; i < n; i++) {
        if (!e[i].nid || !e[i].replacement) return SKY_HOOK_INVALID;
        found[i] = p->find_slot(p->ctx, e[i].nid);
        if (!found[i] && e[i].required) return SKY_HOOK_MISSING_REQUIRED;   /* nothing touched yet */
    }
    memset(st, 0, sizeof(*st));
    for (size_t i = 0; i < n; i++) {
        if (!found[i]) continue;
        st->slot[st->count] = found[i];
        st->orig[st->count] = *found[i];
        st->count++;
        if (e[i].original_out) *e[i].original_out = *found[i];
        *found[i] = e[i].replacement;
    }
    st->installed = true;
    if (patched) *patched = st->count;
    return SKY_HOOK_OK;
}

void sky_hook_uninstall(SkyHookState *st) {
    if (!st || !st->installed) return;
    for (size_t i = st->count; i > 0; i--) *st->slot[i - 1] = st->orig[i - 1];
    memset(st, 0, sizeof(*st));
}
