#pragma once
/* Import-slot patching logic for redirecting a game's library calls to our replacements.
 * Platform-neutral and host-tested with a fake slot table. The platform backend that finds the
 * real import slots inside a running PS4 game (by NID) is NOT part of this file or implemented
 * anywhere in this project yet: it needs APIs verified on the console. */
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*SkyFn)(void);
#define SKY_HOOK_MAX 48u

typedef struct {
    const char *name;
    const char *nid;
    SkyFn replacement;
    SkyFn *original_out;   /* receives the slot's previous value (may be NULL) */
    bool required;         /* if required and the game does not import it, install nothing */
} SkyHookEntry;

typedef struct {
    void *ctx;
    /* Return the writable import slot for this NID, or NULL if the game does not import it. */
    SkyFn *(*find_slot)(void *ctx, const char *nid);
} SkyHookPlatform;

typedef struct {
    SkyFn *slot[SKY_HOOK_MAX];
    SkyFn orig[SKY_HOOK_MAX];
    size_t count;
    bool installed;
} SkyHookState;

typedef enum { SKY_HOOK_OK = 0, SKY_HOOK_INVALID, SKY_HOOK_MISSING_REQUIRED, SKY_HOOK_ALREADY_INSTALLED } SkyHookResult;

/* All-or-nothing: if any required function has no slot, nothing is patched. */
SkyHookResult sky_hook_install(SkyHookState *st, const SkyHookPlatform *p,
    const SkyHookEntry *entries, size_t n, size_t *patched);
void sky_hook_uninstall(SkyHookState *st);

#ifdef __cplusplus
}
#endif
