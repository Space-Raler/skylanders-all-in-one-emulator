#pragma once
/* libusb-style facade over the virtual Skylanders portal (software only).
 *
 * This is the layer a game-side USB library replacement would call: enumerate,
 * open, claim, control/interrupt transfers (sync and async). It runs the
 * existing SkyUsbDevice/SkyBase model; it does NOT install any hook. Making a
 * PS4 title on a PS5 call these functions instead of the real USB library is a
 * separate, unproven step (see docs/usbd_shim_v32.md). Error codes use libusb's
 * numbering so a thin mapping layer can return them unchanged.
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "sky_ps5_transport.h"

#ifdef __cplusplus
extern "C" {
#endif

enum {
    SKYUSB_OK = 0,
    SKYUSB_ERROR_IO = -1,
    SKYUSB_ERROR_INVALID_PARAM = -2,
    SKYUSB_ERROR_NO_DEVICE = -4,
    SKYUSB_ERROR_NOT_FOUND = -5,
    SKYUSB_ERROR_BUSY = -6,
    SKYUSB_ERROR_PIPE = -9,
    SKYUSB_ERROR_NOT_SUPPORTED = -12
};
enum { SKYUSB_TRANSFER_CONTROL = 0, SKYUSB_TRANSFER_INTERRUPT = 3 };
enum { SKYUSB_STATUS_COMPLETED = 0, SKYUSB_STATUS_ERROR = 1, SKYUSB_STATUS_CANCELLED = 3,
       SKYUSB_STATUS_STALL = 4, SKYUSB_STATUS_NO_DEVICE = 5 };

#define SKYUSB_MAX_PENDING 8u

typedef struct SkyUsbTransfer SkyUsbTransfer;
typedef void (*SkyUsbTransferCb)(SkyUsbTransfer *transfer);
struct SkyUsbTransfer {
    uint8_t endpoint;        /* interrupt: endpoint address; control: ignored */
    uint8_t type;            /* SKYUSB_TRANSFER_* */
    uint8_t *buffer;         /* control: 8-byte SETUP followed by the data stage */
    int length;              /* buffer size (control: includes the 8 setup bytes) */
    int actual_length;       /* control: data-stage bytes only */
    int status;              /* SKYUSB_STATUS_* */
    SkyUsbTransferCb callback;
    void *user_data;
    bool cancelled_;         /* internal */
};

typedef struct {
    SkyPs5Transport transport;
    bool attached;           /* enumerated by the (virtual) host */
    bool opened;
    bool claimed;
    SkyUsbTransfer *pending[SKYUSB_MAX_PENDING];
    size_t pending_count;
    uint32_t control_count, in_count, out_count;
} SkyUsbShim;

void skyusb_init(SkyUsbShim *s, SkyBase *base);
/* Run the bus-side enumeration a host does on plug-in (address, descriptors, configuration 1). */
int skyusb_attach(SkyUsbShim *s);
void skyusb_detach(SkyUsbShim *s);   /* pending transfers complete with NO_DEVICE on next handle_events */

/* 1 if the virtual portal matches vid:pid (and is attached), else 0. */
int skyusb_find_device(const SkyUsbShim *s, uint16_t vid, uint16_t pid);
int skyusb_get_device_descriptor(SkyUsbShim *s, uint8_t out[18]);
int skyusb_open(SkyUsbShim *s);
void skyusb_close(SkyUsbShim *s);
int skyusb_claim_interface(SkyUsbShim *s, int interface_number);
int skyusb_release_interface(SkyUsbShim *s, int interface_number);

/* Return bytes transferred (>= 0) or a negative SKYUSB_ERROR_*. */
int skyusb_control_transfer(SkyUsbShim *s, uint8_t bm_request_type, uint8_t b_request,
    uint16_t w_value, uint16_t w_index, uint8_t *data, uint16_t w_length);
int skyusb_interrupt_transfer(SkyUsbShim *s, uint8_t endpoint, uint8_t *data, int length,
    int *transferred);

int skyusb_submit_transfer(SkyUsbShim *s, SkyUsbTransfer *t);
int skyusb_cancel_transfer(SkyUsbShim *s, SkyUsbTransfer *t);
/* Completes the transfers pending at entry (not ones submitted by callbacks) and runs callbacks. */
int skyusb_handle_events(SkyUsbShim *s);

#ifdef __cplusplus
}
#endif
