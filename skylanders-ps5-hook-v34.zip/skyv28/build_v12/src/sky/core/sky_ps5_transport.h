#pragma once
/* PS5 transport integration seam.
 * This module adapts a VERIFIED platform/game-I/O hook to the portable USB
 * device model. It does not install a hook, access kernel internals, or create
 * a USB peripheral. A target backend must call these entry points only after
 * it has proven the actual Trap Team USB I/O path on the target firmware.
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "sky_usb_device.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SKY_PS5_TRACE_CAPACITY 64u

typedef enum {
    SKY_PS5_TRANSPORT_OK = 0,
    SKY_PS5_TRANSPORT_INVALID_ARGUMENT,
    SKY_PS5_TRANSPORT_NO_BACKEND,
    SKY_PS5_TRANSPORT_USB_ERROR,
    SKY_PS5_TRANSPORT_TRACE_FULL
} SkyPs5TransportResult;

typedef enum {
    SKY_PS5_EVENT_SETUP = 1,
    SKY_PS5_EVENT_STATUS_OK,
    SKY_PS5_EVENT_STATUS_FAILED,
    SKY_PS5_EVENT_INTERRUPT_IN,
    SKY_PS5_EVENT_INTERRUPT_OUT,
    SKY_PS5_EVENT_BACKEND_ATTACHED,
    SKY_PS5_EVENT_BACKEND_MISSING
} SkyPs5TransportEventType;

typedef struct {
    uint32_t sequence;
    SkyPs5TransportEventType type;
    int32_t result;
    uint16_t length;
    uint8_t endpoint;
    uint8_t request;
} SkyPs5TransportEvent;

typedef struct {
    SkyBase *base;
    SkyUsbDevice usb;
    SkyPs5TransportEvent trace[SKY_PS5_TRACE_CAPACITY];
    size_t trace_count;
    uint32_t next_sequence;
    bool backend_attached;
} SkyPs5Transport;

void sky_ps5_transport_init(SkyPs5Transport *transport, SkyBase *base);
/* Explicitly records that no real target transport is attached. */
SkyPs5TransportResult sky_ps5_transport_require_backend(SkyPs5Transport *transport);
/* Backend event entry points. These model/route transfers; they do not perform
 * physical USB transactions themselves. status_ok must be called only after
 * the actual platform reports that the control status stage succeeded. */
SkyPs5TransportResult sky_ps5_transport_setup(
    SkyPs5Transport *transport, const uint8_t setup[8],
    const uint8_t *out_payload, size_t out_payload_len,
    uint8_t *response, size_t response_capacity, size_t *response_len);
SkyPs5TransportResult sky_ps5_transport_status_ok(SkyPs5Transport *transport);
SkyPs5TransportResult sky_ps5_transport_status_failed(SkyPs5Transport *transport);
SkyPs5TransportResult sky_ps5_transport_interrupt_in(
    SkyPs5Transport *transport, uint8_t endpoint,
    uint8_t report[SKY_PACKET_SIZE], bool *was_command_reply);
SkyPs5TransportResult sky_ps5_transport_interrupt_out(
    SkyPs5Transport *transport, uint8_t endpoint,
    const uint8_t *report, size_t report_len);
size_t sky_ps5_transport_trace_read(const SkyPs5Transport *transport,
    size_t start, SkyPs5TransportEvent *out, size_t capacity);
void sky_ps5_transport_trace_clear(SkyPs5Transport *transport);

#ifdef __cplusplus
}
#endif
