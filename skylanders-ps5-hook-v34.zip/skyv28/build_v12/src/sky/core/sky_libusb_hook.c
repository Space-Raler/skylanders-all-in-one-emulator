#include "sky_libusb_hook.h"
#include "sky_hook_nids.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* ---- libusb-1.0 ABI subset (assumed) ---- */
struct lu_device_descriptor {
    uint8_t bLength, bDescriptorType; uint16_t bcdUSB;
    uint8_t bDeviceClass, bDeviceSubClass, bDeviceProtocol, bMaxPacketSize0;
    uint16_t idVendor, idProduct, bcdDevice;
    uint8_t iManufacturer, iProduct, iSerialNumber, bNumConfigurations;
};
struct lu_transfer {
    void *dev_handle; uint8_t flags; unsigned char endpoint; unsigned char type; unsigned int timeout;
    int status; int length; int actual_length;
    void (*callback)(struct lu_transfer *); void *user_data; unsigned char *buffer; int num_iso_packets;
};
_Static_assert(sizeof(struct lu_device_descriptor) == 18, "libusb device descriptor must be 18 bytes");

typedef ptrdiff_t (*get_list_fn)(void *, void ***);
typedef void (*free_list_fn)(void **, int);
typedef int (*get_desc_fn)(void *, struct lu_device_descriptor *);
typedef int (*open_fn)(void *, void **);
typedef void (*close_fn)(void *);
typedef void *(*open_vp_fn)(void *, uint16_t, uint16_t);
typedef int (*iface_fn)(void *, int);
typedef int (*control_fn)(void *, uint8_t, uint8_t, uint16_t, uint16_t, unsigned char *, uint16_t, unsigned);
typedef int (*interrupt_fn)(void *, unsigned char, unsigned char *, int, int *, unsigned);
typedef int (*transfer_fn)(struct lu_transfer *);
typedef int (*events_fn)(void *);
typedef int (*events_to_fn)(void *, void *);
typedef int (*events_done_fn)(void *, int *);

#define LU_ERROR_NOT_SUPPORTED (-12)

static struct {
    SkyFn get_list, free_list, get_desc, open, close, open_vp, claim, release,
          control, interrupt, submit, cancel, events, events_to, events_done;
} orig;

static SkyUsbShim *g_shim;
static char g_vdev, g_vhandle;          /* addresses are the virtual device / handle identities */
#define VQ_MAX 8
static struct lu_transfer *vq[VQ_MAX];
static bool vq_cancelled[VQ_MAX];
static size_t vq_n;
static struct { void **ours; void **theirs; } lists[4];

static bool attached(void) { return g_shim && g_shim->attached; }

int sky_libusb_hook_attach(SkyUsbShim *shim) {
    g_shim = shim;
    vq_n = 0;
    return shim ? skyusb_attach(shim) : SKYUSB_ERROR_INVALID_PARAM;
}

/* ---- device list ---- */
static ptrdiff_t h_get_list(void *ctx, void ***list) {
    void **theirs = NULL; ptrdiff_t n = 0;
    if (orig.get_list) n = ((get_list_fn)orig.get_list)(ctx, &theirs);
    if (!attached() || !list) { if (list) *list = theirs; return n; }
    if (n < 0) { n = 0; theirs = NULL; }
    void **ours = malloc((size_t)(n + 2) * sizeof(void *));
    if (!ours) { *list = theirs; return n; }
    for (ptrdiff_t i = 0; i < n; i++) ours[i] = theirs[i];
    ours[n] = &g_vdev; ours[n + 1] = NULL;
    for (size_t i = 0; i < 4; i++) if (!lists[i].ours) { lists[i].ours = ours; lists[i].theirs = theirs; break; }
    *list = ours;
    return n + 1;
}
static void h_free_list(void **list, int unref) {
    for (size_t i = 0; i < 4; i++) if (list && lists[i].ours == list) {
        void **theirs = lists[i].theirs;
        lists[i].ours = lists[i].theirs = NULL;
        free(list);
        if (theirs && orig.free_list) ((free_list_fn)orig.free_list)(theirs, unref);
        return;
    }
    if (orig.free_list) ((free_list_fn)orig.free_list)(list, unref);
}

/* ---- device / handle ---- */
static int h_get_desc(void *dev, struct lu_device_descriptor *d) {
    if (dev == &g_vdev) {
        uint8_t raw[18];
        if (!d) return SKYUSB_ERROR_INVALID_PARAM;
        int r = skyusb_get_device_descriptor(g_shim, raw);
        if (r != SKYUSB_OK) return r;
        memcpy(d, raw, sizeof raw);
        return 0;
    }
    return orig.get_desc ? ((get_desc_fn)orig.get_desc)(dev, d) : LU_ERROR_NOT_SUPPORTED;
}
static int h_open(void *dev, void **handle) {
    if (dev == &g_vdev) {
        if (!handle) return SKYUSB_ERROR_INVALID_PARAM;
        int r = skyusb_open(g_shim);
        if (r == SKYUSB_OK) *handle = &g_vhandle;
        return r;
    }
    return orig.open ? ((open_fn)orig.open)(dev, handle) : LU_ERROR_NOT_SUPPORTED;
}
static void h_close(void *h) {
    if (h == &g_vhandle) { skyusb_close(g_shim); return; }
    if (orig.close) ((close_fn)orig.close)(h);
}
static void *h_open_vp(void *ctx, uint16_t vid, uint16_t pid) {
    if (attached() && skyusb_find_device(g_shim, vid, pid) && skyusb_open(g_shim) == SKYUSB_OK) return &g_vhandle;
    return orig.open_vp ? ((open_vp_fn)orig.open_vp)(ctx, vid, pid) : NULL;
}
static int h_claim(void *h, int n) {
    if (h == &g_vhandle) return skyusb_claim_interface(g_shim, n);
    return orig.claim ? ((iface_fn)orig.claim)(h, n) : LU_ERROR_NOT_SUPPORTED;
}
static int h_release(void *h, int n) {
    if (h == &g_vhandle) return skyusb_release_interface(g_shim, n);
    return orig.release ? ((iface_fn)orig.release)(h, n) : LU_ERROR_NOT_SUPPORTED;
}
static int h_control(void *h, uint8_t bm, uint8_t br, uint16_t wv, uint16_t wi, unsigned char *d, uint16_t wl, unsigned to) {
    if (h == &g_vhandle) return skyusb_control_transfer(g_shim, bm, br, wv, wi, d, wl);
    return orig.control ? ((control_fn)orig.control)(h, bm, br, wv, wi, d, wl, to) : LU_ERROR_NOT_SUPPORTED;
}
static int h_interrupt(void *h, unsigned char ep, unsigned char *d, int len, int *tr, unsigned to) {
    if (h == &g_vhandle) return skyusb_interrupt_transfer(g_shim, ep, d, len, tr);
    return orig.interrupt ? ((interrupt_fn)orig.interrupt)(h, ep, d, len, tr, to) : LU_ERROR_NOT_SUPPORTED;
}

/* ---- async transfers ---- */
static int h_submit(struct lu_transfer *t) {
    if (t && t->dev_handle == &g_vhandle) {
        if (vq_n >= VQ_MAX) return SKYUSB_ERROR_BUSY;
        for (size_t i = 0; i < vq_n; i++) if (vq[i] == t) return SKYUSB_ERROR_BUSY;
        vq_cancelled[vq_n] = false; vq[vq_n++] = t;
        return 0;
    }
    return orig.submit ? ((transfer_fn)orig.submit)(t) : LU_ERROR_NOT_SUPPORTED;
}
static int h_cancel(struct lu_transfer *t) {
    for (size_t i = 0; i < vq_n; i++) if (vq[i] == t) { vq_cancelled[i] = true; return 0; }
    return orig.cancel ? ((transfer_fn)orig.cancel)(t) : LU_ERROR_NOT_SUPPORTED;
}
/* Complete the virtual transfers pending now; returns how many. */
static size_t run_virtual(void) {
    struct lu_transfer *batch[VQ_MAX]; bool canc[VQ_MAX]; const size_t n = vq_n;
    memcpy(batch, vq, n * sizeof vq[0]); memcpy(canc, vq_cancelled, n * sizeof canc[0]);
    vq_n = 0;
    for (size_t i = 0; i < n; i++) {
        struct lu_transfer *t = batch[i];
        if (canc[i]) { t->status = SKYUSB_STATUS_CANCELLED; t->actual_length = 0; }
        else if (!attached()) { t->status = SKYUSB_STATUS_NO_DEVICE; t->actual_length = 0; }
        else {
            SkyUsbTransfer st = { .endpoint = t->endpoint, .type = t->type, .buffer = t->buffer, .length = t->length };
            if (skyusb_submit_transfer(g_shim, &st) != SKYUSB_OK) st.status = SKYUSB_STATUS_ERROR;
            else skyusb_handle_events(g_shim);
            t->status = st.status; t->actual_length = st.actual_length;
        }
        if (t->callback) t->callback(t);
    }
    return n;
}
static int h_events(void *ctx) {
    if (run_virtual()) return 0;   /* do not block in the real library after completing virtual work */
    return orig.events ? ((events_fn)orig.events)(ctx) : 0;
}
static int h_events_to(void *ctx, void *tv) {
    if (run_virtual()) return 0;
    return orig.events_to ? ((events_to_fn)orig.events_to)(ctx, tv) : 0;
}
static int h_events_done(void *ctx, int *completed) {
    if (run_virtual()) return 0;
    return orig.events_done ? ((events_done_fn)orig.events_done)(ctx, completed) : 0;
}

/* ---- entry table ---- */
static const char *nid_of(const char *name) {
    for (size_t i = 0; i < SKY_HOOK_NID_COUNT; i++) if (!strcmp(sky_hook_nids[i].name, name)) return sky_hook_nids[i].nid;
    return NULL;
}

size_t sky_libusb_hook_build_entries(SkyHookEntry *out, size_t cap) {
    memset(&orig, 0, sizeof orig);
    const struct { const char *name; SkyFn rep; SkyFn *orig; bool req; } m[] = {
        { "sceUsbdGetDeviceList",       (SkyFn)h_get_list,    &orig.get_list,   true  },
        { "sceUsbdFreeDeviceList",      (SkyFn)h_free_list,   &orig.free_list,  true  },
        { "sceUsbdGetDeviceDescriptor", (SkyFn)h_get_desc,    &orig.get_desc,   true  },
        { "sceUsbdOpen",                (SkyFn)h_open,        &orig.open,       true  },
        { "sceUsbdClose",               (SkyFn)h_close,       &orig.close,      true  },
        { "sceUsbdClaimInterface",      (SkyFn)h_claim,       &orig.claim,      true  },
        { "sceUsbdReleaseInterface",    (SkyFn)h_release,     &orig.release,    true  },
        { "sceUsbdOpenDeviceWithVidPid",(SkyFn)h_open_vp,     &orig.open_vp,    false },
        { "sceUsbdControlTransfer",     (SkyFn)h_control,     &orig.control,    false },
        { "sceUsbdInterruptTransfer",   (SkyFn)h_interrupt,   &orig.interrupt,  false },
        { "sceUsbdSubmitTransfer",      (SkyFn)h_submit,      &orig.submit,     false },
        { "sceUsbdCancelTransfer",      (SkyFn)h_cancel,      &orig.cancel,     false },
        { "sceUsbdHandleEvents",        (SkyFn)h_events,      &orig.events,     false },
        { "sceUsbdHandleEventsTimeout", (SkyFn)h_events_to,   &orig.events_to,  false },
        { "sceUsbdHandleEventsCompleted",(SkyFn)h_events_done,&orig.events_done,false },
    };
    const size_t n = sizeof m / sizeof m[0];
    if (!out || cap < n) return 0;
    for (size_t i = 0; i < n; i++) {
        out[i].name = m[i].name; out[i].nid = nid_of(m[i].name);
        out[i].replacement = m[i].rep; out[i].original_out = m[i].orig; out[i].required = m[i].req;
    }
    return n;
}
