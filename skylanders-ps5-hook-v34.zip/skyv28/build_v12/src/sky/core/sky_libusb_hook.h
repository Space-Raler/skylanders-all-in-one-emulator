#pragma once
/* Replacement functions for a libusb-1.0-style USB library, presenting the virtual Skylanders
 * portal next to any real devices. Anything that is not the virtual portal is passed to the
 * game's original function. ASSUMPTION: the game's library matches libusb-1.0 signatures and
 * struct layouts (descriptor 18 bytes, transfer struct as in libusb 1.0.x). Verify against the
 * game before relying on it. */
#include "sky_hook.h"
#include "sky_usbd_shim.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Fill entries (capacity cap) for every function this layer replaces; returns the count.
 * Also resets the stored originals, which the installer fills in. */
size_t sky_libusb_hook_build_entries(SkyHookEntry *out, size_t cap);
/* Use this shim as the virtual portal and plug it in. */
int sky_libusb_hook_attach(SkyUsbShim *shim);

#ifdef __cplusplus
}
#endif
