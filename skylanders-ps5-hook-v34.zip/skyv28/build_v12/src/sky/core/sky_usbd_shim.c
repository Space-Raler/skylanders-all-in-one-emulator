#include "sky_usbd_shim.h"
#include <string.h>

static void le16w(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }

/* The transport trace is for debugging; never let a full trace block normal operation. */
static void trim_trace(SkyUsbShim *s) {
    if (s->transport.trace_count + 4u >= SKY_PS5_TRACE_CAPACITY) sky_ps5_transport_trace_clear(&s->transport);
}

void skyusb_init(SkyUsbShim *s, SkyBase *base) {
    if (!s) return;
    memset(s, 0, sizeof(*s));
    sky_ps5_transport_init(&s->transport, base);
}

static int ctrl(SkyUsbShim *s, uint8_t bm, uint8_t req, uint16_t value, uint16_t index,
                uint8_t *data, uint16_t wlen) {
    uint8_t setup[8], resp[256];
    size_t rl = 0;
    const bool in = (bm & 0x80) != 0;
    setup[0] = bm; setup[1] = req;
    le16w(setup + 2, value); le16w(setup + 4, index); le16w(setup + 6, wlen);
    trim_trace(s);
    if (sky_ps5_transport_setup(&s->transport, setup, in ? NULL : data, in ? 0 : wlen,
                                resp, sizeof resp, &rl) != SKY_PS5_TRANSPORT_OK) {
        sky_ps5_transport_status_failed(&s->transport);
        return SKYUSB_ERROR_PIPE;
    }
    sky_ps5_transport_status_ok(&s->transport);
    s->control_count++;
    if (in) {
        size_t n = rl < wlen ? rl : wlen;
        if (n) memcpy(data, resp, n);
        return (int)n;
    }
    return (int)wlen;
}

int skyusb_attach(SkyUsbShim *s) {
    uint8_t buf[64];
    if (!s || !s->transport.base) return SKYUSB_ERROR_INVALID_PARAM;
    if (ctrl(s, 0x00, 0x05, 1, 0, NULL, 0) < 0) return SKYUSB_ERROR_IO;      /* SET_ADDRESS 1 */
    if (ctrl(s, 0x80, 0x06, 0x0100, 0, buf, 18) != 18) return SKYUSB_ERROR_IO; /* device descr */
    if (ctrl(s, 0x80, 0x06, 0x0200, 0, buf, sizeof buf) < 9) return SKYUSB_ERROR_IO;
    if (ctrl(s, 0x00, 0x09, 1, 0, NULL, 0) < 0) return SKYUSB_ERROR_IO;      /* SET_CONFIGURATION 1 */
    s->attached = s->transport.usb.configured;
    return s->attached ? SKYUSB_OK : SKYUSB_ERROR_IO;
}

void skyusb_detach(SkyUsbShim *s) {
    if (!s) return;
    s->attached = false; s->opened = false; s->claimed = false;
    sky_usb_device_init(&s->transport.usb);
}

int skyusb_find_device(const SkyUsbShim *s, uint16_t vid, uint16_t pid) {
    return s && s->attached && vid == SKY_USB_VID && pid == SKY_USB_PID;
}

int skyusb_get_device_descriptor(SkyUsbShim *s, uint8_t out[18]) {
    if (!s || !out) return SKYUSB_ERROR_INVALID_PARAM;
    if (!s->attached) return SKYUSB_ERROR_NO_DEVICE;
    return ctrl(s, 0x80, 0x06, 0x0100, 0, out, 18) == 18 ? SKYUSB_OK : SKYUSB_ERROR_IO;
}

int skyusb_open(SkyUsbShim *s) {
    if (!s) return SKYUSB_ERROR_INVALID_PARAM;
    if (!s->attached) return SKYUSB_ERROR_NO_DEVICE;
    s->opened = true;
    return SKYUSB_OK;
}

void skyusb_close(SkyUsbShim *s) {
    if (!s) return;
    s->opened = false; s->claimed = false;
}

int skyusb_claim_interface(SkyUsbShim *s, int n) {
    if (!s) return SKYUSB_ERROR_INVALID_PARAM;
    if (!s->attached || !s->opened) return SKYUSB_ERROR_NO_DEVICE;
    if (n != 0) return SKYUSB_ERROR_NOT_FOUND;
    if (s->claimed) return SKYUSB_ERROR_BUSY;
    s->claimed = true;
    return SKYUSB_OK;
}

int skyusb_release_interface(SkyUsbShim *s, int n) {
    if (!s) return SKYUSB_ERROR_INVALID_PARAM;
    if (n != 0 || !s->claimed) return SKYUSB_ERROR_NOT_FOUND;
    s->claimed = false;
    return SKYUSB_OK;
}

int skyusb_control_transfer(SkyUsbShim *s, uint8_t bm, uint8_t req, uint16_t value,
                            uint16_t index, uint8_t *data, uint16_t wlen) {
    if (!s || (wlen && !data)) return SKYUSB_ERROR_INVALID_PARAM;
    if (!s->attached || !s->opened) return SKYUSB_ERROR_NO_DEVICE;
    return ctrl(s, bm, req, value, index, data, wlen);
}

int skyusb_interrupt_transfer(SkyUsbShim *s, uint8_t ep, uint8_t *data, int length, int *transferred) {
    if (!s || !data || length < 0) return SKYUSB_ERROR_INVALID_PARAM;
    if (!s->attached || !s->opened || !s->claimed) return SKYUSB_ERROR_NO_DEVICE;
    if (transferred) *transferred = 0;
    trim_trace(s);
    if (ep & 0x80) {
        uint8_t report[SKY_PACKET_SIZE];
        bool reply = false;
        if (ep != SKY_USB_EP_IN) return SKYUSB_ERROR_INVALID_PARAM;
        if (sky_ps5_transport_interrupt_in(&s->transport, ep, report, &reply) != SKY_PS5_TRANSPORT_OK)
            return SKYUSB_ERROR_IO;
        int n = length < (int)sizeof report ? length : (int)sizeof report;
        memcpy(data, report, (size_t)n);
        if (transferred) *transferred = n;
        s->in_count++;
        return SKYUSB_OK;
    }
    if (ep != SKY_USB_EP_OUT) return SKYUSB_ERROR_INVALID_PARAM;
    /* Called on the device directly: "ignored" (speaker audio, or an OUT packet the core does
     * not treat as a command) is still a successful transfer from the game's point of view. */
    SkyUsbDeviceResult r = sky_usb_device_interrupt_out(&s->transport.usb, s->transport.base,
        ep, data, (size_t)length);
    if (r != SKY_USB_DEVICE_OK && r != SKY_USB_DEVICE_IGNORED) return SKYUSB_ERROR_IO;
    if (transferred) *transferred = length;
    s->out_count++;
    return SKYUSB_OK;
}

int skyusb_submit_transfer(SkyUsbShim *s, SkyUsbTransfer *t) {
    if (!s || !t || !t->buffer || t->length < 0) return SKYUSB_ERROR_INVALID_PARAM;
    if (t->type != SKYUSB_TRANSFER_CONTROL && t->type != SKYUSB_TRANSFER_INTERRUPT)
        return SKYUSB_ERROR_NOT_SUPPORTED;
    if (t->type == SKYUSB_TRANSFER_CONTROL && t->length < 8) return SKYUSB_ERROR_INVALID_PARAM;
    if (!s->attached) return SKYUSB_ERROR_NO_DEVICE;
    if (s->pending_count >= SKYUSB_MAX_PENDING) return SKYUSB_ERROR_BUSY;
    for (size_t i = 0; i < s->pending_count; i++) if (s->pending[i] == t) return SKYUSB_ERROR_BUSY;
    t->cancelled_ = false; t->actual_length = 0; t->status = SKYUSB_STATUS_COMPLETED;
    s->pending[s->pending_count++] = t;
    return SKYUSB_OK;
}

int skyusb_cancel_transfer(SkyUsbShim *s, SkyUsbTransfer *t) {
    if (!s || !t) return SKYUSB_ERROR_INVALID_PARAM;
    for (size_t i = 0; i < s->pending_count; i++)
        if (s->pending[i] == t) { t->cancelled_ = true; return SKYUSB_OK; }
    return SKYUSB_ERROR_NOT_FOUND;
}

static void run_transfer(SkyUsbShim *s, SkyUsbTransfer *t) {
    if (t->cancelled_) { t->status = SKYUSB_STATUS_CANCELLED; return; }
    if (!s->attached || !s->opened) { t->status = SKYUSB_STATUS_NO_DEVICE; return; }
    if (t->type == SKYUSB_TRANSFER_CONTROL) {
        const uint8_t *su = t->buffer;
        const uint16_t wlen = (uint16_t)(su[6] | (su[7] << 8));
        if ((int)wlen > t->length - 8) { t->status = SKYUSB_STATUS_ERROR; return; }
        int r = ctrl(s, su[0], su[1], (uint16_t)(su[2] | (su[3] << 8)), (uint16_t)(su[4] | (su[5] << 8)),
                     t->buffer + 8, wlen);
        if (r == SKYUSB_ERROR_PIPE) t->status = SKYUSB_STATUS_STALL;
        else if (r < 0) t->status = SKYUSB_STATUS_ERROR;
        else t->actual_length = r;
    } else {
        int n = 0;
        int r = skyusb_interrupt_transfer(s, t->endpoint, t->buffer, t->length, &n);
        if (r == SKYUSB_OK) t->actual_length = n;
        else t->status = r == SKYUSB_ERROR_NO_DEVICE ? SKYUSB_STATUS_NO_DEVICE : SKYUSB_STATUS_ERROR;
    }
}

int skyusb_handle_events(SkyUsbShim *s) {
    if (!s) return SKYUSB_ERROR_INVALID_PARAM;
    SkyUsbTransfer *batch[SKYUSB_MAX_PENDING];
    const size_t n = s->pending_count;
    memcpy(batch, s->pending, n * sizeof batch[0]);
    s->pending_count = 0;
    for (size_t i = 0; i < n; i++) {
        run_transfer(s, batch[i]);
        if (batch[i]->callback) batch[i]->callback(batch[i]);   /* may resubmit */
    }
    return SKYUSB_OK;
}
