#include "sky_ps5_transport.h"
#include <string.h>

static void trace_event(SkyPs5Transport *t, SkyPs5TransportEventType type,
                        int32_t result, uint16_t length, uint8_t endpoint,
                        uint8_t request) {
    if (!t || t->trace_count >= SKY_PS5_TRACE_CAPACITY) return;
    SkyPs5TransportEvent *e = &t->trace[t->trace_count++];
    e->sequence = t->next_sequence++;
    e->type = type; e->result = result; e->length = length;
    e->endpoint = endpoint; e->request = request;
}

void sky_ps5_transport_init(SkyPs5Transport *t, SkyBase *base) {
    if (!t) return;
    memset(t, 0, sizeof(*t));
    t->base = base;
    sky_usb_device_init(&t->usb);
}

SkyPs5TransportResult sky_ps5_transport_require_backend(SkyPs5Transport *t) {
    if (!t || !t->base) return SKY_PS5_TRANSPORT_INVALID_ARGUMENT;
    if (!t->backend_attached) {
        trace_event(t, SKY_PS5_EVENT_BACKEND_MISSING,
                    SKY_PS5_TRANSPORT_NO_BACKEND, 0, 0, 0);
        return SKY_PS5_TRANSPORT_NO_BACKEND;
    }
    return SKY_PS5_TRANSPORT_OK;
}

SkyPs5TransportResult sky_ps5_transport_setup(
    SkyPs5Transport *t, const uint8_t setup[8],
    const uint8_t *out_payload, size_t out_payload_len,
    uint8_t *response, size_t response_capacity, size_t *response_len) {
    if (!t || !t->base || !setup || !response_len ||
        (!out_payload && out_payload_len) || (!response && response_capacity))
        return SKY_PS5_TRANSPORT_INVALID_ARGUMENT;
    size_t len = 0;
    SkyUsbDeviceResult r = sky_usb_device_setup(&t->usb, t->base, setup,
        out_payload, out_payload_len, response, response_capacity, &len);
    *response_len = len;
    trace_event(t, SKY_PS5_EVENT_SETUP, (int32_t)r,
        (uint16_t)(len > UINT16_MAX ? UINT16_MAX : len), 0, setup[1]);
    return r == SKY_USB_DEVICE_OK ? SKY_PS5_TRANSPORT_OK : SKY_PS5_TRANSPORT_USB_ERROR;
}

SkyPs5TransportResult sky_ps5_transport_status_ok(SkyPs5Transport *t) {
    if (!t || !t->base) return SKY_PS5_TRANSPORT_INVALID_ARGUMENT;
    sky_usb_device_complete_status(&t->usb, t->base);
    trace_event(t, SKY_PS5_EVENT_STATUS_OK, SKY_PS5_TRANSPORT_OK, 0, 0, 0);
    return SKY_PS5_TRANSPORT_OK;
}

SkyPs5TransportResult sky_ps5_transport_status_failed(SkyPs5Transport *t) {
    if (!t || !t->base) return SKY_PS5_TRANSPORT_INVALID_ARGUMENT;
    /* Discard pending state: a failed status stage must not commit SET_ADDRESS
       or SET_CONFIGURATION. The next SETUP request may replace pending state. */
    t->usb.address_pending = false;
    t->usb.configuration_pending = false;
    trace_event(t, SKY_PS5_EVENT_STATUS_FAILED, SKY_PS5_TRANSPORT_USB_ERROR, 0, 0, 0);
    return SKY_PS5_TRANSPORT_OK;
}

SkyPs5TransportResult sky_ps5_transport_interrupt_in(
    SkyPs5Transport *t, uint8_t endpoint, uint8_t report[SKY_PACKET_SIZE],
    bool *was_command_reply) {
    if (!t || !t->base || !report || !was_command_reply)
        return SKY_PS5_TRANSPORT_INVALID_ARGUMENT;
    SkyUsbDeviceResult r = sky_usb_device_interrupt_in(&t->usb, t->base,
        endpoint, report, was_command_reply);
    trace_event(t, SKY_PS5_EVENT_INTERRUPT_IN, (int32_t)r, SKY_PACKET_SIZE, endpoint, 0);
    return r == SKY_USB_DEVICE_OK ? SKY_PS5_TRANSPORT_OK : SKY_PS5_TRANSPORT_USB_ERROR;
}

SkyPs5TransportResult sky_ps5_transport_interrupt_out(
    SkyPs5Transport *t, uint8_t endpoint, const uint8_t *report, size_t report_len) {
    if (!t || !t->base || (!report && report_len)) return SKY_PS5_TRANSPORT_INVALID_ARGUMENT;
    SkyUsbDeviceResult r = sky_usb_device_interrupt_out(&t->usb, t->base,
        endpoint, report, report_len);
    trace_event(t, SKY_PS5_EVENT_INTERRUPT_OUT, (int32_t)r,
        (uint16_t)(report_len > UINT16_MAX ? UINT16_MAX : report_len), endpoint, 0);
    return r == SKY_USB_DEVICE_OK ? SKY_PS5_TRANSPORT_OK : SKY_PS5_TRANSPORT_USB_ERROR;
}

size_t sky_ps5_transport_trace_read(const SkyPs5Transport *t, size_t start,
                                    SkyPs5TransportEvent *out, size_t capacity) {
    if (!t || !out || start >= t->trace_count || !capacity) return 0;
    size_t n = t->trace_count - start;
    if (n > capacity) n = capacity;
    memcpy(out, &t->trace[start], n * sizeof(*out));
    return n;
}

void sky_ps5_transport_trace_clear(SkyPs5Transport *t) {
    if (!t) return;
    t->trace_count = 0;
}
