#pragma once
/* Portable USB 1.1 HID device-enumeration model for the Skylanders portal.
 * This answers descriptor/standard requests and routes HID SET_REPORT into the
 * existing protocol dispatcher. A platform backend must still perform real bus
 * transfers and USB status stages; this module does not make a PS5 host port a
 * USB device or intercept PS4-game USB I/O.
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "sky_usb_control.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SKY_USB_VID 0x1430u
#define SKY_USB_PID 0x0150u
#define SKY_USB_EP_IN 0x81u
#define SKY_USB_EP_OUT 0x02u
#define SKY_USB_CONFIG_DESCRIPTOR_SIZE 41u
#define SKY_USB_REPORT_DESCRIPTOR_SIZE 29u

typedef enum {
    SKY_USB_DEVICE_OK = 0,
    SKY_USB_DEVICE_INVALID_ARGUMENT,
    SKY_USB_DEVICE_STALL,
    SKY_USB_DEVICE_BUFFER_TOO_SMALL,
    SKY_USB_DEVICE_CONTROL_ERROR,
    SKY_USB_DEVICE_NOT_CONFIGURED,
    SKY_USB_DEVICE_WRONG_ENDPOINT,
    SKY_USB_DEVICE_IGNORED
} SkyUsbDeviceResult;

typedef struct {
    uint8_t address;
    uint8_t configuration;
    bool configured;
    /* Standard requests take effect only after the control status stage. */
    uint8_t pending_address;
    uint8_t pending_configuration;
    bool address_pending;
    bool configuration_pending;
    uint32_t setup_count;
    uint32_t descriptor_count;
    uint32_t unsupported_count;
} SkyUsbDevice;

void sky_usb_device_init(SkyUsbDevice *device);
/* Commit deferred SET_ADDRESS / SET_CONFIGURATION after the backend confirms
 * successful completion of the control status stage. Call only on success. */
void sky_usb_device_complete_status(SkyUsbDevice *device, SkyBase *base);
/* Model one completed interrupt endpoint transaction after configuration.
 * IN fills exactly one 32-byte report; OUT passes a report to the protocol core. */
SkyUsbDeviceResult sky_usb_device_interrupt_in(SkyUsbDevice *device, SkyBase *base,
    uint8_t endpoint, uint8_t report[SKY_PACKET_SIZE], bool *was_command_reply);
SkyUsbDeviceResult sky_usb_device_interrupt_out(SkyUsbDevice *device, SkyBase *base,
    uint8_t endpoint, const uint8_t *report, size_t report_len);
/* Respond to a raw 8-byte USB SETUP packet. OUT data for SET_REPORT is passed
 * separately in out_payload. `response` receives the control data stage only;
 * the platform backend remains responsible for ACK/status-stage completion. */
SkyUsbDeviceResult sky_usb_device_setup(
    SkyUsbDevice *device, SkyBase *base, const uint8_t setup[8],
    const uint8_t *out_payload, size_t out_payload_len,
    uint8_t *response, size_t response_capacity, size_t *response_len);

#ifdef __cplusplus
}
#endif
