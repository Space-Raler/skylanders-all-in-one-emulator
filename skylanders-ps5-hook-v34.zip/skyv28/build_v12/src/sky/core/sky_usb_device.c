#include "sky_usb_device.h"
#include <string.h>

#define USB_DIR_IN 0x80u
#define USB_TYPE_MASK 0x60u
#define USB_TYPE_STANDARD 0x00u
#define USB_TYPE_CLASS 0x20u
#define USB_RECIP_MASK 0x1fu
#define USB_RECIP_DEVICE 0x00u
#define USB_RECIP_INTERFACE 0x01u
#define USB_REQ_GET_STATUS 0x00u
#define USB_REQ_CLEAR_FEATURE 0x01u
#define USB_REQ_SET_ADDRESS 0x05u
#define USB_REQ_GET_DESCRIPTOR 0x06u
#define USB_REQ_GET_CONFIGURATION 0x08u
#define USB_REQ_SET_CONFIGURATION 0x09u
#define USB_REQ_GET_INTERFACE 0x0au
#define USB_REQ_SET_INTERFACE 0x0bu
#define USB_DT_DEVICE 0x01u
#define USB_DT_CONFIGURATION 0x02u
#define USB_DT_STRING 0x03u
#define USB_DT_INTERFACE 0x04u
#define USB_DT_ENDPOINT 0x05u
#define USB_DT_HID 0x21u
#define USB_DT_REPORT 0x22u

/* Device identity and interface layout copied from the project’s Switch
 * reference source (USB 1.1 profile). IN interval 22 ms, OUT interval 1 ms. */
static const uint8_t device_descriptor[] = {
    18, USB_DT_DEVICE, 0x10,0x01, 0,0,0, 64,
    0x30,0x14, 0x50,0x01, 0x00,0x01, 1,2,0,1
};
static const uint8_t config_descriptor[SKY_USB_CONFIG_DESCRIPTOR_SIZE] = {
    9, USB_DT_CONFIGURATION, 41,0, 1,1,0, 0x80, 50,
    9, USB_DT_INTERFACE, 0,0,2, 3,0,0,0,
    9, USB_DT_HID, 0x11,0x01,0,1, USB_DT_REPORT, 29,0,
    7, USB_DT_ENDPOINT, SKY_USB_EP_IN, 3, 32,0, 22,
    7, USB_DT_ENDPOINT, SKY_USB_EP_OUT,3, 32,0, 1
};
static const uint8_t report_descriptor[SKY_USB_REPORT_DESCRIPTOR_SIZE] = {
    0x06,0x00,0xff, 0x09,0x01, 0xa1,0x01, 0x19,0x01, 0x29,0x40,
    0x15,0x00, 0x26,0xff,0x00, 0x75,0x08, 0x95,0x20, 0x81,0x00,
    0x19,0x01, 0x29,0x40, 0x91,0x00, 0xc0
};
static const uint8_t lang_string[] = {4,USB_DT_STRING,0x09,0x04};
static const uint8_t manufacturer_string[] = {22,USB_DT_STRING,'A',0,'c',0,'t',0,'i',0,'v',0,'i',0,'s',0,'i',0,'o',0,'n',0};
static const uint8_t product_string[] = {24,USB_DT_STRING,'S',0,'p',0,'y',0,'r',0,'o',0,' ',0,'P',0,'o',0,'r',0,'t',0,'a',0};

static uint16_t le16(const uint8_t *p) { return (uint16_t)(p[0] | ((uint16_t)p[1] << 8)); }
static SkyUsbDeviceResult send_bytes(const uint8_t *src, size_t src_len, uint16_t requested,
                                     uint8_t *out, size_t cap, size_t *out_len) {
    size_t n = src_len;
    if (n > requested) n = requested;
    if (n > cap || (n && !out)) return SKY_USB_DEVICE_BUFFER_TOO_SMALL;
    if (n) memcpy(out, src, n);
    *out_len = n;
    return SKY_USB_DEVICE_OK;
}
void sky_usb_device_init(SkyUsbDevice *d) { if (d) memset(d, 0, sizeof(*d)); }

void sky_usb_device_complete_status(SkyUsbDevice *d, SkyBase *base) {
    if (!d) return;
    if (d->address_pending) {
        d->address = d->pending_address;
        d->address_pending = false;
    }
    if (d->configuration_pending) {
        d->configuration = d->pending_configuration;
        d->configured = (d->configuration == 1);
        d->configuration_pending = false;
        if (!d->configured && base) sky_base_clear_replies(base);
    }
}

SkyUsbDeviceResult sky_usb_device_interrupt_in(SkyUsbDevice *d, SkyBase *base,
    uint8_t endpoint, uint8_t report[SKY_PACKET_SIZE], bool *was_command_reply) {
    if (!d || !base || !report || !was_command_reply) return SKY_USB_DEVICE_INVALID_ARGUMENT;
    if (!d->configured) return SKY_USB_DEVICE_NOT_CONFIGURED;
    if (endpoint != SKY_USB_EP_IN) return SKY_USB_DEVICE_WRONG_ENDPOINT;
    SkyAdapterResult ar = sky_hid_adapter_interrupt_in(base, endpoint, report, was_command_reply);
    if (ar == SKY_ADAPTER_OK) return SKY_USB_DEVICE_OK;
    if (ar == SKY_ADAPTER_IGNORED) return SKY_USB_DEVICE_IGNORED;
    return SKY_USB_DEVICE_CONTROL_ERROR;
}

SkyUsbDeviceResult sky_usb_device_interrupt_out(SkyUsbDevice *d, SkyBase *base,
    uint8_t endpoint, const uint8_t *report, size_t report_len) {
    if (!d || !base || (!report && report_len)) return SKY_USB_DEVICE_INVALID_ARGUMENT;
    if (!d->configured) return SKY_USB_DEVICE_NOT_CONFIGURED;
    if (endpoint != SKY_USB_EP_OUT) return SKY_USB_DEVICE_WRONG_ENDPOINT;
    SkyAdapterResult ar = sky_hid_adapter_interrupt_out(base, endpoint, report, report_len);
    if (ar == SKY_ADAPTER_OK) return SKY_USB_DEVICE_OK;
    if (ar == SKY_ADAPTER_IGNORED || ar == SKY_ADAPTER_AUDIO_DATA) return SKY_USB_DEVICE_IGNORED;
    return SKY_USB_DEVICE_CONTROL_ERROR;
}

SkyUsbDeviceResult sky_usb_device_setup(SkyUsbDevice *d, SkyBase *base,
    const uint8_t setup[8], const uint8_t *out_payload, size_t out_payload_len,
    uint8_t *response, size_t response_capacity, size_t *response_len) {
    if (!d || !base || !setup || !response_len || (!out_payload && out_payload_len) ||
        (!response && response_capacity)) return SKY_USB_DEVICE_INVALID_ARGUMENT;
    *response_len = 0;
    d->setup_count++;
    const uint8_t type = setup[0], request = setup[1];
    const uint16_t value = le16(setup+2), index = le16(setup+4), length = le16(setup+6);
    const uint8_t kind = type & USB_TYPE_MASK, recipient = type & USB_RECIP_MASK;
    const bool in = (type & USB_DIR_IN) != 0;
    if (kind == USB_TYPE_STANDARD) {
        if (request == USB_REQ_GET_DESCRIPTOR && in) {
            const uint8_t dt = (uint8_t)(value >> 8), di = (uint8_t)value;
            const uint8_t *src = NULL; size_t n = 0;
            if (recipient == USB_RECIP_DEVICE && dt == USB_DT_DEVICE && di == 0) { src=device_descriptor; n=sizeof device_descriptor; }
            else if (recipient == USB_RECIP_DEVICE && dt == USB_DT_CONFIGURATION && di == 0) { src=config_descriptor; n=sizeof config_descriptor; }
            else if (recipient == USB_RECIP_DEVICE && dt == USB_DT_STRING) {
                if (di == 0) { src=lang_string; n=sizeof lang_string; }
                else if (di == 1) { src=manufacturer_string; n=sizeof manufacturer_string; }
                else if (di == 2) { src=product_string; n=sizeof product_string; }
            } else if (recipient == USB_RECIP_INTERFACE && index == 0 && dt == USB_DT_REPORT && di == 0) { src=report_descriptor; n=sizeof report_descriptor; }
            else if (recipient == USB_RECIP_INTERFACE && index == 0 && dt == USB_DT_HID && di == 0) { src=config_descriptor+18; n=9; }
            if (!src) { d->unsupported_count++; return SKY_USB_DEVICE_STALL; }
            d->descriptor_count++;
            return send_bytes(src,n,length,response,response_capacity,response_len);
        }
        if (request == USB_REQ_SET_ADDRESS && recipient == USB_RECIP_DEVICE && !in && length == 0 && value <= 127 && index == 0) {
            d->pending_address=(uint8_t)value; d->address_pending=true; return SKY_USB_DEVICE_OK;
        }
        if (request == USB_REQ_SET_CONFIGURATION && recipient == USB_RECIP_DEVICE && !in && length == 0 && index == 0 && (value == 0 || value == 1)) {
            d->pending_configuration=(uint8_t)value; d->configuration_pending=true; return SKY_USB_DEVICE_OK;
        }
        if (request == USB_REQ_GET_CONFIGURATION && recipient == USB_RECIP_DEVICE && in && length >= 1) {
            uint8_t cfg=d->configuration; return send_bytes(&cfg,1,length,response,response_capacity,response_len);
        }
        if (request == USB_REQ_GET_STATUS && in && length >= 2) {
            static const uint8_t status[2]={0,0}; return send_bytes(status,2,length,response,response_capacity,response_len);
        }
        if (request == USB_REQ_GET_INTERFACE && recipient == USB_RECIP_INTERFACE && in && index == 0 && length >= 1) {
            static const uint8_t alt=0; return send_bytes(&alt,1,length,response,response_capacity,response_len);
        }
        if (request == USB_REQ_SET_INTERFACE && recipient == USB_RECIP_INTERFACE && !in && index == 0 && value == 0 && length == 0) return SKY_USB_DEVICE_OK;
        if ((request == USB_REQ_CLEAR_FEATURE) && !in && length == 0) return SKY_USB_DEVICE_OK;
        d->unsupported_count++; return SKY_USB_DEVICE_STALL;
    }
    if (kind == USB_TYPE_CLASS && recipient == USB_RECIP_INTERFACE && index == 0 && in) {
        /* HID class reads. A host that sees these stalled may treat the device as broken. */
        if (request == 0x01 && length >= 1) { /* GET_REPORT: same packet interrupt IN would give */
            uint8_t rep[SKY_PACKET_SIZE]; bool reply = false;
            if (sky_hid_adapter_interrupt_in(base, SKY_USB_EP_IN, rep, &reply) != SKY_ADAPTER_OK) return SKY_USB_DEVICE_CONTROL_ERROR;
            return send_bytes(rep, sizeof rep, length, response, response_capacity, response_len);
        }
        if (request == 0x02 && length >= 1) { static const uint8_t idle = 0; return send_bytes(&idle, 1, length, response, response_capacity, response_len); }
        if (request == 0x03 && length >= 1) { static const uint8_t proto = 1; return send_bytes(&proto, 1, length, response, response_capacity, response_len); }
    }
    if (kind == USB_TYPE_CLASS && recipient == USB_RECIP_INTERFACE && index == 0 && !in &&
        (request == 0x09 || request == 0x0A || request == 0x0B)) { /* SET_REPORT, SET_IDLE, SET_PROTOCOL */
        size_t n=0;
        SkyUsbControlResult cr=sky_usb_control_dispatch(base,type,request,value,index,length,out_payload,out_payload_len,response,response_capacity,&n);
        if (cr != SKY_USB_CTRL_OK) { d->unsupported_count++; return SKY_USB_DEVICE_CONTROL_ERROR; }
        *response_len=n; return SKY_USB_DEVICE_OK;
    }
    d->unsupported_count++;
    return SKY_USB_DEVICE_STALL;
}
